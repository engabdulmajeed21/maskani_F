import { FormEvent, ReactNode, useEffect, useRef, useState } from "react"

const screens = [
  "البداية",
  "الترحيب",
  "البحث الذكي",
  "الحجز بثقة",
  "تسجيل الدخول",
  "إنشاء حساب",
  "رمز التحقق",
  "استعادة كلمة المرور",
  "كلمة المرور المؤقتة",
  "كلمة مرور جديدة",
  "ترحيب المستخدم",
  "ترحيب الشركاء",
  "الرئيسية",
  "حسابي",
  "المنازل والشقق",
  "الإشعارات",
  "تصفية البحث",
  "المساعد الذكي",
  "تعطيل الحساب",
  "حذف الحساب",
  "الاقتراحات",
  "حول المنصة",
  "نتائج البحث",
  "تعديل الملف الشخصي",
  "توثيق الحساب",
  "قائمة المتابعة",
  "انضم كشريك",
  "إدارة وأمان الحساب",
  "اللغة",
  "طلباتي",
  "الملف الشخصي",
  "إعدادات الإشعارات",
  "المساعدة والتواصل",
  "الشروط والأحكام",
  "رفع طلب عقار جديد",
  "الرسائل",
  "المحادثة",
  "المفضلة",
  "تفاصيل العقار",
  "قيد التطوير",
  "الملف الشخصي للمالك",
  "المحلات التجارية",
  "الأراضي",
  "الفنادق",
  "الشاليهات",
  "العروض المميزة",
]

type IconName = "arrow" | "mail" | "lock" | "user" | "phone" | "eye" | "menu" | "bell" | "bellOff" | "moon" | "sun" | "search" | "filter" | "home" | "heart" | "calendar" | "chat" | "building" | "shop" | "hotel" | "chalet" | "land" | "sparkles" | "chevron" | "tag" | "userPlus" | "settings" | "globe" | "help" | "document" | "logout" | "trash" | "close" | "warning" | "send" | "pause" | "shield" | "instagram" | "facebook" | "xSocial" | "pin" | "whatsapp" | "upload" | "share" | "google" | "apple" | "video" | "mic" | "paperclip" | "image" | "more" | "smile" | "bolt" | "droplet" | "wifi" | "bed" | "bath" | "sofa" | "kitchen" | "star"

function Icon({ name }: { name: IconName }) {
  const paths: Record<IconName, ReactNode> = {
    arrow: <path d="m9 18 6-6-6-6M15 12H3" />,
    mail: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="3" />
        <path d="m3 8 9 6 9-6" />
      </>
    ),
    lock: (
      <>
        <rect x="4" y="10" width="16" height="11" rx="3" />
        <path d="M8 10V7a4 4 0 0 1 8 0v3" />
      </>
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4.5 21a7.5 7.5 0 0 1 15 0" />
      </>
    ),
    phone: (
      <>
        <rect x="6" y="2" width="12" height="20" rx="3" />
        <path d="M10 18h4" />
      </>
    ),
    eye: (
      <>
        <path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" />
        <circle cx="12" cy="12" r="2.5" />
      </>
    ),
    menu: <path d="M4 7h16M4 12h16M4 17h16" />,
    bell: (
      <>
        <path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" />
        <path d="M10 21h4" />
      </>
    ),
    bellOff: (
      <>
        <path d="M13.7 4.2A6 6 0 0 1 18 10c0 1.8.2 3.2.6 4.3M6.3 6.3A6 6 0 0 0 6 10c0 7-3 7-3 9h14" />
        <path d="M10 22h4M3 3l18 18" />
      </>
    ),
    moon: <path d="M20 15.3A8.5 8.5 0 0 1 8.7 4a8.5 8.5 0 1 0 11.3 11.3Z" />,
    sun: (
      <>
        <circle cx="12" cy="12" r="4" />
        <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    filter: <path d="M4 6h16M7 12h10M10 18h4" />,
    home: (
      <>
        <path d="m3 11 9-8 9 8" />
        <path d="M5 10v10h14V10M9 20v-6h6v6" />
      </>
    ),
    heart: (
      <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z" />
    ),
    calendar: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="3" />
        <path d="M8 3v4M16 3v4M3 10h18" />
      </>
    ),
    chat: (
      <>
        <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z" />
        <path d="M8 10h8M8 14h5" />
      </>
    ),
    building: (
      <>
        <path d="M3 11 12 4l9 7v10H3Z" />
        <path d="M8 21v-6h8v6" />
      </>
    ),
    shop: (
      <>
        <path d="M4 10v10h16V10M3 5h18l-2 5H5Z" />
        <path d="M9 20v-6h6v6" />
      </>
    ),
    hotel: (
      <>
        <rect x="4" y="3" width="16" height="18" rx="2" />
        <path d="M8 7h2M14 7h2M8 11h2M14 11h2M10 21v-5h4v5" />
      </>
    ),
    chalet: (
      <>
        <path d="m2 13 10-9 10 9M5 11v10h14V11" />
        <path d="M9 21v-6h6v6M4 8h16" />
      </>
    ),
    land: (
      <>
        <path d="m3 7 6-3 6 3 6-3v13l-6 3-6-3-6 3Z" />
        <path d="M9 4v13M15 7v13" />
      </>
    ),
    sparkles: (
      <>
        <path d="m12 3 1.3 4.2L17 9l-3.7 1.8L12 15l-1.3-4.2L7 9l3.7-1.8Z" />
        <path d="m19 15 .7 2.3L22 18l-2.3.7L19 21l-.7-2.3L16 18l2.3-.7Z" />
        <path d="m5 3 .6 2L8 6l-2.4 1L5 9l-.6-2L2 6l2.4-1Z" />
      </>
    ),
    chevron: <path d="m15 18-6-6 6-6" />,
    tag: (
      <>
        <path d="M20 13 13 20 4 11V4h7Z" />
        <circle cx="8.5" cy="8.5" r="1" />
      </>
    ),
    userPlus: (
      <>
        <circle cx="9" cy="8" r="4" />
        <path d="M2 21a7 7 0 0 1 14 0M19 8v6M16 11h6" />
      </>
    ),
    settings: (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" />
      </>
    ),
    globe: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18" />
      </>
    ),
    help: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M9.6 9a2.5 2.5 0 1 1 3.7 2.2c-.9.5-1.3 1-1.3 2M12 17h.01" />
      </>
    ),
    document: (
      <>
        <path d="M6 3h8l4 4v14H6Z" />
        <path d="M14 3v5h5M9 13h6M9 17h6" />
      </>
    ),
    logout: <path d="M10 4H5v16h5M14 8l4 4-4 4M8 12h10" />,
    trash: (
      <>
        <path d="M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14M10 11v6M14 11v6" />
      </>
    ),
    close: <path d="m6 6 12 12M18 6 6 18" />,
    warning: (
      <>
        <path d="M10.3 3.7 2.5 18a2 2 0 0 0 1.8 3h15.4a2 2 0 0 0 1.8-3L13.7 3.7a2 2 0 0 0-3.4 0Z" />
        <path d="M12 9v4M12 17h.01" />
      </>
    ),
    send: <path d="m22 2-7 20-4-9-9-4ZM22 2 11 13" />,
    pause: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M9 9v6M15 9v6" />
      </>
    ),
    shield: (
      <>
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" />
        <path d="m9 12 2 2 4-4" />
      </>
    ),
    instagram: (
      <>
        <rect x="3" y="3" width="18" height="18" rx="5" />
        <circle cx="12" cy="12" r="4" />
        <circle cx="17.5" cy="6.5" r=".5" />
      </>
    ),
    facebook: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M14.5 8H13a2 2 0 0 0-2 2v11M8 13h7" />
      </>
    ),
    xSocial: <path d="M5 4h3l11 16h-3ZM19 4 5 20" />,
    pin: (
      <>
        <path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    whatsapp: (
      <>
        <path d="M20.5 11.6a8.5 8.5 0 0 1-12.6 7.5L3 20.5l1.4-4.7A8.5 8.5 0 1 1 20.5 11.6Z" />
        <path d="M8.3 7.7c.3-.6.6-.6.9-.6h.4l.8 2c.1.3.1.5-.1.7l-.6.7c-.2.2-.1.4 0 .6.7 1.2 1.7 2.2 3 2.8.2.1.4.1.6-.1l.8-1c.2-.2.4-.3.7-.2l1.9.9c.3.1.5.3.5.5 0 .4-.2 1.3-.7 1.8-.5.5-1.4.8-2.3.6-1.1-.2-2.8-.8-4.7-2.5-1.5-1.4-2.5-3.1-2.8-4.2-.3-.9 0-1.6.3-2Z" />
      </>
    ),
    upload: (
      <>
        <path d="M12 16V4M7 9l5-5 5 5" />
        <path d="M4 15v5h16v-5" />
      </>
    ),
    share: (
      <>
        <circle cx="18" cy="5" r="3" />
        <circle cx="6" cy="12" r="3" />
        <circle cx="18" cy="19" r="3" />
        <path d="m8.6 10.5 6.8-4M8.6 13.5l6.8 4" />
      </>
    ),
    google: (
      <>
        <path d="M21 12.2c0-.7-.1-1.4-.2-2H12v3.7h5.1a4.4 4.4 0 0 1-1.9 2.9v2.4h3.1c1.8-1.7 2.7-4.1 2.7-7Z" />
        <path d="M12 21c2.6 0 4.8-.9 6.3-2.3l-3.1-2.4c-.9.6-2 1-3.2 1a5.6 5.6 0 0 1-5.3-3.9H3.5v2.5A9.5 9.5 0 0 0 12 21Z" />
        <path d="M6.7 13.4a5.7 5.7 0 0 1 0-3.6V7.3H3.5a9.5 9.5 0 0 0 0 8.6Z" />
        <path d="M12 5.9c1.4 0 2.7.5 3.7 1.4l2.7-2.7A9.1 9.1 0 0 0 12 2.1a9.5 9.5 0 0 0-8.5 5.2l3.2 2.5A5.6 5.6 0 0 1 12 5.9Z" />
      </>
    ),
    apple: (
      <>
        <path d="M16.7 13.2c0-2.7 2.2-4 2.3-4.1a5 5 0 0 0-3.9-2.1c-1.7-.2-3.2 1-4.1 1s-2.2-1-3.7-1a5.4 5.4 0 0 0-4.6 2.8c-2 3.4-.5 8.5 1.4 11.3.9 1.4 2 2.9 3.5 2.8 1.4-.1 1.9-.9 3.6-.9s2.2.9 3.7.9c1.5 0 2.5-1.4 3.4-2.8a12.3 12.3 0 0 0 1.6-3.2 4.8 4.8 0 0 1-3.2-4.7Z" />
        <path d="M14 5.2A4.7 4.7 0 0 0 15.1 2a4.8 4.8 0 0 0-3.1 1.6 4.4 4.4 0 0 0-1.1 3.1A4 4 0 0 0 14 5.2Z" />
      </>
    ),
    video: (
      <>
        <rect x="3" y="6" width="13" height="12" rx="3" />
        <path d="m16 10 5-3v10l-5-3Z" />
      </>
    ),
    mic: (
      <>
        <rect x="9" y="3" width="6" height="11" rx="3" />
        <path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6" />
      </>
    ),
    paperclip: (
      <path d="m21 11.5-8.8 8.8a6 6 0 0 1-8.5-8.5l9.5-9.5a4 4 0 0 1 5.7 5.7l-9.5 9.5a2 2 0 1 1-2.8-2.8l8.8-8.8" />
    ),
    image: (
      <>
        <rect x="3" y="3" width="18" height="18" rx="3" />
        <circle cx="8.5" cy="8.5" r="1.5" />
        <path d="m21 15-5-5L5 21" />
      </>
    ),
    more: (
      <>
        <circle cx="5" cy="12" r="1" />
        <circle cx="12" cy="12" r="1" />
        <circle cx="19" cy="12" r="1" />
      </>
    ),
    smile: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01" />
      </>
    ),
    bolt: <path d="m13 2-8 12h7l-1 8 8-12h-7Z" />,
    droplet: <path d="M12 2S5 10 5 15a7 7 0 0 0 14 0c0-5-7-13-7-13Z" />,
    wifi: (
      <>
        <path d="M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0" />
        <circle cx="12" cy="20" r="1" />
      </>
    ),
    bed: (
      <>
        <path d="M3 19v-9M21 19v-6a3 3 0 0 0-3-3H9v6h12M3 16h18" />
        <path d="M5 10V7h4v3" />
      </>
    ),
    bath: (
      <>
        <path d="M4 12h17v2a6 6 0 0 1-6 6H9a5 5 0 0 1-5-5ZM7 12V6a3 3 0 0 1 6 0" />
        <path d="M8 20v2M18 20v2" />
      </>
    ),
    sofa: (
      <>
        <path d="M5 12V8a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3v4" />
        <path d="M4 11a2 2 0 0 0-2 2v5h20v-5a2 2 0 0 0-2-2M6 18v3M18 18v3" />
      </>
    ),
    kitchen: (
      <>
        <path d="M6 3v18M18 3v18M6 11h12M9 7h.01M15 7h.01M9 15h.01M15 15h.01" />
      </>
    ),
    star: (
      <path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-2.9-5.6 2.9 1.1-6.2L3 9.6l6.2-.9Z" />
    ),
  }

  return (
    <svg className="icon" viewBox="0 0 24 24" aria-hidden="true">
      {paths[name]}
    </svg>
  )
}

function LogoMark({ large = false }: { large?: boolean }) {
  return (
    <div className={large ? "logo-mark logo-mark--large" : "logo-mark"}>
      <svg viewBox="0 0 64 64" role="img" aria-label="شعار مسكني">
        <path d="M12 30.5 32 13l20 17.5v20A4.5 4.5 0 0 1 47.5 55h-31a4.5 4.5 0 0 1-4.5-4.5v-20Z" />
        <path d="M24 55V38h16v17" />
        <circle cx="43.5" cy="34.5" r="5.5" />
        <path d="m39.5 38.5-8 8M31.5 46.5h-4v4h-4" />
      </svg>
    </div>
  )
}

function Illustration({
  kind,
}: {
  kind: "welcome" | "search" | "key" | "success" | "business"
}) {
  if (kind === "welcome") {
    return (
      <div className="illustration" aria-hidden="true">
        <svg viewBox="0 0 260 210">
          <path className="soft-fill" d="M56 92 130 32l74 60v83H56Z" />
          <path className="line" d="M46 98 130 29l84 69M63 86v90h134V86" />
          <path className="accent-fill" d="M110 111h40v65h-40z" />
          <path
            className="line-thin"
            d="M77 111h22v25H77zM161 111h22v25h-22z"
          />
          <circle className="accent-line" cx="155" cy="139" r="4" />
          <path className="muted-line" d="M31 176h198" />
        </svg>
      </div>
    )
  }

  if (kind === "search") {
    return (
      <div className="illustration" aria-hidden="true">
        <svg viewBox="0 0 260 210">
          <path
            className="soft-fill"
            d="m38 55 57-18 69 23 58-19v125l-58 19-69-23-57 18Z"
          />
          <path
            className="line-thin"
            d="m95 37v125m69-102v125M46 104l41-13 35 13 35-11"
          />
          <path className="muted-line" d="m172 128 42-14" />
          <path
            className="accent-fill"
            d="M154 79c0-18 13-31 30-31s30 13 30 31c0 23-30 51-30 51s-30-28-30-51Z"
          />
          <circle className="cutout" cx="184" cy="78" r="10" />
          <circle className="accent-line" cx="80" cy="133" r="23" />
          <path className="accent-line" d="m63 150-15 15" />
        </svg>
      </div>
    )
  }

  if (kind === "key") {
    return (
      <div className="illustration" aria-hidden="true">
        <svg viewBox="0 0 260 210">
          <path className="soft-fill" d="M47 93 130 28l83 65v84H47Z" />
          <path className="line" d="M38 99 130 27l92 72M55 86v91h150V86" />
          <circle className="accent-line thick" cx="129" cy="110" r="25" />
          <path
            className="accent-line thick"
            d="m111 128-39 39m0 0H57m15 0v-14H58"
          />
          <path className="muted-line" d="M111 177h111" />
        </svg>
      </div>
    )
  }

  if (kind === "success") {
    return (
      <div className="illustration illustration--success" aria-hidden="true">
        <svg viewBox="0 0 260 210">
          <circle className="soft-fill" cx="130" cy="105" r="74" />
          <circle className="accent-fill" cx="130" cy="105" r="49" />
          <path className="check" d="m103 106 18 18 37-42" />
          <path
            className="muted-line"
            d="M67 47 56 36M190 53l14-14M57 153l-15 8M201 148l17 8"
          />
        </svg>
      </div>
    )
  }

  return (
    <div className="illustration" aria-hidden="true">
      <svg viewBox="0 0 260 210">
        <rect
          className="soft-fill"
          x="45"
          y="46"
          width="170"
          height="122"
          rx="12"
        />
        <path className="line" d="M45 76h170M78 168V98h45v70M140 108h44v60" />
        <path className="accent-fill" d="M61 57h10v10H61zM80 57h10v10H80z" />
        <path
          className="line-thin"
          d="M89 113h23M89 127h23M151 121h22M151 135h22"
        />
        <circle className="accent-fill" cx="193" cy="153" r="31" />
        <path className="check" d="m178 153 10 10 20-23" />
      </svg>
    </div>
  )
}

function PrimaryButton({
  children,
  onClick,
  type = "button",
  disabled = false,
}: {
  children: ReactNode
  onClick?: () => void
  type?: "button" | "submit"
  disabled?: boolean
}) {
  return (
    <button
      className="primary-button"
      type={type}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
      <span className="button-arrow" aria-hidden="true">
        ←
      </span>
    </button>
  )
}

function BackButton({ onClick }: { onClick: () => void }) {
  return (
    <button className="round-button" onClick={onClick} aria-label="رجوع">
      <Icon name="arrow" />
    </button>
  )
}

function Field({
  label,
  icon,
  password = false,
  required = true,
}: {
  label: string
  icon: IconName
  password?: boolean
  required?: boolean
}) {
  const [passwordVisible, setPasswordVisible] = useState(false)

  return (
    <label className="field">
      <span>{label}</span>
      <span className="field-control">
        <Icon name={icon} />
        <input
          type={password && !passwordVisible ? "password" : "text"}
          placeholder={label}
          required={required}
        />
        {password && (
          <button
            className="field-password-toggle"
            type="button"
            onClick={() => setPasswordVisible((current) => !current)}
            aria-label={
              passwordVisible ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"
            }
            aria-pressed={passwordVisible}
          >
            <Icon name="eye" />
          </button>
        )}
      </span>
    </label>
  )
}

function Pagination({ active }: { active: number }) {
  return (
    <div className="pagination" aria-label={`الخطوة ${active + 1} من 3`}>
      {[0, 1, 2].map((dot) => (
        <span key={dot} className={dot === active ? "active" : ""} />
      ))}
    </div>
  )
}

function BrandMini() {
  return (
    <div className="brand-mini">
      <LogoMark />
      <span>مَسْكَنِي</span>
    </div>
  )
}

function Toast({
  title,
  message,
  onClose,
}: {
  title: string
  message: string
  onClose: () => void
}) {
  return (
    <div className="toast" role="status" aria-live="polite">
      <span>✓</span>
      <div>
        <strong>{title}</strong>
        <p>{message}</p>
      </div>
      <button onClick={onClose} aria-label="إغلاق">
        ×
      </button>
    </div>
  )
}

function Onboarding({
  step,
  go,
}: {
  step: number
  go: (screen: number) => void
}) {
  const content = [
    {
      kind: "welcome" as const,
      eyebrow: "اكتشف مكانك",
      title: "أهلاً بك في مسكني",
      body: "وجهتك الواحدة لاكتشاف العقارات والفنادق والشاليهات التي تشبه أحلامك.",
    },
    {
      kind: "search" as const,
      eyebrow: "أقرب مما تتخيل",
      title: "ابحث بذكاء",
      body: "حدّد وجهتك، ميزانيتك، وما تفضّله لنقترح عليك أفضل الأماكن في ثوانٍ.",
    },
    {
      kind: "key" as const,
      eyebrow: "اختيار آمن",
      title: "تواصل بثقة",
      body: "قارن الخيارات، تعرّف على التفاصيل، وتواصل مباشرة مع المالك بخطوات واضحة وآمنة.",
    },
  ][step]

  return (
    <section className="screen">
      <header className="topbar">
        {step < 2 ? (
          <button className="text-button" onClick={() => go(4)}>
            تخطي
          </button>
        ) : (
          <span />
        )}
        {step > 0 ? (
          <button className="text-button muted" onClick={() => go(step)}>
            السابق
          </button>
        ) : (
          <span />
        )}
      </header>
      <main className="onboarding-main">
        <Illustration kind={content.kind} />
        <div className="copy-block">
          <span className="eyebrow">{content.eyebrow}</span>
          <h1>{content.title}</h1>
          <p>{content.body}</p>
        </div>
        <Pagination active={step} />
      </main>
      <footer className="screen-footer">
        <PrimaryButton onClick={() => go(step === 2 ? 4 : step + 2)}>
          {step === 2 ? "ابدأ الآن" : "التالي"}
        </PrimaryButton>
        <div className="auth-links">
          <button onClick={() => go(4)}>تسجيل الدخول</button>
          <span />
          <button onClick={() => go(5)}>إنشاء حساب</button>
        </div>
      </footer>
    </section>
  )
}

type AuthHeaderProps = {
  title: string
  subtitle: string
}

function AuthHeader({ title, subtitle }: AuthHeaderProps) {
  return (
    <>
      <header className="topbar auth-topbar">
        <BrandMini />
      </header>
      <div className="auth-heading">
        <span className="eyebrow">مرحباً بعودتك</span>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
    </>
  )
}

function Login({
  go,
  setAccountType,
}: {
  go: (screen: number) => void
  setAccountType: (type: number) => void
}) {
  const submit = (event: FormEvent) => {
    event.preventDefault()
    setAccountType(0)
    go(6)
  }

  return (
    <section className="screen scrollable">
      <AuthHeader
        title="تسجيل الدخول"
        subtitle="سجّل دخولك لتكمل رحلتك من حيث توقفت."
      />
      <form className="auth-form" onSubmit={submit}>
        <Field label="البريد الإلكتروني أو الهاتف" icon="mail" />
        <Field label="كلمة المرور" icon="lock" password />
        <div className="options-row">
          <label className="check-label">
            <input type="checkbox" defaultChecked />
            <span className="custom-check">✓</span>
            تذكرني
          </label>
          <button type="button" className="link-button" onClick={() => go(7)}>
            هل نسيت كلمة المرور؟
          </button>
        </div>
        <PrimaryButton type="submit">دخول</PrimaryButton>
      </form>
      <p className="auth-switch">
        ليس لديك حساب؟ <button onClick={() => go(5)}>إنشاء حساب</button>
      </p>
    </section>
  )
}

const accountTypes = [
  "مستخدم عادي",
  "مالك شخصي",
  "مالك مكتب",
  "فندق",
  "شاليهات",
]

function SignUp({
  go,
  accountType,
  setAccountType,
}: {
  go: (screen: number) => void
  accountType: number
  setAccountType: (type: number) => void
}) {
  const submit = (event: FormEvent) => {
    event.preventDefault()
    go(6)
  }

  return (
    <section className="screen scrollable">
      <AuthHeader
        title="إنشاء حساب جديد"
        subtitle="خطوة واحدة تفصلك عن تجربة مسكني."
      />
      <form className="auth-form signup-form" onSubmit={submit}>
        <fieldset className="account-picker">
          <legend>نوع الحساب</legend>
          <div>
            {accountTypes.map((type, index) => (
              <button
                key={type}
                type="button"
                className={accountType === index ? "selected" : ""}
                onClick={() => setAccountType(index)}
              >
                {type}
              </button>
            ))}
          </div>
        </fieldset>
        <Field label="الاسم الكامل" icon="user" />
        <Field label="رقم الهاتف أو البريد" icon="phone" />
        <Field label="كلمة المرور" icon="lock" password />
        <Field label="تأكيد كلمة المرور" icon="lock" password />
        <PrimaryButton type="submit">تسجيل</PrimaryButton>
      </form>
      <p className="auth-switch">
        لديك حساب بالفعل؟ <button onClick={() => go(4)}>تسجيل الدخول</button>
      </p>
    </section>
  )
}

function Otp({
  go,
  isPartner,
}: {
  go: (screen: number) => void
  isPartner: boolean
}) {
  const [showToast, setShowToast] = useState(false)
  const [digits, setDigits] = useState(["", "", "", ""])
  const [seconds, setSeconds] = useState(42)

  useEffect(() => {
    if (seconds <= 0) return
    const timer = window.setTimeout(
      () => setSeconds((current) => current - 1),
      1000,
    )
    return () => window.clearTimeout(timer)
  }, [seconds])

  const resendCode = () => {
    if (seconds > 0) return
    setDigits(["", "", "", ""])
    setSeconds(42)
    setShowToast(true)
    window.setTimeout(() => setShowToast(false), 3200)
  }

  return (
    <section className="screen">
      <header className="topbar auth-topbar">
        <BrandMini />
      </header>
      <main className="otp-main">
        <div className="otp-symbol">
          <Icon name="mail" />
          <span>✓</span>
        </div>
        <div className="auth-heading centered">
          <span className="eyebrow">تأكيد الهوية</span>
          <h1>رمز التحقق</h1>
          <p>تم إرسال رمز التحقق إلى رقم هاتفك أو بريدك الإلكتروني</p>
          <b>m••••@mail.com</b>
        </div>
        <div className="otp-inputs" dir="ltr">
          {digits.map((digit, index) => (
            <input
              key={index}
              value={digit}
              onChange={(event) => {
                const value = event.target.value.replace(/\D/g, "").slice(-1)
                setDigits((current) =>
                  current.map((item, itemIndex) =>
                    itemIndex === index ? value : item,
                  ),
                )
                if (value) {
                  const nextInput =
                    event.currentTarget.parentElement?.querySelectorAll(
                      "input",
                    )[index + 1]
                  nextInput?.focus()
                }
              }}
              inputMode="numeric"
              autoComplete={index === 0 ? "one-time-code" : "off"}
              maxLength={1}
              aria-label={`الرقم ${index + 1}`}
            />
          ))}
        </div>
        <p className="resend">
          يمكنك إعادة الإرسال خلال{" "}
          <strong dir="ltr">00:{String(seconds).padStart(2, "0")}</strong>
        </p>
        <button
          className="link-button"
          onClick={resendCode}
          disabled={seconds > 0}
        >
          إعادة إرسال الرمز
        </button>
      </main>
      <footer className="screen-footer">
        <PrimaryButton
          onClick={() => go(isPartner ? 11 : 10)}
          disabled={digits.some((digit) => !digit)}
        >
          تحقق وتأكيد
        </PrimaryButton>
      </footer>
      {showToast && (
        <Toast
          title="تم الإرسال بنجاح"
          message="تم إرسال رمز التحقق بنجاح إلى هاتفك"
          onClose={() => setShowToast(false)}
        />
      )}
    </section>
  )
}

function PasswordRecovery({ go }: { go: (screen: number) => void }) {
  const [showToast, setShowToast] = useState(false)

  const submit = (event: FormEvent) => {
    event.preventDefault()
    if (showToast) return
    setShowToast(true)
    window.setTimeout(() => go(8), 1500)
  }

  return (
    <section className="screen">
      <header className="topbar recovery-topbar">
        <BackButton onClick={() => go(4)} />
        <BrandMini />
      </header>
      <main className="recovery-main">
        <div className="recovery-symbol">
          <Icon name="lock" />
          <span>?</span>
        </div>
        <div className="auth-heading">
          <span className="eyebrow">استعادة الحساب</span>
          <h1>إعادة تعيين كلمة المرور</h1>
          <p>أدخل بريدك الإلكتروني أو رقم هاتفك لإرسال تعليمات الاستعادة</p>
        </div>
        <form className="auth-form recovery-form" onSubmit={submit}>
          <Field label="البريد الإلكتروني أو الهاتف" icon="mail" />
          <PrimaryButton type="submit">إرسال تعليمات الاستعادة</PrimaryButton>
        </form>
      </main>
      <p className="auth-switch">
        تذكرت كلمة المرور؟ <button onClick={() => go(4)}>تسجيل الدخول</button>
      </p>
      {showToast && (
        <Toast
          title="تم إرسال كلمة المرور"
          message="تم إرسال كلمة مرور مؤقتة لرقم الهاتف أو البريد"
          onClose={() => setShowToast(false)}
        />
      )}
    </section>
  )
}

function TemporaryPassword({ go }: { go: (screen: number) => void }) {
  const submit = (event: FormEvent) => {
    event.preventDefault()
    go(9)
  }

  return (
    <section className="screen">
      <header className="topbar recovery-topbar">
        <BackButton onClick={() => go(7)} />
        <BrandMini />
      </header>
      <main className="recovery-main">
        <div className="recovery-symbol">
          <Icon name="mail" />
          <span>✓</span>
        </div>
        <div className="auth-heading">
          <span className="eyebrow">تحقق آمن</span>
          <h1>أدخل كلمة المرور المؤقتة</h1>
          <p>
            أدخل كلمة المرور التي أرسلناها إلى رقم هاتفك أو بريدك الإلكتروني.
          </p>
        </div>
        <form className="auth-form recovery-form" onSubmit={submit}>
          <Field label="كلمة المرور المؤقتة" icon="lock" password />
          <PrimaryButton type="submit">تأكيد</PrimaryButton>
        </form>
      </main>
      <p className="auth-switch">
        لم تصلك الرسالة؟ <button onClick={() => go(7)}>إعادة الإرسال</button>
      </p>
    </section>
  )
}

function NewPassword({
  go,
  isPartner,
}: {
  go: (screen: number) => void
  isPartner: boolean
}) {
  const submit = (event: FormEvent) => {
    event.preventDefault()
    go(isPartner ? 11 : 10)
  }

  return (
    <section className="screen">
      <header className="topbar recovery-topbar">
        <BackButton onClick={() => go(8)} />
        <BrandMini />
      </header>
      <main className="recovery-main">
        <div className="recovery-symbol">
          <Icon name="lock" />
          <span>✓</span>
        </div>
        <div className="auth-heading">
          <span className="eyebrow">حماية حسابك</span>
          <h1>إنشاء كلمة مرور جديدة</h1>
          <p>اختر كلمة مرور قوية وجديدة للحفاظ على أمان حسابك.</p>
        </div>
        <form className="auth-form recovery-form" onSubmit={submit}>
          <Field label="كلمة المرور الجديدة" icon="lock" password />
          <Field label="تأكيد كلمة المرور" icon="lock" password />
          <PrimaryButton type="submit">حفظ وتغيير</PrimaryButton>
        </form>
      </main>
    </section>
  )
}

function Welcome({
  partner,
  go,
}: {
  partner: boolean
  go: (screen: number) => void
}) {
  return (
    <section className="screen welcome-screen">
      <header className="topbar auth-topbar">
        <BrandMini />
      </header>
      <main className="welcome-main">
        <Illustration kind={partner ? "business" : "success"} />
        <div className="copy-block">
          <span className="success-pill">تم التفعيل بنجاح</span>
          <h1>{partner ? "أهلاً بك شريك النجاح!" : "تم تفعيل حسابك بنجاح!"}</h1>
          <p>
            {partner
              ? "ابدأ الآن بإضافة عقارك الأول، إدارة حجوزاتك، ومضاعفة أرباحك بكل سهولة."
              : "أنت جاهز الآن لاستكشاف أفضل العقارات والفنادق والشاليهات، وتواصل مباشرة مع المالك."}
          </p>
        </div>
      </main>
      <footer className="screen-footer">
        <PrimaryButton onClick={() => go(partner ? 24 : 12)}>
          {partner ? "وثق حسابك" : "ابدأ التصفح الآن"}
        </PrimaryButton>
        <p className="safe-note">
          <span>✓</span> تجربة آمنة وموثوقة مع مسكني
        </p>
      </footer>
    </section>
  )
}

type NavigationItem = {
  label: string
  icon: IconName
}

type DrawerItem = NavigationItem & {
  hint?: string
  target: number
}

const categories: NavigationItem[] = [
  { label: "المنازل والشقق", icon: "building" },
  { label: "المحلات التجارية", icon: "shop" },
  { label: "الفنادق", icon: "hotel" },
  { label: "الشاليهات", icon: "chalet" },
  { label: "الأراضي", icon: "land" },
]

const bottomNav: (NavigationItem & { target: number })[] = [
  { label: "الرئيسية", icon: "home", target: 12 },
  { label: "طلباتي", icon: "calendar", target: 29 },
  { label: "العروض المميزة", icon: "star", target: 45 },
  { label: "الرسائل", icon: "chat", target: 35 },
  { label: "حسابي", icon: "user", target: 13 },
]
const drawerGroups: {
  title: string
  items: DrawerItem[]
}[] = [
  {
    title: "روابط سريعة",
    items: [
      { label: "المفضلة", icon: "heart", target: 37 },
      { label: "قائمة المتابعة", icon: "heart", target: 25 },
    ],
  },
  {
    title: "الدعم والمساعدة",
    items: [
      { label: "المساعدة والتواصل", icon: "help", target: 32 },
      { label: "اقتراحات لتطوير المنصة", icon: "chat", target: 20 },
      { label: "حول المنصة", icon: "help", target: 21 },
      { label: "الشروط والأحكام", icon: "document", target: 33 },
    ],
  },
]

function Home({
  go,
  onSearch,
  onOpenFilters,
  onViewAll,
}: {
  go: (screen: number) => void
  onSearch: (query: string) => void
  onOpenFilters: () => void
  onViewAll: () => void
}) {
  const [query, setQuery] = useState("")
  const [darkMode, setDarkMode] = useState(() => {
    const storedTheme = window.localStorage.getItem("maskani-theme")
    if (storedTheme) return storedTheme === "dark"
    return (
      document.documentElement.dataset.theme === "dark" ||
      (!document.documentElement.dataset.theme &&
        window.matchMedia("(prefers-color-scheme: dark)").matches)
    )
  })

  useEffect(() => {
    const theme = darkMode ? "dark" : "light"
    document.documentElement.dataset.theme = theme
    window.localStorage.setItem("maskani-theme", theme)
  }, [darkMode])

  return (
    <section className="screen home-screen">
      <header className="home-header">
        <div className="home-actions">
          <button
            className="notification-button"
            onClick={() => go(15)}
            aria-label="الإشعارات"
          >
            <Icon name="bell" />
            <span />
          </button>
          <button
            className="mode-toggle"
            onClick={() => setDarkMode((current) => !current)}
            aria-label={darkMode ? "تفعيل الوضع الفاتح" : "تفعيل الوضع الداكن"}
            aria-pressed={darkMode}
          >
            <Icon name={darkMode ? "sun" : "moon"} />
          </button>
        </div>
        <BrandMini />
      </header>

      <main className="home-content">
        <div className="home-greeting">
          <p>أهلاً بك، محمد</p>
          <h1>أين تريد أن تسكن اليوم؟</h1>
        </div>

        <form
          className="search-row"
          onSubmit={(event) => {
            event.preventDefault()
            onSearch(query)
          }}
        >
          <label className="home-search">
            <Icon name="search" />
            <input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="ابحث عن عقارك أو وجهتك..."
              aria-label="البحث عن عقار أو وجهة"
            />
          </label>
          <button
            className="filter-button"
            type="button"
            onClick={onOpenFilters}
            aria-label="خيارات التصفية"
          >
            <Icon name="filter" />
          </button>
        </form>

        <div className="section-heading">
          <h2>تصفح حسب الفئة</h2>
          <button onClick={onViewAll}>عرض الكل</button>
        </div>

        <div className="category-grid">
          {categories.map((category, index) => (
            <button
              key={category.label}
              className="category-card"
              onClick={() =>
                go(
                  index === 0
                    ? 14
                    : index === 1
                      ? 41
                      : index === 2
                        ? 43
                        : index === 3
                          ? 44
                        : index === 4
                          ? 42
                          : 39,
                )
              }
            >
              <span>
                <Icon name={category.icon} />
              </span>
              <b>{category.label}</b>
            </button>
          ))}
        </div>
      </main>

      <div className="home-bottom">
        <button className="ai-fab" onClick={() => go(17)}>
          <Icon name="sparkles" />
          ابحث بالذكاء الاصطناعي
        </button>
        <nav className="bottom-nav" aria-label="التنقل الرئيسي">
  {bottomNav.map((item, index) => (
    <button
      key={item.label}
      className={index === 0 ? "active" : ""}
      onClick={() => go(item.target)}
    >
      <Icon name={item.icon} />
      <span>{item.label}</span>
    </button>
  ))}
</nav>
      </div>
    </section>
  )
}

function AccountScreen({ go }: { go: (screen: number) => void }) {
  const [shareNotice, setShareNotice] = useState(false)

  const shareApp = async () => {
    const shareData = {
      title: "مسكني",
      text: "اكتشف أفضل العقارات والفنادق والشاليهات مع مسكني",
    }

    try {
      if (!navigator.share) throw new Error("Web Share is unavailable")
      await navigator.share(shareData)
    } catch {
      try {
        await navigator.clipboard?.writeText(
          `${shareData.title} — ${shareData.text}`,
        )
      } catch {
        // Clipboard access can also be restricted inside embedded previews.
      }
      setShareNotice(true)
      window.setTimeout(() => setShareNotice(false), 2800)
    }
  }

  return (
    <section className="screen account-screen">
      <header className="account-header">
        <div>
          <span>الملف الشخصي</span>
          <h1>حسابي</h1>
        </div>
        <BrandMini />
      </header>
      <main className="account-page-content">
        <button className="account-primary-setting" onClick={() => go(30)}>
          <span>
            <Icon name="user" />
          </span>
          <div>
            <strong>الملف الشخصي</strong>
            <small>بياناتك الشخصية ومعلومات التواصل</small>
          </div>
          <Icon name="chevron" />
        </button>

        <section className="account-menu-group account-settings-group">
          <h2>الإعدادات</h2>
          <div>
            <button className="account-menu-item" onClick={() => go(27)}>
              <span>
                <Icon name="shield" />
              </span>
              <b>إدارة وأمان الحساب</b>
              <small>الحماية والحسابات المرتبطة</small>
              <Icon name="chevron" />
            </button>
            <button className="account-menu-item" onClick={() => go(24)}>
              <span>
                <Icon name="shield" />
              </span>
              <b>توثيق الحساب</b>
              <small>توثيق الهوية</small>
              <Icon name="chevron" />
            </button>
            <button className="account-menu-item" onClick={() => go(28)}>
              <span>
                <Icon name="globe" />
              </span>
              <b>اللغة</b>
              <small>العربية</small>
              <Icon name="chevron" />
            </button>
            <button className="account-menu-item" onClick={() => go(26)}>
              <span>
                <Icon name="userPlus" />
              </span>
              <b>انضم إلينا كشريك/مالك</b>
              <small>حوّل حسابك إلى حساب شريك</small>
              <Icon name="chevron" />
            </button>
          </div>
        </section>

        <div className="account-menu">
          {drawerGroups.map((group) => (
            <section className="account-menu-group" key={group.title}>
              <h2>{group.title}</h2>
              <div>
                {group.items.map((item) => (
                  <button
                    className="account-menu-item"
                    key={item.label}
                    onClick={() => go(item.target)}
                  >
                    <span>
                      <Icon name={item.icon} />
                    </span>
                    <b>{item.label}</b>
                    {item.hint && <small>{item.hint}</small>}
                    <Icon name="chevron" />
                  </button>
                ))}
              </div>
            </section>
          ))}
        </div>

        <div className="account-page-actions">
          <button onClick={() => go(4)}>
            <Icon name="logout" />
            تسجيل الخروج
          </button>
          <button className="share-action" onClick={() => void shareApp()}>
            <Icon name="share" />
            مشاركة التطبيق
          </button>
        </div>
      </main>
      <nav
        className="bottom-nav account-bottom-nav"
        aria-label="التنقل الرئيسي"
      >
        {bottomNav.map((item, index) => (
          <button
            key={item.label}
            className={index === 4 ? "active" : ""}
            onClick={() => go(item.target)}
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
      {shareNotice && (
        <div className="account-share-notice" role="status">
          <span>✓</span>
          تم تجهيز معلومات المشاركة
        </div>
      )}
    </section>
  )
}

function PageHeader({
  title,
  go,
}: {
  title: string
  go: (screen: number) => void
}) {
  return (
    <header className="page-header">
      <BackButton onClick={() => go(-1)} />
      <h1>{title}</h1>
      <span />
    </header>
  )
}

function Placeholder({
  go,
  isPartner = false,
}: {
  go: (screen: number) => void
  isPartner?: boolean
}) {
  return (
    <section className="screen feature-screen">
      {!isPartner && <PageHeader title="قيد التطوير" go={go} />}
      <main className="placeholder-main">
        <div className="wip-illustration" aria-hidden="true">
          <span className="wip-orbit" />
          <Icon name="settings" />
          <i>•••</i>
        </div>
        <span className="eyebrow">
          {isPartner ? "حساب شريك / مالك" : "نعمل عليها الآن"}
        </span>
        <h1>
          {isPartner ? "واجهات الملاك قيد التطوير" : "هذه الميزة قيد التصميم"}
        </h1>
        <p>
          {isPartner
            ? "تم استلام بياناتك بنجاح وستتم مراجعتها لتفعيل حسابك. لوحة التحكم الخاصة بالملاك قيد التطوير حالياً."
            : "نجهّز لك تجربة أفضل وأكثر سهولة. ستتوفر هذه الميزة قريباً في مسكني."}
        </p>
      </main>
      {!isPartner && (
        <footer className="screen-footer">
          <PrimaryButton onClick={() => go(12)}>العودة للرئيسية</PrimaryButton>
        </footer>
      )}
    </section>
  )
}

const notificationItems: {
  title: string
  body: string
  time: string
  icon: IconName
  target: "requests" | "property"
}[] = [
  {
    title: "عقار جديد مطابق لبحثك",
    body: "تمت إضافة شقة جديدة في حدة تطابق تفضيلاتك.",
    time: "قبل 5 دقائق",
    icon: "building",
    target: "property",
  },
  {
    title: "رسالة جديدة من مالك",
    body: "أحمد القاسمي رد على استفسارك بخصوص الشقة.",
    time: "قبل ساعة",
    icon: "chat",
    target: "property",
  },
  {
    title: "تحديث على طلبك العقاري",
    body: "تم العثور على خيارات جديدة تطابق طلبك المخصص في عدن.",
    time: "أمس",
    icon: "calendar",
    target: "requests",
  },
  {
    title: "عرض جديد في منطقتك",
    body: "شاليه عائلي في عدن أصبح متاحاً للحجز اليومي.",
    time: "قبل يومين",
    icon: "tag",
    target: "property",
  },
]

function Notifications({
  go,
  onOpenProperty,
}: {
  go: (screen: number) => void
  onOpenProperty: (property: Property) => void
}) {
  return (
    <section className="screen feature-screen">
      <PageHeader title="الإشعارات" go={go} />
      <main className="feature-content">
        <button className="notification-settings-link" onClick={() => go(31)}>
          <span>
            <Icon name="settings" />
          </span>
          <div>
            <strong>إعدادات الإشعارات</strong>
            <small>تحكّم في أنواع التنبيهات التي تصلك</small>
          </div>
          <Icon name="chevron" />
        </button>

        <div className="notification-list">
          {notificationItems.map((item) => (
            <button
              className="notification-card"
              key={item.title}
              onClick={() =>
                item.target === "requests"
                  ? go(29)
                  : onOpenProperty(properties[0])
              }
            >
              <span className="notification-icon">
                <Icon name={item.icon} />
              </span>
              <div>
                <strong>{item.title}</strong>
                <p>{item.body}</p>
                <small>{item.time}</small>
              </div>
              <i />
            </button>
          ))}
        </div>
      </main>
    </section>
  )
}

type SearchFilterState = {
  propertyType: string
  governorate: string
  district: string
  neighborhood: string
  manualLocation: string
  nearMe: boolean
  currency: string
  minPrice: string
  maxPrice: string
  purpose: string
  payment: string
  furnishing: string
  bedrooms: number
  bathrooms: number
  halls: number
  kitchens: number
  propertyAge: string
  infrastructure: string[]
  amenities: string[]
  landType: string
  areaMin: string
  areaMax: string
  frontage: string[]
  streetWidth: string
  commercialType: string
  shopLocation: string
  finishing: string
  starRating: number
  roomCategory: string
  bedCount: number
  bedType: string
  capacity: number
  privacy: string
}

type SearchFilterContext =
  | "all"
  | "residential"
  | "commercial"
  | "land"
  | "hotel"
  | "chalet"

const createDefaultFilters = (): SearchFilterState => ({
  propertyType: "",
  governorate: "",
  district: "",
  neighborhood: "",
  manualLocation: "",
  nearMe: false,
  currency: "",
  minPrice: "",
  maxPrice: "",
  purpose: "",
  payment: "",
  furnishing: "",
  bedrooms: 0,
  bathrooms: 0,
  halls: 0,
  kitchens: 0,
  propertyAge: "",
  infrastructure: [],
  amenities: [],
  landType: "",
  areaMin: "",
  areaMax: "",
  frontage: [],
  streetWidth: "",
  commercialType: "",
  shopLocation: "",
  finishing: "",
  starRating: 0,
  roomCategory: "",
  bedCount: 0,
  bedType: "",
  capacity: 0,
  privacy: "",
})

function ChoiceGroup({
  options,
  value,
  onChange,
}: {
  options: string[]
  value: string
  onChange: (value: string) => void
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((option) => (
        <button
          className={`rounded-full border px-3 py-2 text-[10px] font-bold transition ${
            value === option
              ? "border-[var(--primary)] bg-[var(--primary-strong)] text-[var(--dark-text)]"
              : "border-[var(--line)] bg-[var(--surface)] text-[var(--text-muted)]"
          }`}
          key={option}
          onClick={() => onChange(value === option ? "" : option)}
          type="button"
        >
          {option}
        </button>
      ))}
    </div>
  )
}

function CheckGroup({
  options,
  values,
  onChange,
}: {
  options: string[]
  values: string[]
  onChange: (values: string[]) => void
}) {
  return (
    <div className="flex w-full min-w-0 flex-wrap gap-2">
      {options.map((option) => {
        const checked = values.includes(option)
        return (
          <label
            className={`inline-flex cursor-pointer items-center gap-2 rounded-full border px-3 py-2 text-[10px] font-semibold transition ${
              checked
                ? "border-[var(--primary)] bg-[var(--primary-strong)] text-[var(--dark-text)]"
                : "border-[var(--line)] bg-[var(--surface)] text-[var(--text)]"
            }`}
            key={option}
          >
            <input
              className="sr-only"
              type="checkbox"
              checked={checked}
              onChange={() =>
                onChange(
                  checked
                    ? values.filter((item) => item !== option)
                    : [...values, option],
                )
              }
            />
            <span
              className={`grid size-4 shrink-0 place-items-center rounded-full border ${
                checked
                  ? "border-[var(--dark-text)] bg-[var(--dark-text)] text-[var(--primary-strong)]"
                  : "border-[var(--line-strong)] bg-[var(--surface-raised)] text-[var(--transparent)]"
              }`}
            >
              ✓
            </span>
            <span className="whitespace-nowrap text-[10px] leading-5">
              {option}
            </span>
          </label>
        )
      })}
    </div>
  )
}
function DualRangeSlider({
  minValue,
  maxValue,
  min,
  max,
  step,
  unit,
  onChange,
}: {
  minValue: string
  maxValue: string
  min: number
  max: number
  step: number
  unit: string
  onChange: (minValue: string, maxValue: string) => void
}) {
  const selectedMin = minValue === "" ? min : Number(minValue)
  const selectedMax = maxValue === "" ? max : Number(maxValue)
  const formatValue = (value: number) =>
    `${value.toLocaleString("ar-SA")} ${unit}`.trim()

  return (
    <div className="w-full min-w-0 space-y-4">
      <label className="block min-w-0">
        <span className="mb-2 flex items-center justify-between gap-2 text-[10px] text-[var(--text-muted)]">
          <b className="text-[var(--text)]">الحد الأدنى</b>
          <span>{formatValue(selectedMin)}</span>
        </span>
        <input
          className="dual-range-input"
          type="range"
          min={min}
          max={max}
          step={step}
          value={selectedMin}
          onChange={(event) =>
            onChange(
              String(Math.min(Number(event.target.value), selectedMax)),
              String(selectedMax),
            )
          }
          dir="ltr"
        />
      </label>
      <label className="block min-w-0">
        <span className="mb-2 flex items-center justify-between gap-2 text-[10px] text-[var(--text-muted)]">
          <b className="text-[var(--text)]">الحد الأعلى</b>
          <span>{formatValue(selectedMax)}</span>
        </span>
        <input
          className="dual-range-input"
          type="range"
          min={min}
          max={max}
          step={step}
          value={selectedMax}
          onChange={(event) =>
            onChange(
              String(selectedMin),
              String(Math.max(Number(event.target.value), selectedMin)),
            )
          }
          dir="ltr"
        />
      </label>
    </div>
  )
}

function FilterCounter({
  label,
  value,
  onChange,
}: {
  label: string
  value: number
  onChange: (value: number) => void
}) {
  return (
    <div className="flex items-center justify-between rounded-xl border border-[var(--line)] bg-[var(--surface)] p-3">
      <span className="text-[11px] font-bold text-[var(--text)]">{label}</span>
      <div className="flex items-center gap-3">
        <button
          className="grid size-8 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-raised)] text-[var(--text)]"
          onClick={() => onChange(Math.max(0, value - 1))}
          type="button"
        >
          −
        </button>
        <strong className="min-w-5 text-center text-sm text-[var(--text)]">
          {value || "أي"}
        </strong>
        <button
          className="grid size-8 place-items-center rounded-full bg-[var(--primary-strong)] text-[var(--dark-text)]"
          onClick={() => onChange(Math.min(20, value + 1))}
          type="button"
        >
          +
        </button>
      </div>
    </div>
  )
}

function FilterSection({
  title,
  children,
}: {
  title: string
  children: React.ReactNode
}) {
  return (
    <section className="w-full min-w-0 overflow-hidden rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-4">
      <h2 className="mb-3 text-xs font-extrabold text-[var(--text)]">
        {title}
      </h2>
      {children}
    </section>
  )
}

function SearchFilters({
  go,
  filters,
  setFilters,
  onApply,
  context,
}: {
  go: (screen: number) => void
  filters: SearchFilterState
  setFilters: React.Dispatch<React.SetStateAction<SearchFilterState>>
  onApply: () => void
  context: SearchFilterContext
}) {
  const [locationMessage, setLocationMessage] = useState("")
  const update = <K extends keyof SearchFilterState,>(
    key: K,
    value: SearchFilterState[K],
  ) => setFilters((current) => ({ ...current, [key]: value }))
  const resetFilters = () =>
    setFilters({
      ...createDefaultFilters(),
      propertyType:
        context === "commercial"
          ? "محلات"
          : context === "land"
            ? "أرض"
            : context === "hotel"
              ? "فندق"
              : context === "chalet"
                ? "شاليه"
                : "",
    })

  const governorates = [
    ...new Set(properties.map((item) => item.location.governorate)),
  ]
  const districts = [
    ...new Set(
      properties
        .filter(
          (item) =>
            !filters.governorate ||
            item.location.governorate === filters.governorate,
        )
        .map((item) => item.location.district),
    ),
  ]
  const neighborhoods = [
    ...new Set(
      properties
        .filter(
          (item) =>
            (!filters.governorate ||
              item.location.governorate === filters.governorate) &&
            (!filters.district || item.location.district === filters.district),
        )
        .map((item) => item.location.neighborhood)
        .filter((item): item is string => Boolean(item)),
    ),
  ]

  const requestLocation = () => {
    if (!navigator.geolocation) {
      setLocationMessage("خدمة الموقع غير متاحة على هذا الجهاز")
      return
    }
    setLocationMessage("جارٍ تحديد موقعك...")
    navigator.geolocation.getCurrentPosition(
      () => {
        update("nearMe", true)
        setLocationMessage(
          "تم السماح بالموقع، ولا تتوفر إحداثيات للعقارات الحالية للمقارنة الدقيقة",
        )
      },
      () => {
        update("nearMe", false)
        setLocationMessage(
          "تعذر الوصول إلى موقعك. يمكنك اختيار الموقع أو كتابته يدوياً",
        )
      },
      { enableHighAccuracy: false, timeout: 8000 },
    )
  }

  const residential =
    context === "residential" ||
    ["شقة", "منازل مستقلة", "فلل"].includes(filters.propertyType)
  const propertyTypes =
    context === "residential"
      ? ["شقة", "منازل مستقلة", "فلل"]
      : context === "commercial"
        ? ["محلات"]
        : context === "land"
          ? ["أرض"]
          : context === "hotel"
            ? ["فندق"]
            : context === "chalet"
              ? ["شاليه"]
              : ["شقة", "منازل مستقلة", "فلل", "أرض", "محلات", "فندق", "شاليه"]
  const inputClass =
    "h-11 w-full rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 text-xs text-[var(--text)] outline-none focus:border-[var(--primary)]"
  const priceRange =
    filters.currency === "ريال يمني"
      ? { max: 100000000, step: 500000, unit: "ر.ي" }
      : filters.currency === "ريال سعودي"
        ? { max: 20000, step: 100, unit: "ر.س" }
        : { max: 20000, step: 100, unit: filters.currency ? "$" : "" }

  return (
    <section className="screen flex h-full min-h-0 flex-col !bg-[var(--surface-soft)] !text-[var(--text)]">
      <header className="grid shrink-0 grid-cols-3 items-center border-b border-[var(--line)] bg-[var(--surface-raised)] px-4 pb-3 pt-9">
        <button
          className="grid size-10 justify-self-start place-items-center rounded-full border border-[var(--line)]"
          onClick={() => go(-1)}
          aria-label="رجوع"
        >
          <Icon name="arrow" />
        </button>
        <h1 className="text-center text-base font-extrabold">
          {context === "residential"
            ? "تصفية المنازل والشقق"
            : context === "commercial"
              ? "تصفية المحلات التجارية"
              : context === "land"
                ? "تصفية الأراضي"
                : context === "hotel"
                  ? "تصفية الفنادق"
                  : context === "chalet"
                    ? "تصفية الشاليهات"
                    : "تصفية البحث"}
        </h1>
        <button
          className="justify-self-end text-xs font-bold text-[var(--primary-text)]"
          onClick={resetFilters}
        >
          إعادة ضبط
        </button>
      </header>

      <main
        className="w-full min-w-0 flex-1 space-y-3 overflow-x-hidden overflow-y-auto overscroll-contain px-4 pb-4 pt-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        style={{ minHeight: 0 }}
      >
        <FilterSection title="الموقع">
          <div className="grid grid-cols-3 gap-2">
            <select
              className={inputClass}
              value={filters.governorate}
              onChange={(event) =>
                setFilters((current) => ({
                  ...current,
                  governorate: event.target.value,
                  district: "",
                  neighborhood: "",
                }))
              }
              aria-label="المحافظة"
            >
              <option value="">المحافظة</option>
              {governorates.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
            <select
              className={inputClass}
              value={filters.district}
              onChange={(event) =>
                setFilters((current) => ({
                  ...current,
                  district: event.target.value,
                  neighborhood: "",
                }))
              }
              aria-label="المديرية"
            >
              <option value="">المديرية</option>
              {districts.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
            <select
              className={inputClass}
              value={filters.neighborhood}
              onChange={(event) => update("neighborhood", event.target.value)}
              aria-label="الحي"
            >
              <option value="">الحي</option>
              {neighborhoods.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </div>
          <input
            className={`${inputClass} mt-2`}
            value={filters.manualLocation}
            onChange={(event) => update("manualLocation", event.target.value)}
            placeholder="الإدخال اليدوي الحر — اكتب الحي أو المكان"
          />
          <button
            className={`mt-2 flex w-full items-center justify-center gap-2 rounded-xl border p-3 text-xs font-bold ${
              filters.nearMe
                ? "border-[var(--primary)] bg-[var(--primary-strong)] text-[var(--dark-text)]"
                : "border-[var(--line)] bg-[var(--primary-soft)] text-[var(--primary-text)]"
            }`}
            onClick={requestLocation}
            type="button"
          >
            <Icon name="pin" />
            {filters.nearMe ? "تم تحديد موقعي" : "بالقرب مني"}
          </button>
          {locationMessage && (
            <p
              className="mt-2 text-[10px] leading-5 text-[var(--text-muted)]"
              role="status"
            >
              {locationMessage}
            </p>
          )}
        </FilterSection>

        <FilterSection title="عملة العرض">
          <ChoiceGroup
            options={["ريال يمني", "ريال سعودي", "دولار أمريكي"]}
            value={filters.currency}
            onChange={(value) =>
              setFilters((current) => ({
                ...current,
                currency: value,
                minPrice: "",
                maxPrice: "",
              }))
            }
          />
          <p className="mt-2 text-[9px] leading-5 text-[var(--text-muted)]">
            لا يتم تحويل العملات دون توفر سعر صرف موثوق؛ تظهر النتائج بعملتها
            الأصلية.
          </p>
        </FilterSection>

        <FilterSection
          title={`نطاق السعر — ${filters.currency || "العملة الأصلية"}`}
        >
          {filters.currency ? (
            <DualRangeSlider
              minValue={filters.minPrice}
              maxValue={filters.maxPrice}
              min={0}
              max={priceRange.max}
              step={priceRange.step}
              unit={priceRange.unit}
              onChange={(minValue, maxValue) =>
                setFilters((current) => ({
                  ...current,
                  minPrice: minValue,
                  maxPrice: maxValue,
                }))
              }
            />
          ) : (
            <p className="rounded-xl bg-[var(--surface-soft)] p-3 text-[10px] leading-5 text-[var(--text-muted)]">
              اختر عملة العرض أولاً لتحديد نطاق سعر دقيق دون خلط العملات.
            </p>
          )}
        </FilterSection>

        <section>
          <h2 className="mb-2 text-xs font-extrabold">نوع العقار</h2>
          <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 [scrollbar-width:none]">
            {propertyTypes.map((type) => (
              <button
                className={`shrink-0 rounded-full border px-4 py-2 text-xs font-bold ${
                  filters.propertyType === type
                    ? "border-[var(--primary)] bg-[var(--primary-strong)] text-[var(--dark-text)]"
                    : "border-[var(--line)] bg-[var(--surface-raised)] text-[var(--text)]"
                }`}
                key={type}
                onClick={() =>
                  update(
                    "propertyType",
                    context === "commercial" ||
                    context === "land" ||
                    context === "hotel" ||
                    context === "chalet"
                      ? type
                      : filters.propertyType === type
                        ? ""
                        : type,
                  )
                }
                aria-pressed={filters.propertyType === type}
              >
                {type}
              </button>
            ))}
          </div>
        </section>

        {residential && (
          <>
            <FilterSection title="الغرض">
              <ChoiceGroup
                options={["للبيع", "للإيجار"]}
                value={filters.purpose}
                onChange={(value) => update("purpose", value)}
              />
            </FilterSection>
            <FilterSection title="طريقة الدفع">
              <ChoiceGroup
                options={["كاش", "تقسيط"]}
                value={filters.payment}
                onChange={(value) => update("payment", value)}
              />
            </FilterSection>
            <FilterSection title="التأثيث">
              <ChoiceGroup
                options={["مفروش", "غير مفروش"]}
                value={filters.furnishing}
                onChange={(value) => update("furnishing", value)}
              />
            </FilterSection>
            <FilterSection title="المساحات الداخلية — الحد الأدنى">
              <div className="space-y-2">
                <FilterCounter
                  label="غرف النوم"
                  value={filters.bedrooms}
                  onChange={(value) => update("bedrooms", value)}
                />
                <FilterCounter
                  label="الحمامات"
                  value={filters.bathrooms}
                  onChange={(value) => update("bathrooms", value)}
                />
                <FilterCounter
                  label="الصالات"
                  value={filters.halls}
                  onChange={(value) => update("halls", value)}
                />
                <FilterCounter
                  label="المطابخ"
                  value={filters.kitchens}
                  onChange={(value) => update("kitchens", value)}
                />
              </div>
            </FilterSection>
            <FilterSection title="عمر العقار">
              <ChoiceGroup
                options={["جديد", "أقل من 5 سنوات", "بناء قديم"]}
                value={filters.propertyAge}
                onChange={(value) => update("propertyAge", value)}
              />
            </FilterSection>
            <FilterSection title="الخدمات الأساسية">
              <CheckGroup
                options={[
                  "الكهرباء: حكومي / خط عام",
                  "الكهرباء: تجاري / مولدات",
                  "المياه: شبكة حكومية",
                  "المياه: بير ارتوازي",
                  "المياه: متوفر بانتظام",
                  "الصرف الصحي: شبكة حكومية",
                  "الصرف الصحي: بيارة خاصة",
                  "الاتصالات: خط تلفون",
                  "الاتصالات: إنترنت ألياف ضوئية Fiber",
                ]}
                values={filters.infrastructure}
                onChange={(value) => update("infrastructure", value)}
              />
            </FilterSection>
            <FilterSection title="المرافق">
              <CheckGroup
                options={[
                  "موقف سيارات",
                  "إنترنت",
                  "مسبح",
                  "مصعد",
                  "حديقة",
                  "تكييف مركزي",
                ]}
                values={filters.amenities}
                onChange={(value) => update("amenities", value)}
              />
            </FilterSection>
          </>
        )}

        {filters.propertyType === "أرض" && (
          <>
            <FilterSection title="الغرض">
              <ChoiceGroup
                options={["للبيع", "للإيجار", "استثمار"]}
                value={filters.purpose}
                onChange={(value) => update("purpose", value)}
              />
            </FilterSection>
            <FilterSection title="طريقة الدفع">
              <ChoiceGroup
                options={["كاش", "تقسيط"]}
                value={filters.payment}
                onChange={(value) => update("payment", value)}
              />
            </FilterSection>
            <FilterSection title="نوع الأرض">
              <ChoiceGroup
                options={["سكنية", "تجارية", "زراعية", "صناعية"]}
                value={filters.landType}
                onChange={(value) => update("landType", value)}
              />
            </FilterSection>
            <FilterSection title="المساحة م²">
              <DualRangeSlider
                minValue={filters.areaMin}
                maxValue={filters.areaMax}
                min={0}
                max={5000}
                step={50}
                unit="م²"
                onChange={(areaMin, areaMax) =>
                  setFilters((current) => ({
                    ...current,
                    areaMin,
                    areaMax,
                  }))
                }
              />
            </FilterSection>
            <FilterSection title="واجهة الأرض">
              <CheckGroup
                options={["شمالية", "جنوبية", "شرقية", "غربية", "زاوية/شارعين"]}
                values={filters.frontage}
                onChange={(value) => update("frontage", value)}
              />
            </FilterSection>
            <FilterSection title="عرض الشارع الرئيسي">
              <ChoiceGroup
                options={["10م", "12م", "20م+"]}
                value={filters.streetWidth}
                onChange={(value) => update("streetWidth", value)}
              />
            </FilterSection>
            <FilterSection title="توفر الخدمات">
              <CheckGroup
                options={["إسفلت", "كهرباء", "مياه", "صرف صحي"]}
                values={filters.amenities}
                onChange={(value) => update("amenities", value)}
              />
            </FilterSection>
          </>
        )}

        {filters.propertyType === "محلات" && (
          <>
            <FilterSection title="الغرض">
              <ChoiceGroup
                options={["للبيع", "للإيجار"]}
                value={filters.purpose}
                onChange={(value) => update("purpose", value)}
              />
            </FilterSection>
            <FilterSection title="طريقة الدفع">
              <ChoiceGroup
                options={["كاش", "تقسيط"]}
                value={filters.payment}
                onChange={(value) => update("payment", value)}
              />
            </FilterSection>
            <FilterSection title="نوع المحل">
              <ChoiceGroup
                options={[
                  "مكتب تجاري",
                  "معرض",
                  "مطعم/مقهى",
                  "صيدلية",
                  "مستودع",
                  "محل عام",
                ]}
                value={filters.commercialType}
                onChange={(value) => update("commercialType", value)}
              />
            </FilterSection>
            <FilterSection title="موقع المحل">
              <ChoiceGroup
                options={[
                  "داخل مول",
                  "داخل سوق تجاري",
                  "على الشارع العام",
                  "في حي سكني",
                ]}
                value={filters.shopLocation}
                onChange={(value) => update("shopLocation", value)}
              />
            </FilterSection>
            <FilterSection title="المساحة م²">
              <DualRangeSlider
                minValue={filters.areaMin}
                maxValue={filters.areaMax}
                min={0}
                max={5000}
                step={25}
                unit="م²"
                onChange={(areaMin, areaMax) =>
                  setFilters((current) => ({
                    ...current,
                    areaMin,
                    areaMax,
                  }))
                }
              />
            </FilterSection>
            <FilterSection title="حالة التشطيب">
              <ChoiceGroup
                options={["عظم", "تشطيب كامل", "يحتاج ديكور"]}
                value={filters.finishing}
                onChange={(value) => update("finishing", value)}
              />
            </FilterSection>
            <FilterSection title="المميزات والمرافق">
              <CheckGroup
                options={[
                  "واجهة زجاجية",
                  "عداد كهرباء مستقل",
                  "دورة مياه",
                  "مواقف للعملاء",
                  "كاميرات مراقبة",
                ]}
                values={filters.amenities}
                onChange={(value) => update("amenities", value)}
              />
            </FilterSection>
          </>
        )}

        {filters.propertyType === "فندق" && (
          <>
            <FilterSection title="الغرض">
              <p className="rounded-xl bg-[var(--primary-soft)] p-3 text-xs font-bold text-[var(--primary-text)]">
                حجز يومي / إقامات قصيرة
              </p>
            </FilterSection>
            <FilterSection title="التصنيف">
              <ChoiceGroup
                options={["⭐", "⭐⭐", "⭐⭐⭐", "⭐⭐⭐⭐", "⭐⭐⭐⭐⭐"]}
                value={
                  filters.starRating ? "⭐".repeat(filters.starRating) : ""
                }
                onChange={(value) => update("starRating", value.length)}
              />
            </FilterSection>
            <FilterSection title="النوع / الفئة">
              <ChoiceGroup
                options={[
                  "غرفة مفردة",
                  "غرفة مزدوجة",
                  "جناح عائلي",
                  "استراحة عامة",
                  "طيرمانة",
                  "صالة مؤتمرات",
                ]}
                value={filters.roomCategory}
                onChange={(value) => update("roomCategory", value)}
              />
            </FilterSection>
            <FilterSection title="عدد السراير في الغرفة">
              <FilterCounter
                label="عدد السراير"
                value={filters.bedCount}
                onChange={(value) => update("bedCount", value)}
              />
            </FilterSection>
            <FilterSection title="نوع السرير">
              <ChoiceGroup
                options={["عائلي مزدوج", "فردي"]}
                value={filters.bedType}
                onChange={(value) => update("bedType", value)}
              />
            </FilterSection>
            <FilterSection title="الخدمات الفندقية">
              <CheckGroup
                options={[
                  "إفطار مجاني",
                  "خدمة الغرف 24 ساعة",
                  "مسبح مشترك",
                  "نادي صحي",
                  "مواقف",
                  "استقبال 24 ساعة",
                  "واي فاي",
                  "مطعم",
                  "قاعة اجتماعات",
                ]}
                values={filters.amenities}
                onChange={(value) => update("amenities", value)}
              />
            </FilterSection>
          </>
        )}

        {filters.propertyType === "شاليه" && (
          <>
            <FilterSection title="الغرض">
              <p className="rounded-xl bg-[var(--primary-soft)] p-3 text-xs font-bold text-[var(--primary-text)]">
                حجز يومي / ترفيهي واستجمام
              </p>
            </FilterSection>
            <FilterSection title="السعة الاستيعابية">
              <FilterCounter
                label="العدد التقريبي للضيوف"
                value={filters.capacity}
                onChange={(value) => update("capacity", value)}
              />
            </FilterSection>
            <FilterSection title="المميزات الترفيهية">
              <CheckGroup
                options={[
                  "مسبح خاص",
                  "مسبح أطفال",
                  "مسطحات خضراء",
                  "جلسات خارجية",
                  "ألعاب إلكترونية",
                  "مكان للشواء",
                  "جاكوزي",
                ]}
                values={filters.amenities}
                onChange={(value) => update("amenities", value)}
              />
            </FilterSection>
            <FilterSection title="الخصوصية">
              <ChoiceGroup
                options={["سور مستقل مرتفع", "إطلالة بانورامية"]}
                value={filters.privacy}
                onChange={(value) => update("privacy", value)}
              />
            </FilterSection>
          </>
        )}
      </main>

      <footer className="relative z-50 shrink-0 border-t border-[var(--line)] bg-[var(--surface-raised)] p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
        <button
          className="min-h-12 w-full rounded-xl bg-[var(--primary-strong)] px-4 font-bold text-[var(--dark-text)] shadow-lg"
          onClick={onApply}
        >
          إظهار النتائج
        </button>
      </footer>
    </section>
  )
}

type InfrastructureKey = "electricity" | "water" | "sewage" | "telecommunications"

type InfrastructureService = {
  label: string
  value: string
  icon: IconName
  status?: "available" | "unavailable" | "unknown"
}

type Owner = {
  id: string
  name: string
  initials: string
  rating: number
  reviewCount: number
  since: string
  verified: boolean
  online: boolean
  lastSeen: string
  location: string
  bio: string
  phone: string
  responseRate: number
  followerCount: number
  type: string
}

const owners: Record<string, Owner> = {
  ahmed: {
    id: "ahmed",
    name: "أحمد القاسمي",
    initials: "أق",
    rating: 4.8,
    reviewCount: 120,
    since: "يناير 2019",
    verified: true,
    online: true,
    lastSeen: "الآن",
    location: "صنعاء، حدة",
    bio: "مالك عقارات موثّق ومتخصص في الشقق السكنية داخل صنعاء. أهتم بتقديم معلومات واضحة وترتيب المعاينات بسرعة ومرونة.",
    phone: "+967700000001",
    responseRate: 96,
    followerCount: 248,
    type: "مالك عقار",
  },
  ofuq: {
    id: "ofuq",
    name: "مكتب أفق العقاري",
    initials: "مأ",
    rating: 4.6,
    reviewCount: 84,
    since: "مارس 2017",
    verified: true,
    online: true,
    lastSeen: "الآن",
    location: "صنعاء، بني الحارث",
    bio: "مكتب عقاري موثّق لخدمة الباحثين عن المنازل المستقلة والعقارات العائلية، مع متابعة مباشرة لجميع الاستفسارات.",
    phone: "+967700000002",
    responseRate: 92,
    followerCount: 391,
    type: "مكتب عقاري",
  },
  coast: {
    id: "coast",
    name: "دار الساحل للضيافة",
    initials: "دس",
    rating: 4.9,
    reviewCount: 211,
    since: "يونيو 2021",
    verified: true,
    online: false,
    lastSeen: "منذ ساعة",
    location: "عدن، خور مكسر",
    bio: "منشأة ضيافة متخصصة في الإقامات اليومية والفلل الخاصة، نوفر تجربة مريحة وخدمة سريعة للعائلات والمجموعات.",
    phone: "+967700000003",
    responseRate: 98,
    followerCount: 624,
    type: "منشأة ضيافة",
  },
  sama: {
    id: "sama",
    name: "سما العقارية",
    initials: "سع",
    rating: 4.5,
    reviewCount: 49,
    since: "سبتمبر 2020",
    verified: true,
    online: false,
    lastSeen: "أمس",
    location: "تعز، القاهرة",
    bio: "خدمات عقارية موثوقة في مدينة تعز تشمل البيع والتقسيط والمتابعة حتى إتمام الاتفاق.",
    phone: "+967700000004",
    responseRate: 89,
    followerCount: 176,
    type: "مكتب عقاري",
  },
  hotelSanaa: {
    id: "hotel-sanaa-owner",
    name: "فندق سماء صنعاء",
    initials: "فس",
    rating: 4.7,
    reviewCount: 162,
    since: "فبراير 2018",
    verified: true,
    online: true,
    lastSeen: "الآن",
    location: "صنعاء، شارع حدة",
    bio: "فندق عائلي بخدمات ضيافة متكاملة وموقع قريب من أهم مرافق المدينة.",
    phone: "+967700000005",
    responseRate: 97,
    followerCount: 510,
    type: "فندق",
  },
  oasis: {
    id: "oasis",
    name: "شاليهات الواحة",
    initials: "شا",
    rating: 4.7,
    reviewCount: 73,
    since: "مايو 2022",
    verified: true,
    online: false,
    lastSeen: "منذ ساعتين",
    location: "عدن، الساحل الذهبي",
    bio: "شاليهات عائلية للترفيه والاستجمام مع مساحات خاصة وخدمة حجز مرنة.",
    phone: "+967700000006",
    responseRate: 91,
    followerCount: 203,
    type: "شاليه",
  },
}

const ownerList = Object.values(owners)
const findOwner = (ownerId: string) =>
  ownerList.find((owner) => owner.id === ownerId)

type Property = {
  id: string
  title: string
  subtitle: string
  featured?: boolean
  featuredAt?: string
  category: "residential" | "commercial" | "land" | "hotel" | "chalet"
  type:
    | "شقة"
    | "منزل مستقل"
    | "فيلا"
    | "محل تجاري"
    | "أرض"
    | "فندق"
    | "شاليه"
  commercialType?:
    | "مكتب تجاري"
    | "معرض"
    | "مطعم/مقهى"
    | "صيدلية"
    | "مستودع"
    | "محل عام"
  shopLocation?:
    | "داخل مول"
    | "داخل سوق تجاري"
    | "على الشارع العام"
    | "في حي سكني"
  area?: number
  finishing?: "عظم" | "تشطيب كامل" | "يحتاج ديكور"
  landType?: "سكنية" | "تجارية" | "زراعية" | "صناعية"
  frontage?: ("شمالية" | "جنوبية" | "شرقية" | "غربية" | "زاوية/شارعين")[]
  streetWidth?: "10م" | "12م" | "20م+"
  starRating?: 1 | 2 | 3 | 4 | 5
  roomCategory?:
    | "غرفة مفردة"
    | "غرفة مزدوجة"
    | "جناح عائلي"
    | "استراحة عامة"
    | "طيرمانة"
    | "صالة مؤتمرات"
  bedCount?: number
  bedType?: "عائلي مزدوج" | "فردي"
  capacity?: number
  privacy?: "سور مستقل مرتفع" | "إطلالة بانورامية"
  chaletAmenities?: string[]
  image: string
  images: string[]
  alt: string
  price: number
  currency: string
  pricePeriod?: string
  location: {
    governorate: string
    district: string
    neighborhood?: string
  }
  bedrooms: number
  halls: number
  kitchens: number
  bathrooms: number
  purpose: "للبيع" | "للإيجار" | "حجز يومي" | "استثمار"
  paymentMethod?: "كاش" | "تقسيط"
  furnishing: "مفروش" | "غير مفروش"
  owner: Owner
  description: string
  amenities: string[]
  infrastructure: Partial<Record<InfrastructureKey, InfrastructureService>>
  createdAt: string
}

type PropertyReview = {
  id: string
  propertyId: string
  userId: string
  userName: string
  userInitials: string
  rating: number
  text: string
  dateLabel: string
  createdAt: number
  isOwn: boolean
  isNew?: boolean
}

const photo = (id: string) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=1080&q=82`

const properties: Property[] = [
  {
    id: "apt-hadda-01",
    category: "residential",
    title: "شقة فاخرة بإطلالة مفتوحة",
    subtitle: "تشطيب حديث ومساحات عملية في قلب حي حدة",
    featured: true,
    featuredAt: "2026-05-20",
    type: "شقة",
    image: photo("photo-1515263487990-61b07816b324"),
    images: [
      photo("photo-1515263487990-61b07816b324"),
      photo("photo-1600607687939-ce8a6c25118c"),
      photo("photo-1600566753086-00f18fb6b3ea"),
      photo("photo-1600210492486-724fe5c67fb0"),
      photo("photo-1600585154340-be6161a56a0c"),
    ],
    alt: "مبنى شقق سكنية عصري",
    price: 85000000,
    currency: "ر.ي",
    location: {
      governorate: "صنعاء",
      district: "السبعين",
      neighborhood: "حدة",
    },
    bedrooms: 3,
    halls: 2,
    kitchens: 1,
    bathrooms: 2,
    purpose: "للبيع",
    paymentMethod: "كاش",
    furnishing: "غير مفروش",
    owner: owners.ahmed,
    description:
      "شقة عصرية بمساحة رحبة وتوزيع عملي، تضم ثلاث غرف نوم وصالتين ومطبخاً مجهزاً. تقع بالقرب من المدارس والخدمات اليومية وتتميز بإضاءة طبيعية وإطلالة مفتوحة.",
    amenities: ["موقف سيارات", "مصعد", "نظام أمان", "مدخل مستقل"],
    infrastructure: {
      electricity: {
        label: "الكهرباء",
        value: "كهرباء تجارية",
        icon: "bolt",
      },
      water: {
        label: "المياه",
        value: "بئر ارتوازي",
        icon: "droplet",
      },
      sewage: {
        label: "الصرف الصحي",
        value: "شبكة حكومية",
        icon: "settings",
      },
      telecommunications: {
        label: "الإنترنت",
        value: "ألياف ضوئية",
        icon: "wifi",
      },
    },
    createdAt: "2026-05-12",
  },
  {
    id: "house-rawdah-02",
    category: "residential",
    title: "منزل مستقل بحديقة خاصة",
    subtitle: "منزل عائلي هادئ بمدخل مستقل وحديقة خضراء",
    type: "منزل مستقل",
    image: photo("photo-1721815693498-cc28507c0ba2"),
    images: [
      photo("photo-1721815693498-cc28507c0ba2"),
      photo("photo-1600047509807-ba8f99d2cdde"),
      photo("photo-1600566753190-17f0baa2a6c3"),
    ],
    alt: "منزل مستقل حديث من طابقين",
    price: 8500,
    currency: "ريال سعودي",
    pricePeriod: "شهرياً",
    location: {
      governorate: "صنعاء",
      district: "بني الحارث",
      neighborhood: "الروضة",
    },
    bedrooms: 4,
    halls: 2,
    kitchens: 1,
    bathrooms: 3,
    purpose: "للإيجار",
    furnishing: "مفروش",
    owner: owners.ofuq,
    description:
      "منزل مستقل مفروش مناسب للعائلات، يتكون من طابقين مع حديقة خاصة وموقف سيارة. يقع في شارع هادئ وقريب من الأسواق والخدمات الأساسية.",
    amenities: ["حديقة", "موقف سيارات", "إنترنت", "غرفة خادمة"],
    infrastructure: {
      electricity: {
        label: "الكهرباء",
        value: "طاقة شمسية",
        icon: "bolt",
      },
      water: {
        label: "المياه",
        value: "خزان مياه",
        icon: "droplet",
      },
      sewage: {
        label: "الصرف الصحي",
        value: "بيارة خاصة",
        icon: "settings",
      },
      telecommunications: {
        label: "الاتصالات",
        value: "إنترنت لاسلكي",
        icon: "wifi",
      },
    },
    createdAt: "2026-05-08",
  },
  {
    id: "villa-aden-03",
    category: "residential",
    title: "فيلا راقية مع مسبح",
    subtitle: "إقامة يومية خاصة على مقربة من ساحل عدن",
    type: "فيلا",
    image: photo("photo-1670589953882-b94c9cb380f5"),
    images: [
      photo("photo-1670589953882-b94c9cb380f5"),
      photo("photo-1733413788848-6f9e0c1c414c"),
      photo("photo-1613490493576-7fde63acd811"),
      photo("photo-1600607687920-4e2a09cf159d"),
    ],
    alt: "فيلا حديثة مع مسبح",
    price: 1200,
    currency: "ريال سعودي",
    pricePeriod: "يومياً",
    location: {
      governorate: "عدن",
      district: "خور مكسر",
      neighborhood: "العريش",
    },
    bedrooms: 5,
    halls: 3,
    kitchens: 2,
    bathrooms: 5,
    purpose: "حجز يومي",
    paymentMethod: "كاش",
    furnishing: "مفروش",
    owner: owners.coast,
    description:
      "فيلا خاصة مجهزة للإقامة اليومية، تضم مسبحاً وجلسات خارجية وخمس غرف نوم. مثالية للعائلات والمجموعات مع خصوصية كاملة وخدمات ضيافة متكاملة.",
    amenities: ["مسبح", "إنترنت", "موقف سيارات", "تكييف مركزي", "نظام أمان"],
    infrastructure: {
      electricity: {
        label: "الكهرباء",
        value: "خط عام",
        icon: "bolt",
      },
      water: {
        label: "المياه",
        value: "شبكة حكومية",
        icon: "droplet",
      },
      telecommunications: {
        label: "الإنترنت",
        value: "شبكة اتصالات محلية",
        icon: "wifi",
      },
    },
    createdAt: "2026-05-15",
  },
  {
    id: "apt-taiz-04",
    category: "residential",
    title: "شقة عائلية وسط المدينة",
    subtitle: "موقع مركزي قريب من المرافق والخدمات",
    type: "شقة",
    image: photo("photo-1628012209120-d9db7abf7eab"),
    images: [
      photo("photo-1628012209120-d9db7abf7eab"),
      photo("photo-1522708323590-d24dbb6b0267"),
      photo("photo-1560448204-e02f11c3d0e2"),
    ],
    alt: "واجهة شقق بيضاء حديثة",
    price: 62500000,
    currency: "ر.ي",
    location: {
      governorate: "تعز",
      district: "القاهرة",
      neighborhood: "وادي القاضي",
    },
    bedrooms: 3,
    halls: 1,
    kitchens: 1,
    bathrooms: 2,
    purpose: "للبيع",
    paymentMethod: "تقسيط",
    furnishing: "غير مفروش",
    owner: owners.sama,
    description:
      "شقة عائلية جديدة بتشطيب متين ومساحات مريحة، تقع وسط المدينة وتوفر وصولاً سهلاً إلى المدارس والأسواق والمواصلات.",
    amenities: ["مصعد", "موقف سيارات"],
    infrastructure: {
      electricity: {
        label: "الكهرباء",
        value: "كهرباء حكومية",
        icon: "bolt",
      },
      water: {
        label: "المياه",
        value: "وايت مياه",
        icon: "droplet",
      },
      sewage: {
        label: "الصرف الصحي",
        value: "غير متوفر",
        icon: "settings",
        status: "unavailable",
      },
    },
    createdAt: "2026-04-28",
  },
  {
    id: "shop-hadda-01",
    category: "commercial",
    title: "مكتب تجاري حديث في حدة",
    subtitle: "مساحة عمل جاهزة بواجهة أنيقة وموقع قريب من مراكز الأعمال",
    featured: true,
featuredAt: "2026-05-20",
    type: "محل تجاري",
    commercialType: "مكتب تجاري",
    shopLocation: "على الشارع العام",
    area: 145,
    finishing: "تشطيب كامل",
    image: photo("photo-1765219212909-791445ca4887"),
    images: [
      photo("photo-1765219212909-791445ca4887"),
      photo("photo-1781967651630-e680c7bad016"),
    ],
    alt: "مبنى مكاتب تجارية حديث",
    price: 650000,
    currency: "ر.ي",
    pricePeriod: "شهرياً",
    location: {
      governorate: "صنعاء",
      district: "السبعين",
      neighborhood: "حدة",
    },
    bedrooms: 0,
    halls: 0,
    kitchens: 0,
    bathrooms: 0,
    purpose: "للإيجار",
    paymentMethod: "كاش",
    furnishing: "غير مفروش",
    owner: owners.ahmed,
    description:
      "مكتب تجاري بتشطيب كامل وتقسيم عملي يضم مساحة استقبال ومكاتب خاصة وقاعة اجتماعات، مع واجهة واضحة على شارع حيوي ومواقف قريبة للعملاء.",
    amenities: [
      "واجهة زجاجية",
      "عداد كهرباء مستقل",
      "دورة مياه",
      "مواقف للعملاء",
      "كاميرات مراقبة",
    ],
    infrastructure: {
      electricity: {
        label: "الكهرباء",
        value: "عداد تجاري مستقل",
        icon: "bolt",
      },
      water: {
        label: "المياه",
        value: "شبكة حكومية",
        icon: "droplet",
      },
      sewage: {
        label: "الصرف الصحي",
        value: "شبكة حكومية",
        icon: "settings",
      },
      telecommunications: {
        label: "الإنترنت",
        value: "ألياف ضوئية",
        icon: "wifi",
      },
    },
    createdAt: "2026-05-18",
  },
  {
    id: "showroom-taiz-02",
    category: "commercial",
    title: "معرض واسع بواجهة زجاجية",
    subtitle: "واجهة بارزة ومساحة عرض مفتوحة على شارع جمال",
    type: "محل تجاري",
    commercialType: "معرض",
    shopLocation: "على الشارع العام",
    area: 280,
    finishing: "تشطيب كامل",
    image: photo("photo-1750767303706-7d93c2d0f03f"),
    images: [
      photo("photo-1750767303706-7d93c2d0f03f"),
      photo("photo-1758631279366-8e8aeaf94082"),
    ],
    alt: "مدخل معرض تجاري حديث",
    price: 180000000,
    currency: "ر.ي",
    location: {
      governorate: "تعز",
      district: "القاهرة",
      neighborhood: "شارع جمال",
    },
    bedrooms: 0,
    halls: 0,
    kitchens: 0,
    bathrooms: 0,
    purpose: "للبيع",
    paymentMethod: "تقسيط",
    furnishing: "غير مفروش",
    owner: owners.sama,
    description:
      "معرض تجاري واسع بتصميم مفتوح وواجهة زجاجية ممتدة، مناسب للأثاث أو الإلكترونيات أو معارض السيارات الخفيفة، مع مخزن خلفي ومدخل تحميل مستقل.",
    amenities: [
      "واجهة زجاجية",
      "عداد كهرباء مستقل",
      "دورة مياه",
      "مواقف للعملاء",
      "كاميرات مراقبة",
    ],
    infrastructure: {
      electricity: {
        label: "الكهرباء",
        value: "كهرباء حكومية وتجارية",
        icon: "bolt",
      },
      water: {
        label: "المياه",
        value: "خزان مستقل",
        icon: "droplet",
      },
      telecommunications: {
        label: "الاتصالات",
        value: "تغطية اتصالات وإنترنت",
        icon: "wifi",
      },
    },
    createdAt: "2026-05-14",
  },
  {
    id: "restaurant-aden-03",
    category: "commercial",
    title: "محل مطعم مجهز في خور مكسر",
    subtitle: "موقع نشط قريب من الفنادق والخدمات مع تجهيزات تشغيل أساسية",
    type: "محل تجاري",
    commercialType: "مطعم/مقهى",
    shopLocation: "داخل سوق تجاري",
    area: 190,
    finishing: "تشطيب كامل",
    image: photo("photo-1783275463499-995361d01289"),
    images: [
      photo("photo-1783275463499-995361d01289"),
      photo("photo-1788416636136-6c84b518507d"),
    ],
    alt: "واجهة مطعم ومقهى تجاري",
    price: 4200,
    currency: "ريال سعودي",
    pricePeriod: "شهرياً",
    location: {
      governorate: "عدن",
      district: "خور مكسر",
      neighborhood: "المدينة البيضاء",
    },
    bedrooms: 0,
    halls: 0,
    kitchens: 0,
    bathrooms: 0,
    purpose: "للإيجار",
    paymentMethod: "كاش",
    furnishing: "مفروش",
    owner: owners.coast,
    description:
      "محل مناسب لمطعم أو مقهى مع صالة استقبال ومطبخ تحضيري ومنطقة خدمات، يقع داخل سوق تجاري نشط ويتمتع بمرور يومي مرتفع ومواقف قريبة.",
    amenities: [
      "واجهة زجاجية",
      "عداد كهرباء مستقل",
      "دورة مياه",
      "مواقف للعملاء",
    ],
    infrastructure: {
      electricity: {
        label: "الكهرباء",
        value: "خط عام ومولد احتياطي",
        icon: "bolt",
      },
      water: {
        label: "المياه",
        value: "متوفر بانتظام",
        icon: "droplet",
      },
      sewage: {
        label: "الصرف الصحي",
        value: "شبكة حكومية",
        icon: "settings",
      },
      telecommunications: {
        label: "الإنترنت",
        value: "إنترنت لاسلكي",
        icon: "wifi",
      },
    },
    createdAt: "2026-05-11",
  },
  {
    id: "warehouse-sanaa-04",
    category: "commercial",
    title: "مستودع تجاري بمدخل تحميل",
    subtitle: "مساحة تخزين مرتفعة السقف وسهلة الوصول للشاحنات",
    type: "محل تجاري",
    commercialType: "مستودع",
    shopLocation: "في حي سكني",
    area: 520,
    finishing: "عظم",
    image: photo("photo-1682579401399-f65e193d6389"),
    images: [
      photo("photo-1682579401399-f65e193d6389"),
      photo("photo-1765219212909-791445ca4887"),
    ],
    alt: "مستودع تجاري واسع",
    price: 95000000,
    currency: "ر.ي",
    location: {
      governorate: "صنعاء",
      district: "بني الحارث",
      neighborhood: "الجراف",
    },
    bedrooms: 0,
    halls: 0,
    kitchens: 0,
    bathrooms: 0,
    purpose: "للبيع",
    paymentMethod: "كاش",
    furnishing: "غير مفروش",
    owner: owners.ofuq,
    description:
      "مستودع تجاري بسقف مرتفع وأرضية قوية ومدخل تحميل واسع، مناسب للتوزيع والتخزين المتوسط مع غرفة إدارة ودورة مياه وعداد كهرباء مستقل.",
    amenities: [
      "عداد كهرباء مستقل",
      "دورة مياه",
      "مواقف للعملاء",
      "كاميرات مراقبة",
    ],
    infrastructure: {
      electricity: {
        label: "الكهرباء",
        value: "عداد تجاري مستقل",
        icon: "bolt",
      },
      water: {
        label: "المياه",
        value: "خزان مياه",
        icon: "droplet",
      },
      sewage: {
        label: "الصرف الصحي",
        value: "بيارة خاصة",
        icon: "settings",
      },
      telecommunications: {
        label: "الاتصالات",
        value: "تغطية شبكة مستقرة",
        icon: "wifi",
      },
    },
    createdAt: "2026-05-05",
  },
  {
    id: "land-hadda-01",
    category: "land",
    title: "أرض سكنية في حدة",
    subtitle: "قطعة مستوية على شارعين ضمن مخطط سكني هادئ",
    featured: true,
featuredAt: "2026-05-20",
    type: "أرض",
    landType: "سكنية",
    frontage: ["شمالية", "زاوية/شارعين"],
    streetWidth: "20م+",
    area: 720,
    image: photo("photo-1488354028423-039ac1e23357"),
    images: [
      photo("photo-1488354028423-039ac1e23357"),
      photo("photo-1762369879305-59b7b00d8761"),
    ],
    alt: "أرض سكنية مستوية بجوار طريق",
    price: 145000000,
    currency: "ر.ي",
    location: {
      governorate: "صنعاء",
      district: "السبعين",
      neighborhood: "حدة",
    },
    bedrooms: 0,
    halls: 0,
    kitchens: 0,
    bathrooms: 0,
    purpose: "للبيع",
    paymentMethod: "تقسيط",
    furnishing: "غير مفروش",
    owner: owners.ahmed,
    description:
      "قطعة أرض سكنية مستوية ضمن مخطط منظم في حدة، تقع على زاوية شارعين وتناسب بناء فيلا أو مبنى عائلي مع سهولة الوصول إلى الخدمات.",
    amenities: ["إسفلت", "كهرباء", "مياه", "صرف صحي"],
    infrastructure: {},
    createdAt: "2026-05-20",
  },
  {
    id: "land-aden-02",
    category: "land",
    title: "أرض تجارية على خط رئيسي",
    subtitle: "واجهة واسعة مناسبة لمشروع تجاري أو معرض",
    type: "أرض",
    landType: "تجارية",
    frontage: ["جنوبية", "شرقية"],
    streetWidth: "20م+",
    area: 1150,
    image: photo("photo-1762369879305-59b7b00d8761"),
    images: [
      photo("photo-1762369879305-59b7b00d8761"),
      photo("photo-1717981097393-4b32f421c69f"),
    ],
    alt: "أرض تجارية بمحاذاة طريق رئيسي",
    price: 320000,
    currency: "دولار أمريكي",
    location: {
      governorate: "عدن",
      district: "المنصورة",
      neighborhood: "خط التسعين",
    },
    bedrooms: 0,
    halls: 0,
    kitchens: 0,
    bathrooms: 0,
    purpose: "استثمار",
    paymentMethod: "كاش",
    furnishing: "غير مفروش",
    owner: owners.coast,
    description:
      "أرض تجارية بواجهة طويلة على خط رئيسي وحركة مرور مرتفعة، مناسبة لإنشاء معرض أو مركز خدمات أو مشروع استثماري متوسط الحجم.",
    amenities: ["إسفلت", "كهرباء", "مياه"],
    infrastructure: {},
    createdAt: "2026-05-17",
  },
  {
    id: "land-ibb-03",
    category: "land",
    title: "أرض زراعية خصبة",
    subtitle: "مدرجات خضراء قريبة من مصدر مياه وطريق فرعي",
    type: "أرض",
    landType: "زراعية",
    frontage: ["غربية"],
    streetWidth: "10م",
    area: 3200,
    image: photo("photo-1508175688576-0c076b47b5b5"),
    images: [
      photo("photo-1508175688576-0c076b47b5b5"),
      photo("photo-1516822277566-bb38424a2b77"),
      photo("photo-1545292470-391a7b77b8a2"),
    ],
    alt: "أرض زراعية خضراء من الأعلى",
    price: 180000,
    currency: "ريال سعودي",
    location: {
      governorate: "إب",
      district: "الظهار",
      neighborhood: "السحول",
    },
    bedrooms: 0,
    halls: 0,
    kitchens: 0,
    bathrooms: 0,
    purpose: "للبيع",
    paymentMethod: "كاش",
    furnishing: "غير مفروش",
    owner: owners.sama,
    description:
      "أرض زراعية خصبة ذات تربة جيدة ومدرجات قابلة للزراعة، قريبة من مصدر مياه ويمكن الوصول إليها عبر طريق فرعي ممهد.",
    amenities: ["مياه", "كهرباء"],
    infrastructure: {},
    createdAt: "2026-05-09",
  },
  {
    id: "land-taiz-04",
    category: "land",
    title: "أرض صناعية بساحة مفتوحة",
    subtitle: "موقع مناسب لمستودع أو ورشة مع مدخل للمركبات الثقيلة",
    type: "أرض",
    landType: "صناعية",
    frontage: ["شمالية"],
    streetWidth: "12م",
    area: 2400,
    image: photo("photo-1720155390935-f49e18525eb9"),
    images: [
      photo("photo-1720155390935-f49e18525eb9"),
      photo("photo-1681585223949-dab44b4441bc"),
    ],
    alt: "مساحة أرض مفتوحة لمشروع صناعي",
    price: 900000,
    currency: "ر.ي",
    pricePeriod: "شهرياً",
    location: {
      governorate: "تعز",
      district: "التعزية",
      neighborhood: "الحوبان",
    },
    bedrooms: 0,
    halls: 0,
    kitchens: 0,
    bathrooms: 0,
    purpose: "للإيجار",
    paymentMethod: "كاش",
    furnishing: "غير مفروش",
    owner: owners.ofuq,
    description:
      "أرض صناعية مفتوحة تصلح كساحة تخزين أو ورشة أو مستودع مسبق الصنع، مع مدخل واسع للشاحنات وقربها من المنطقة الصناعية.",
    amenities: ["إسفلت", "كهرباء", "صرف صحي"],
    infrastructure: {},
    createdAt: "2026-05-03",
  },
  {
    id: "hotel-sanaa-single-01",
    category: "hotel",
    title: "فندق بوابة صنعاء",
    subtitle: "إقامة عملية وهادئة بالقرب من مركز المدينة",
    type: "فندق",
    starRating: 2,
    roomCategory: "غرفة مفردة",
    bedCount: 1,
    bedType: "فردي",
    image: photo("photo-1572177215152-32f247303126"),
    images: [
      photo("photo-1572177215152-32f247303126"),
      photo("photo-1613899531429-9253abb43569"),
    ],
    alt: "غرفة فندقية مفردة مرتبة",
    price: 28000,
    currency: "ر.ي",
    pricePeriod: "يومياً",
    location: {
      governorate: "صنعاء",
      district: "التحرير",
      neighborhood: "باب اليمن",
    },
    bedrooms: 1,
    halls: 0,
    kitchens: 0,
    bathrooms: 1,
    purpose: "حجز يومي",
    paymentMethod: "كاش",
    furnishing: "مفروش",
    owner: owners.hotelSanaa,
    description:
      "غرفة مفردة مريحة للمسافرين ورحلات العمل، مجهزة بسرير فردي وحمام خاص وخدمة استقبال على مدار الساعة.",
    amenities: ["واي فاي", "إفطار مجاني", "مواقف", "استقبال 24 ساعة"],
    infrastructure: {},
    createdAt: "2026-05-22",
  },
  {
    id: "hotel-taiz-double-02",
    category: "hotel",
    title: "فندق القلعة السياحي",
    subtitle: "غرفة مزدوجة بإطلالة على مرتفعات تعز",
    type: "فندق",
    starRating: 3,
    roomCategory: "غرفة مزدوجة",
    bedCount: 2,
    bedType: "فردي",
    image: photo("photo-1710388663701-8c4aad200795"),
    images: [
      photo("photo-1710388663701-8c4aad200795"),
      photo("photo-1613891186868-eebda780cc8a"),
    ],
    alt: "غرفة فندقية بسريرين منفصلين",
    price: 165,
    currency: "ريال سعودي",
    pricePeriod: "يومياً",
    location: {
      governorate: "تعز",
      district: "صالة",
      neighborhood: "جبل صبر",
    },
    bedrooms: 1,
    halls: 0,
    kitchens: 0,
    bathrooms: 1,
    purpose: "حجز يومي",
    furnishing: "مفروش",
    owner: owners.hotelSanaa,
    description:
      "غرفة مزدوجة بسريرين منفصلين وإطلالة جبلية، مناسبة للأصدقاء ورحلات العمل وتشمل إفطاراً يومياً وخدمة غرف.",
    amenities: [
      "إفطار مجاني",
      "خدمة الغرف 24 ساعة",
      "واي فاي",
      "مطعم",
      "مواقف",
    ],
    infrastructure: {},
    createdAt: "2026-05-19",
  },
  {
    id: "hotel-aden-family-03",
    category: "hotel",
    title: "فندق كورنيش عدن",
    subtitle: "جناح عائلي واسع قريب من الساحل",
    type: "فندق",
    starRating: 4,
    roomCategory: "جناح عائلي",
    bedCount: 3,
    bedType: "عائلي مزدوج",
    image: photo("photo-1758448755969-8791367cf5c5"),
    images: [
      photo("photo-1758448755969-8791367cf5c5"),
      photo("photo-1705095605806-4b2936e90471"),
    ],
    alt: "جناح فندقي عائلي حديث",
    price: 125,
    currency: "دولار أمريكي",
    pricePeriod: "يومياً",
    location: {
      governorate: "عدن",
      district: "خور مكسر",
      neighborhood: "العريش",
    },
    bedrooms: 2,
    halls: 1,
    kitchens: 0,
    bathrooms: 2,
    purpose: "حجز يومي",
    paymentMethod: "كاش",
    furnishing: "مفروش",
    owner: owners.coast,
    description:
      "جناح عائلي من غرفتين وصالة بإطلالة قريبة من البحر، مع مساحات مريحة وخدمات فندقية متكاملة للعائلات.",
    amenities: [
      "إفطار مجاني",
      "خدمة الغرف 24 ساعة",
      "مسبح مشترك",
      "مواقف",
      "واي فاي",
      "تكييف مركزي",
    ],
    infrastructure: {},
    createdAt: "2026-05-16",
  },
  {
    id: "hotel-sanaa-lounge-04",
    category: "hotel",
    title: "استراحة قصر النخبة",
    subtitle: "استراحة فندقية خاصة للاجتماعات والضيافة",
    type: "فندق",
    starRating: 4,
    roomCategory: "استراحة عامة",
    bedCount: 2,
    bedType: "عائلي مزدوج",
    image: photo("photo-1533743471820-07198f456843"),
    images: [
      photo("photo-1533743471820-07198f456843"),
      photo("photo-1775733923991-e7223f9f44bc"),
    ],
    alt: "استراحة فندقية حديثة بأثاث مريح",
    price: 220000,
    currency: "ر.ي",
    pricePeriod: "يومياً",
    location: {
      governorate: "صنعاء",
      district: "الوحدة",
      neighborhood: "شارع حدة",
    },
    bedrooms: 1,
    halls: 2,
    kitchens: 1,
    bathrooms: 2,
    purpose: "حجز يومي",
    paymentMethod: "كاش",
    furnishing: "مفروش",
    owner: owners.hotelSanaa,
    description:
      "استراحة فندقية راقية للضيافة والاجتماعات الخاصة، تضم صالات جلوس ومطعم خدمة ومرافق متكاملة طوال اليوم.",
    amenities: [
      "خدمة الغرف 24 ساعة",
      "نادي صحي",
      "مواقف",
      "استقبال 24 ساعة",
      "مطعم",
      "قاعة اجتماعات",
    ],
    infrastructure: {},
    createdAt: "2026-05-13",
  },
  {
    id: "hotel-aden-rooftop-05",
    category: "hotel",
    title: "فندق أفق البحر",
    subtitle: "طيرمانة فاخرة بإطلالة بانورامية على عدن",
    featured: true,
featuredAt: "2026-05-20",
    type: "فندق",
    starRating: 5,
    roomCategory: "طيرمانة",
    bedCount: 1,
    bedType: "عائلي مزدوج",
    image: photo("photo-1785486249823-02fbb298c918"),
    images: [
      photo("photo-1785486249823-02fbb298c918"),
      photo("photo-1760709584989-79996c89255c"),
      photo("photo-1777180249046-abf7d640e0d9"),
    ],
    alt: "طيرمانة فندقية مطلة على المدينة",
    price: 210,
    currency: "دولار أمريكي",
    pricePeriod: "يومياً",
    location: {
      governorate: "عدن",
      district: "كريتر",
      neighborhood: "صيرة",
    },
    bedrooms: 1,
    halls: 1,
    kitchens: 0,
    bathrooms: 1,
    purpose: "حجز يومي",
    furnishing: "مفروش",
    owner: owners.coast,
    description:
      "طيرمانة فندقية خاصة في الطابق العلوي بإطلالة بانورامية، تشمل تراساً وجلسة مستقلة وخدمات ضيافة خمس نجوم.",
    amenities: [
      "إفطار مجاني",
      "خدمة الغرف 24 ساعة",
      "مسبح مشترك",
      "نادي صحي",
      "استقبال 24 ساعة",
      "واي فاي",
      "مطعم",
      "تكييف مركزي",
    ],
    infrastructure: {},
    createdAt: "2026-05-10",
  },
  {
    id: "hotel-taiz-conference-06",
    category: "hotel",
    title: "فندق رويال تعز",
    subtitle: "صالة مؤتمرات مجهزة داخل فندق خمس نجوم",
    type: "فندق",
    starRating: 5,
    roomCategory: "صالة مؤتمرات",
    bedCount: 0,
    bedType: "فردي",
    image: photo("photo-1788546762508-449aec223c16"),
    images: [
      photo("photo-1788546762508-449aec223c16"),
      photo("photo-1775733924075-11e542629502"),
    ],
    alt: "صالة اجتماعات فندقية راقية",
    price: 2800,
    currency: "ريال سعودي",
    pricePeriod: "يومياً",
    location: {
      governorate: "تعز",
      district: "القاهرة",
      neighborhood: "وادي القاضي",
    },
    bedrooms: 0,
    halls: 1,
    kitchens: 0,
    bathrooms: 2,
    purpose: "حجز يومي",
    paymentMethod: "كاش",
    furnishing: "مفروش",
    owner: owners.hotelSanaa,
    description:
      "صالة مؤتمرات مجهزة للشركات والفعاليات، تتوفر فيها خدمات استقبال وضيافة وقاعة اجتماعات جانبية وتجهيزات صوتية.",
    amenities: [
      "خدمة الغرف 24 ساعة",
      "مواقف",
      "استقبال 24 ساعة",
      "واي فاي",
      "مطعم",
      "قاعة اجتماعات",
      "تكييف مركزي",
    ],
    infrastructure: {},
    createdAt: "2026-05-07",
  },
  {
    id: "chalet-aden-01",
    category: "chalet",
    title: "شاليه نسيم الساحل",
    subtitle: "شاليه خاص صغير بالقرب من شاطئ عدن",
    featured: true,
featuredAt: "2026-05-20",
    type: "شاليه",
    capacity: 4,
    privacy: "سور مستقل مرتفع",
    chaletAmenities: [
      "مسبح خاص",
      "جلسات خارجية",
      "مكان للشواء",
      "تكييف",
      "واي فاي",
    ],
    image: photo("photo-1774280960001-ce8169cfc38f"),
    images: [
      photo("photo-1774280960001-ce8169cfc38f"),
      photo("photo-1787237876710-286560d4ff2f"),
    ],
    alt: "شاليه ساحلي مع مسبح خاص",
    price: 180,
    currency: "دولار أمريكي",
    pricePeriod: "يومياً",
    location: {
      governorate: "عدن",
      district: "البريقة",
      neighborhood: "الساحل الأزرق",
    },
    bedrooms: 2,
    halls: 1,
    kitchens: 1,
    bathrooms: 2,
    purpose: "حجز يومي",
    paymentMethod: "كاش",
    furnishing: "مفروش",
    owner: owners.oasis,
    description:
      "شاليه ساحلي خاص مناسب للأزواج والعائلات الصغيرة، يضم مسبحاً خاصاً وجلسة خارجية ومنطقة شواء مع خصوصية كاملة.",
    amenities: ["مسبح خاص", "جلسات خارجية", "مكان للشواء", "تكييف", "واي فاي"],
    infrastructure: {},
    createdAt: "2026-05-23",
  },
  {
    id: "chalet-abyan-02",
    category: "chalet",
    title: "شاليه لؤلؤة أبين",
    subtitle: "مساحات خضراء ومسبح أطفال للعائلة",
    type: "شاليه",
    capacity: 8,
    privacy: "سور مستقل مرتفع",
    chaletAmenities: [
      "مسبح أطفال",
      "مسطحات خضراء",
      "جلسات خارجية",
      "ألعاب إلكترونية",
      "مكان للشواء",
      "تكييف",
    ],
    image: photo("photo-1789593847377-a0452ab3f3c9"),
    images: [
      photo("photo-1789593847377-a0452ab3f3c9"),
      photo("photo-1789593847924-d418f03a9664"),
    ],
    alt: "شاليه عائلي بحديقة ومسبح أطفال",
    price: 95000,
    currency: "ر.ي",
    pricePeriod: "يومياً",
    location: {
      governorate: "أبين",
      district: "زنجبار",
      neighborhood: "ساحل الشيخ عبدالله",
    },
    bedrooms: 3,
    halls: 2,
    kitchens: 1,
    bathrooms: 3,
    purpose: "حجز يومي",
    furnishing: "مفروش",
    owner: owners.oasis,
    description:
      "شاليه عائلي آمن يضم مسبح أطفال ومساحات خضراء وألعاباً إلكترونية، مناسب لعطلات نهاية الأسبوع والتجمعات الصغيرة.",
    amenities: [
      "مسبح أطفال",
      "مسطحات خضراء",
      "جلسات خارجية",
      "ألعاب إلكترونية",
      "مكان للشواء",
      "تكييف",
    ],
    infrastructure: {},
    createdAt: "2026-05-18",
  },
  {
    id: "chalet-taiz-03",
    category: "chalet",
    title: "شاليه قمة صبر",
    subtitle: "إطلالة جبلية بانورامية وجاكوزي خاص",
    type: "شاليه",
    capacity: 12,
    privacy: "إطلالة بانورامية",
    chaletAmenities: [
      "جاكوزي",
      "جلسات خارجية",
      "مسطحات خضراء",
      "مكان للشواء",
      "واي فاي",
    ],
    image: photo("photo-1775923293081-598283c494bc"),
    images: [
      photo("photo-1775923293081-598283c494bc"),
      photo("photo-1758612853656-def5033bccb5"),
    ],
    alt: "شاليه جبلي بإطلالة بانورامية",
    price: 650,
    currency: "ريال سعودي",
    pricePeriod: "يومياً",
    location: {
      governorate: "تعز",
      district: "الموادم",
      neighborhood: "جبل صبر",
    },
    bedrooms: 4,
    halls: 2,
    kitchens: 1,
    bathrooms: 4,
    purpose: "حجز يومي",
    paymentMethod: "كاش",
    furnishing: "مفروش",
    owner: owners.oasis,
    description:
      "شاليه جبلي بإطلالة مفتوحة على تعز، يضم جاكوزي وجلسات خارجية ومساحات خضراء، ومناسب للعائلات والمجموعات.",
    amenities: [
      "جاكوزي",
      "جلسات خارجية",
      "مسطحات خضراء",
      "مكان للشواء",
      "واي فاي",
    ],
    infrastructure: {},
    createdAt: "2026-05-14",
  },
  {
    id: "chalet-hajjah-04",
    category: "chalet",
    title: "منتجع وادي مور",
    subtitle: "شاليه واسع بتجربة طبيعية ومرافق ترفيهية",
    type: "شاليه",
    capacity: 16,
    privacy: "سور مستقل مرتفع",
    chaletAmenities: [
      "مسبح خاص",
      "مسبح أطفال",
      "مسطحات خضراء",
      "جلسات خارجية",
      "ألعاب إلكترونية",
      "مكان للشواء",
      "تكييف",
      "واي فاي",
    ],
    image: photo("photo-1787237819544-39f0d4dac2b1"),
    images: [
      photo("photo-1787237819544-39f0d4dac2b1"),
      photo("photo-1782939355736-fc6ed5c24b88"),
    ],
    alt: "شاليه واسع تحيط به مساحات خضراء",
    price: 240000,
    currency: "ر.ي",
    pricePeriod: "يومياً",
    location: {
      governorate: "حجة",
      district: "عبس",
      neighborhood: "وادي مور",
    },
    bedrooms: 5,
    halls: 3,
    kitchens: 2,
    bathrooms: 5,
    purpose: "حجز يومي",
    paymentMethod: "كاش",
    furnishing: "مفروش",
    owner: owners.oasis,
    description:
      "شاليه واسع للمجموعات الكبيرة مع مسبحين للكبار والأطفال ومساحات خضراء ومنطقة ألعاب وشواء داخل سور مستقل.",
    amenities: [
      "مسبح خاص",
      "مسبح أطفال",
      "مسطحات خضراء",
      "جلسات خارجية",
      "ألعاب إلكترونية",
      "مكان للشواء",
      "تكييف",
      "واي فاي",
    ],
    infrastructure: {},
    createdAt: "2026-05-11",
  },
  {
    id: "chalet-ibb-05",
    category: "chalet",
    title: "شاليه السحاب الأخضر",
    subtitle: "إقامة جبلية كبيرة وسط طبيعة إب",
    type: "شاليه",
    capacity: 20,
    privacy: "إطلالة بانورامية",
    chaletAmenities: [
      "مسبح خاص",
      "مسطحات خضراء",
      "جلسات خارجية",
      "ألعاب إلكترونية",
      "مكان للشواء",
      "جاكوزي",
      "تكييف",
      "واي فاي",
    ],
    image: photo("photo-1778159153240-51b1ea22bfdd"),
    images: [
      photo("photo-1778159153240-51b1ea22bfdd"),
      photo("photo-1789487972777-65e53ad79e40"),
      photo("photo-1789593847389-80805c7ea5ab"),
    ],
    alt: "شاليه جبلي كبير وسط الطبيعة",
    price: 1450,
    currency: "ريال سعودي",
    pricePeriod: "يومياً",
    location: {
      governorate: "إب",
      district: "الظهار",
      neighborhood: "مشورة",
    },
    bedrooms: 7,
    halls: 4,
    kitchens: 2,
    bathrooms: 7,
    purpose: "حجز يومي",
    furnishing: "مفروش",
    owner: owners.oasis,
    description:
      "شاليه جبلي كبير للمناسبات العائلية، يوفر مسبحاً وجاكوزي ومساحات خضراء وجلسات متعددة مع إطلالة بانورامية على طبيعة إب.",
    amenities: [
      "مسبح خاص",
      "مسطحات خضراء",
      "جلسات خارجية",
      "ألعاب إلكترونية",
      "مكان للشواء",
      "جاكوزي",
      "تكييف",
      "واي فاي",
    ],
    infrastructure: {},
    createdAt: "2026-05-08",
  },
]

const currencyMatches = (
  propertyCurrency: string,
  selectedCurrency: string,
) => {
  if (selectedCurrency === "ريال يمني") {
    return propertyCurrency === "ر.ي" || propertyCurrency === "ريال يمني"
  }
  return propertyCurrency === selectedCurrency
}

const filterProperties = (source: Property[], filters: SearchFilterState) => {
  const residentialType: Record<string, Property["type"]> = {
    شقة: "شقة",
    "منازل مستقلة": "منزل مستقل",
    فلل: "فيلا",
  }
  const selectedType = residentialType[filters.propertyType]
  const commercialSelected = filters.propertyType === "محلات"
  const landSelected = filters.propertyType === "أرض"
  const hotelSelected = filters.propertyType === "فندق"
  const chaletSelected = filters.propertyType === "شاليه"
  const hasUnsupportedCategory =
    Boolean(filters.propertyType) &&
    !selectedType &&
    !commercialSelected &&
    !landSelected &&
    !hotelSelected &&
    !chaletSelected
  const minPrice = filters.minPrice ? Number(filters.minPrice) : undefined
  const maxPrice = filters.maxPrice ? Number(filters.maxPrice) : undefined
  const minArea = filters.areaMin ? Number(filters.areaMin) : undefined
  const maxArea = filters.areaMax ? Number(filters.areaMax) : undefined
  const manualLocation = filters.manualLocation.trim().toLocaleLowerCase("ar")

  const infrastructureTerms: Record<string, {
    key: InfrastructureKey
    terms: string[]
  }> = {
    "الكهرباء: حكومي / خط عام": {
      key: "electricity",
      terms: ["حكومي", "خط عام"],
    },
    "الكهرباء: تجاري / مولدات": {
      key: "electricity",
      terms: ["تجاري", "مولد"],
    },
    "المياه: شبكة حكومية": {
      key: "water",
      terms: ["شبكة حكومية"],
    },
    "المياه: بير ارتوازي": {
      key: "water",
      terms: ["بئر ارتوازي", "بير ارتوازي"],
    },
    "المياه: متوفر بانتظام": {
      key: "water",
      terms: ["متوفر بانتظام"],
    },
    "الصرف الصحي: شبكة حكومية": {
      key: "sewage",
      terms: ["شبكة حكومية"],
    },
    "الصرف الصحي: بيارة خاصة": {
      key: "sewage",
      terms: ["بيارة خاصة"],
    },
    "الاتصالات: خط تلفون": {
      key: "telecommunications",
      terms: ["خط تلفون"],
    },
    "الاتصالات: إنترنت ألياف ضوئية Fiber": {
      key: "telecommunications",
      terms: ["ألياف ضوئية", "Fiber"],
    },
  }

  return source.filter((property) => {
    if (hasUnsupportedCategory) return false
    if (commercialSelected && property.category !== "commercial") return false
    if (landSelected && property.category !== "land") return false
    if (hotelSelected && property.category !== "hotel") return false
    if (chaletSelected && property.category !== "chalet") return false
    if (selectedType && property.type !== selectedType) return false
    if (
      filters.governorate &&
      property.location.governorate !== filters.governorate
    )
      return false
    if (filters.district && property.location.district !== filters.district)
      return false
    if (
      filters.neighborhood &&
      property.location.neighborhood !== filters.neighborhood
    )
      return false
    if (manualLocation) {
      const searchableText = [
        property.title,
        property.subtitle,
        property.type,
        property.commercialType,
        property.shopLocation,
        property.landType,
        property.frontage?.join(" "),
        property.streetWidth,
        property.roomCategory,
        property.starRating ? "⭐".repeat(property.starRating) : "",
        property.privacy,
        property.chaletAmenities?.join(" "),
        propertyAddress(property),
      ]
        .join(" ")
        .toLocaleLowerCase("ar")
      if (!searchableText.includes(manualLocation)) return false
    }
    if (
      filters.currency &&
      !currencyMatches(property.currency, filters.currency)
    )
      return false
    if (minPrice !== undefined && property.price < minPrice) return false
    if (maxPrice !== undefined && property.price > maxPrice) return false
    if (filters.purpose && property.purpose !== filters.purpose) return false
    if (filters.payment && property.paymentMethod !== filters.payment)
      return false
    if (
      property.category === "residential" &&
      filters.furnishing &&
      property.furnishing !== filters.furnishing
    )
      return false
    if (
      property.category === "residential" &&
      (property.bedrooms < filters.bedrooms ||
        property.bathrooms < filters.bathrooms ||
        property.halls < filters.halls ||
        property.kitchens < filters.kitchens)
    )
      return false

    if (property.category === "commercial") {
      if (
        filters.commercialType &&
        property.commercialType !== filters.commercialType
      )
        return false
      if (filters.shopLocation && property.shopLocation !== filters.shopLocation)
        return false
      if (filters.finishing && property.finishing !== filters.finishing)
        return false
      if (minArea !== undefined && (property.area ?? 0) < minArea) return false
      if (maxArea !== undefined && (property.area ?? 0) > maxArea) return false
    }

    if (property.category === "land") {
      if (filters.landType && property.landType !== filters.landType)
        return false
      if (filters.streetWidth && property.streetWidth !== filters.streetWidth)
        return false
      if (
        !filters.frontage.every((frontage) =>
          property.frontage?.includes(
            frontage as NonNullable<Property["frontage"]>[number],
          ),
        )
      )
        return false
      if (minArea !== undefined && (property.area ?? 0) < minArea) return false
      if (maxArea !== undefined && (property.area ?? 0) > maxArea) return false
    }

    if (property.category === "hotel") {
      if (filters.starRating && property.starRating !== filters.starRating)
        return false
      if (
        filters.roomCategory &&
        property.roomCategory !== filters.roomCategory
      )
        return false
      if (filters.bedCount && (property.bedCount ?? 0) < filters.bedCount)
        return false
      if (filters.bedType && property.bedType !== filters.bedType) return false
    }

    if (property.category === "chalet") {
      if (filters.capacity && (property.capacity ?? 0) < filters.capacity)
        return false
      if (filters.privacy && property.privacy !== filters.privacy) return false
      if (
        !filters.amenities.every((amenity) =>
          property.chaletAmenities?.includes(amenity),
        )
      )
        return false
    }

    if (property.category === "residential" && filters.propertyAge) {
      const age = Math.max(
        0,
        new Date().getFullYear() - new Date(property.createdAt).getFullYear(),
      )
      if (filters.propertyAge === "جديد" && age > 1) return false
      if (filters.propertyAge === "أقل من 5 سنوات" && age > 5) return false
      if (filters.propertyAge === "بناء قديم" && age <= 5) return false
    }

    if (property.category === "residential") {
      const matchesInfrastructure = filters.infrastructure.every(
        (selection) => {
          const requirement = infrastructureTerms[selection]
          if (!requirement) return false
          const service = property.infrastructure[requirement.key]
          if (!service) return false
          const value = service.value.toLocaleLowerCase("ar")
          return requirement.terms.some((term) =>
            value.includes(term.toLocaleLowerCase("ar")),
          )
        },
      )
      if (!matchesInfrastructure) return false
    }
    if (
      property.category !== "chalet" &&
      !filters.amenities.every((amenity) =>
        property.amenities.includes(amenity),
      )
    )
      return false

    return true
  })
}

const propertyAddress = (property: Property) =>
  [
    property.location.neighborhood,
    property.location.district,
    property.location.governorate,
  ]
    .filter(Boolean)
    .join("، ")

const propertyPrice = (property: Property) =>
  `${property.price.toLocaleString("en-US")} ${property.currency}${
    property.pricePeriod ? ` / ${property.pricePeriod}` : ""
  }`

const infrastructureItems = (property: Property) =>
  Object.values(property.infrastructure).filter(
    (service): service is InfrastructureService => Boolean(service),
  )

function PropertySpecs({ property }: { property: Property }) {
  const specs =
    property.category === "commercial"
      ? [
          {
            label: "المساحة",
            value: `${property.area} م²`,
            icon: "land" as IconName,
          },
          {
            label: "نوع المحل",
            value: property.commercialType,
            icon: "shop" as IconName,
          },
          {
            label: "الموقع",
            value: property.shopLocation,
            icon: "pin" as IconName,
          },
          {
            label: "التشطيب",
            value: property.finishing,
            icon: "building" as IconName,
          },
        ]
      : property.category === "land"
        ? [
            {
              label: "المساحة",
              value: `${property.area} م²`,
              icon: "land" as IconName,
            },
            {
              label: "نوع الأرض",
              value: property.landType,
              icon: "land" as IconName,
            },
            {
              label: "الواجهة",
              value: property.frontage?.join("، "),
              icon: "pin" as IconName,
            },
            {
              label: "عرض الشارع",
              value: property.streetWidth,
              icon: "building" as IconName,
            },
          ]
        : property.category === "hotel"
          ? [
              {
                label: "التصنيف",
                value: "⭐".repeat(property.starRating ?? 0),
                icon: "hotel" as IconName,
              },
              {
                label: "نوع الغرفة",
                value: property.roomCategory,
                icon: "bed" as IconName,
              },
              {
                label: "عدد السراير",
                value: property.bedCount,
                icon: "bed" as IconName,
              },
              {
                label: "نوع السرير",
                value: property.bedType,
                icon: "sofa" as IconName,
              },
            ]
          : property.category === "chalet"
            ? [
                {
                  label: "السعة",
                  value: `${property.capacity} ضيوف`,
                  icon: "user" as IconName,
                },
                {
                  label: "الخصوصية",
                  value: property.privacy,
                  icon: "shield" as IconName,
                },
                {
                  label: "المسبح",
                  value: property.chaletAmenities?.includes("مسبح خاص")
                    ? "مسبح خاص"
                    : property.chaletAmenities?.includes("مسبح أطفال")
                      ? "مسبح أطفال"
                      : "بدون مسبح",
                  icon: "droplet" as IconName,
                },
                {
                  label: "المساحة الترفيهية",
                  value: property.chaletAmenities?.includes("مسطحات خضراء")
                    ? "مسطحات خضراء"
                    : property.chaletAmenities?.includes("جلسات خارجية")
                      ? "جلسات خارجية"
                      : property.chaletAmenities?.includes("مكان للشواء")
                        ? "مكان للشواء"
                        : "—",
                  icon: "land" as IconName,
                },
              ]
      : [
          {
            label: "حمامات",
            value: property.bathrooms,
            icon: "bath" as IconName,
          },
          {
            label: "مطابخ",
            value: property.kitchens,
            icon: "kitchen" as IconName,
          },
          { label: "صالات", value: property.halls, icon: "sofa" as IconName },
          { label: "غرف", value: property.bedrooms, icon: "bed" as IconName },
        ]

  return (
    <div className="grid grid-cols-4 divide-x divide-x-reverse divide-[var(--line)] rounded-xl bg-[var(--surface-soft)] py-2">
      {specs.map((spec) => (
        <div
          className="flex min-w-0 flex-col items-center gap-0.5 text-center"
          key={spec.label}
        >
          <Icon name={spec.icon} />
          <b
            className={`w-full px-0.5 text-center text-[var(--text)] ${
              property.category !== "residential"
                ? "line-clamp-2 text-[8px] leading-4"
                : "text-[11px]"
            }`}
          >
            {spec.value}
          </b>
          <span className="truncate text-[8px] text-[var(--text-muted)]">
            {spec.label}
          </span>
        </div>
      ))}
    </div>
  )
}

function InfrastructureSummary({ property }: { property: Property }) {
  const services = infrastructureItems(property)
  if (!services.length) return null

  return (
    <div className="border-y border-[var(--line)] py-2">
      <div className="mb-1.5 flex items-center gap-1 text-[9px] font-bold text-[var(--text)]">
        <Icon name="settings" />
        خدمات البنية التحتية
      </div>
      <div className="grid grid-cols-2 gap-1">
        {services.slice(0, 4).map((service) => (
          <div
            className="flex min-w-0 items-center gap-1 rounded-lg bg-[var(--surface-soft)] px-1.5 py-1"
            key={service.label}
            title={`${service.label}: ${service.value}`}
          >
            <span
              className={`shrink-0 ${
                service.status === "unavailable"
                  ? "text-[var(--text-dim)]"
                  : "text-[var(--primary-text)]"
              }`}
            >
              <Icon name={service.icon} />
            </span>
            <span className="min-w-0">
              <b className="block truncate text-[7px] text-[var(--text-muted)]">
                {service.label}
              </b>
              <small className="block truncate text-[8px] font-semibold text-[var(--text)]">
                {service.value}
              </small>
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

const reportReasons = [
  "عقار وهمي أو غير موجود",
  "السعر غير صحيح أو مضلل",
  "صور لا تطابق الواقع",
  "المالك لا يرد أو الرقم خاطئ",
  "سبب آخر",
]

function ReportReasonModal({
  onClose,
  onConfirm,
}: {
  onClose: () => void
  onConfirm: () => void
}) {
  const [reason, setReason] = useState("")
  const [otherReason, setOtherReason] = useState("")

  return (
    <div
      className="fixed inset-0 z-[80] flex items-end bg-[var(--overlay)] p-4 backdrop-blur-sm"
      onClick={(event) => event.stopPropagation()}
      onKeyDown={(event) => event.stopPropagation()}
      role="dialog"
      aria-modal="true"
      aria-labelledby="report-reason-title"
      dir="rtl"
    >
      <div className="mx-auto w-full max-w-md rounded-3xl border border-[var(--line)] bg-[var(--surface-raised)] p-5 text-right shadow-2xl">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div>
            <strong
              className="block text-sm font-extrabold text-[var(--text)]"
              id="report-reason-title"
            >
              سبب الإبلاغ
            </strong>
            <p className="mt-1 text-[10px] leading-5 text-[var(--text-muted)]">
              اختر السبب الأقرب لمساعدتنا في مراجعة العقار.
            </p>
          </div>
          <button
            className="grid size-9 shrink-0 place-items-center rounded-full border border-[var(--line)] text-[var(--text-muted)]"
            onClick={onClose}
            aria-label="إغلاق نافذة البلاغ"
            type="button"
          >
            <Icon name="close" />
          </button>
        </div>

        <div className="grid gap-2">
          {reportReasons.map((item) => (
            <button
              className={`min-h-11 rounded-xl border px-3 py-2 text-right text-[10px] font-bold transition ${
                reason === item
                  ? "border-[var(--primary)] bg-[var(--primary-soft)] text-[var(--primary-text)]"
                  : "border-[var(--line)] bg-[var(--surface)] text-[var(--text)]"
              }`}
              key={item}
              onClick={() => setReason(item)}
              aria-pressed={reason === item}
              type="button"
            >
              {item}
            </button>
          ))}
        </div>

        {reason === "سبب آخر" && (
          <input
            className="mt-3 h-11 w-full rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 text-xs text-[var(--text)] outline-none placeholder:text-[var(--text-muted)] focus:border-[var(--primary)]"
            value={otherReason}
            onChange={(event) => setOtherReason(event.target.value)}
            placeholder="اكتب السبب باختصار (اختياري)"
            maxLength={160}
          />
        )}

        <div className="mt-5 grid gap-2">
          <button
            className="min-h-12 rounded-xl bg-[var(--primary-strong)] px-4 text-xs font-bold text-[var(--dark-text)] disabled:cursor-not-allowed disabled:opacity-50"
            onClick={onConfirm}
            disabled={!reason}
            type="button"
          >
            تأكيد إرسال البلاغ
          </button>
          <button
            className="min-h-11 rounded-xl border border-[var(--line)] bg-[var(--surface)] px-4 text-xs font-bold text-[var(--text-muted)]"
            onClick={onClose}
            type="button"
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  )
}

function PropertyCard({
  property,
  onOpen,
  favorite,
  onToggleFavorite,
  reported,
  onReport,
}: {
  property: Property
  onOpen: (property: Property) => void
  favorite: boolean
  onToggleFavorite: (propertyId: string) => void
  reported: boolean
  onReport: (propertyId: string) => void
}) {
  const [notice, setNotice] = useState("")
  const [reportModalOpen, setReportModalOpen] = useState(false)

  const isolate =
    (action: () => void) => (event: React.MouseEvent<HTMLButtonElement>) => {
      event.stopPropagation()
      action()
    }

  const share = async () => {
    try {
      if (!navigator.share) throw new Error("Share unavailable")
      await navigator.share({
        title: property.title,
        text: `${property.title} — ${propertyAddress(property)}`,
      })
    } catch {
      await navigator.clipboard
        ?.writeText(property.title)
        .catch(() => undefined)
      setNotice("تم نسخ معلومات العقار")
    }
  }

  return (
    <article
      className="relative grid min-h-[360px] cursor-pointer grid-cols-[39%_61%] overflow-hidden rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] text-right shadow-sm transition hover:shadow-md"
      dir="ltr"
      onClick={() => onOpen(property)}
      onKeyDown={(event) => event.key === "Enter" && onOpen(property)}
      role="button"
      tabIndex={0}
      aria-label={`عرض تفاصيل ${property.title}`}
    >
      <div className="relative min-h-full overflow-hidden bg-[var(--surface-soft)]">
        <img
          className="absolute inset-0 h-full w-full object-cover"
          src={property.image}
          alt={property.alt}
          onError={(event) => {
            event.currentTarget.style.display = "none"
          }}
        />
        {property.featured && (
  <span className="absolute left-2 top-2 z-10 flex items-center gap-1 rounded-full bg-[var(--rating)] px-2 py-1 text-[8px] font-bold text-[var(--dark-text)] shadow">
    ⭐ مميز
  </span>
)}
        <button
          className={`absolute right-2 top-2 grid size-9 place-items-center rounded-full bg-[var(--surface-raised)] shadow ${
            favorite
              ? "favorite-active text-[var(--danger-text)]"
              : "text-[var(--text-muted)]"
          }`}
          onClick={isolate(() => onToggleFavorite(property.id))}
          aria-label={favorite ? "إزالة من المفضلة" : "إضافة إلى المفضلة"}
        >
          <Icon name="heart" />
        </button>
      </div>

      <div className="flex min-w-0 flex-col gap-2 p-3" dir="rtl">
        <div className="flex items-center justify-between gap-1">
          <div className="flex min-w-0 gap-1">
            <span className="rounded-full bg-[var(--primary-soft)] px-2 py-1 text-[8px] font-bold text-[var(--primary-text)]">
              {property.purpose}
            </span>
            {property.category === "hotel" ? (
              <span className="rounded-full bg-[var(--primary-soft)] px-2 py-1 text-[8px] font-bold text-[var(--primary-text)]">
                {"⭐".repeat(property.starRating ?? 0)}
              </span>
            ) : property.category === "chalet" ? (
              <span className="rounded-full bg-[var(--primary-soft)] px-2 py-1 text-[8px] font-bold text-[var(--primary-text)]">
                {property.capacity} ضيوف
              </span>
            ) : property.paymentMethod ? (
              <span className="rounded-full bg-[var(--primary-soft)] px-2 py-1 text-[8px] font-bold text-[var(--primary-text)]">
                {property.paymentMethod}
              </span>
            ) : null}
            <span className="truncate rounded-full bg-[var(--surface-soft)] px-2 py-1 text-[8px] font-bold text-[var(--text-muted)]">
              {property.category === "commercial"
                ? property.finishing
                : property.category === "land"
                  ? property.landType
                  : property.category === "hotel"
                    ? property.roomCategory
                    : property.category === "chalet"
                      ? property.privacy
                      : property.furnishing}
            </span>
          </div>
          <div className="flex gap-1">
            <button
              className="grid size-7 place-items-center rounded-full border border-[var(--line)] text-[var(--text-muted)]"
              onClick={isolate(() => void share())}
              aria-label="مشاركة العقار"
            >
              <Icon name="share" />
            </button>
            <button
              className={`grid size-7 place-items-center rounded-full border text-[var(--danger-text)] ${
                reported
                  ? "border-[var(--danger)] bg-[var(--danger-soft)]"
                  : "border-[var(--line)]"
              }`}
              onClick={isolate(() => {
                if (reported) {
                  onReport(property.id)
                  setNotice("تم إلغاء البلاغ")
                } else {
                  setReportModalOpen(true)
                }
              })}
              aria-label={reported ? "إلغاء البلاغ عن العقار" : "إبلاغ عن العقار"}
            >
              <Icon name="warning" />
            </button>
          </div>
        </div>

        <div className="min-w-0">
          <strong className="block truncate text-[12px] font-extrabold text-[var(--text)]">
            {property.title}
          </strong>
          <p className="mt-1 flex items-center gap-1 truncate text-[9px] text-[var(--text-muted)]">
            <Icon name="pin" />
            {propertyAddress(property)}
          </p>
        </div>

        <b
          className="text-[13px] font-extrabold text-[var(--primary-text)]"
          dir="rtl"
        >
          {propertyPrice(property)}
        </b>

        <PropertySpecs property={property} />
        {property.category !== "residential" ? (
          <div className="border-y border-[var(--line)] py-2">
            <div className="mb-1.5 flex items-center gap-1 text-[9px] font-bold text-[var(--text)]">
              <Icon name="settings" />
              {property.category === "commercial"
                ? "المرافق والإضافات"
                : property.category === "chalet"
                  ? "المميزات الترفيهية"
                  : property.category === "land" ||
                      property.category === "hotel"
                    ? "المرافق والخدمات"
                  : "المرافق والإضافات"}
            </div>
            <div className="flex flex-wrap gap-1">
              {(property.category === "chalet"
                ? property.chaletAmenities ?? []
                : property.amenities
              ).map((amenity) => (
                <span
                  className="max-w-full truncate rounded-full bg-[var(--surface-soft)] px-2 py-1 text-[7px] font-semibold text-[var(--text-muted)]"
                  key={amenity}
                  title={amenity}
                >
                  {amenity}
                </span>
              ))}
            </div>
          </div>
        ) : (
          <InfrastructureSummary property={property} />
        )}

        <div className="mt-auto flex items-center gap-2">
          <span className="grid size-7 shrink-0 place-items-center rounded-full bg-[var(--primary-soft)] text-[9px] font-extrabold text-[var(--primary-text)]">
            {property.owner.initials}
          </span>
          <span className="min-w-0 flex-1">
            <b className="block truncate text-[9px] text-[var(--text)]">
              {property.owner.name}
            </b>
            <small className="flex items-center gap-0.5 text-[8px] text-[var(--text-muted)]">
              <span className="text-[var(--primary-text)]">
                <Icon name="star" />
              </span>
              {property.owner.rating} ({property.owner.reviewCount})
            </small>
          </span>
        </div>
      </div>

      {notice && (
        <span className="absolute bottom-2 left-2 z-10 rounded-lg bg-[var(--overlay)] px-2 py-1 text-[8px] text-[var(--dark-text)]">
          {notice}
        </span>
      )}
      {reportModalOpen && (
        <ReportReasonModal
          onClose={() => setReportModalOpen(false)}
          onConfirm={() => {
            onReport(property.id)
            setReportModalOpen(false)
            setNotice("تم إرسال البلاغ للمراجعة")
          }}
        />
      )}
    </article>
  )
}

function HomesApartments({
  go,
  onOpenFilters,
  onOpen,
  favoriteIds,
  onToggleFavorite,
  reportedPropertyIds,
  onReportProperty,
}: {
  go: (screen: number) => void
  onOpenFilters: () => void
  onOpen: (property: Property) => void
  favoriteIds: Set<string>
  onToggleFavorite: (propertyId: string) => void
  reportedPropertyIds: Set<string>
  onReportProperty: (propertyId: string) => void
}) {
  const [category, setCategory] = useState("الكل")
  const [sort, setSort] = useState("الأحدث")
  const categoryMap: Record<string, Property["type"] | undefined> = {
    الكل: undefined,
    شقق: "شقة",
    "منازل مستقلة": "منزل مستقل",
    فلل: "فيلا",
  }
  const visible = properties
    .filter((property) => property.category === "residential")
    .filter(
      (property) =>
        !categoryMap[category] || property.type === categoryMap[category],
    )
    .sort((a, b) => {
      if (sort === "السعر: الأقل") return a.price - b.price
      if (sort === "السعر: الأعلى") return b.price - a.price
      return Date.parse(b.createdAt) - Date.parse(a.createdAt)
    })

  return (
    <section className="screen !bg-[var(--surface-soft)] text-[var(--text)]">
      <header
        className="flex items-center justify-between border-b border-[var(--line)] bg-[var(--surface-raised)] px-4 pb-3 pt-9"
        dir="rtl"
      >
        <button
          className="grid size-10 place-items-center rounded-full border border-[var(--line)] text-[var(--text)]"
          onClick={() => go(-1)}
          aria-label="رجوع"
        >
          <Icon name="arrow" />
        </button>
        <h1 className="!text-lg !font-extrabold !text-[var(--text)]" dir="rtl">
          المنازل والشقق
        </h1>
        <button
          className="grid size-10 place-items-center rounded-full bg-[var(--primary-strong)] text-[var(--dark-text)] shadow-sm"
          onClick={onOpenFilters}
          aria-label="فتح تصفية البحث"
        >
          <Icon name="filter" />
        </button>
      </header>

      <main className="min-h-0 flex-1 overflow-y-auto px-4 pb-24 pt-4">
        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 [scrollbar-width:none]">
          {Object.keys(categoryMap).map((item) => (
            <button
              className={`shrink-0 rounded-full px-4 py-2 text-xs font-bold ${
                category === item
                  ? "bg-[var(--primary-strong)] text-[var(--dark-text)] shadow-sm"
                  : "border border-[var(--line)] bg-[var(--surface-raised)] text-[var(--text)]"
              }`}
              key={item}
              onClick={() => setCategory(item)}
            >
              {item}
            </button>
          ))}
        </div>

        <label
          className="my-3 flex w-full items-center justify-start gap-1 text-right text-[11px] text-[var(--text-muted)]"
          dir="rtl"
        >
          ترتيب حسب:
          <select
            className="border-0 bg-[var(--transparent)] font-bold text-[var(--text)] outline-none"
            value={sort}
            onChange={(event) => setSort(event.target.value)}
            aria-label="ترتيب العقارات"
          >
            <option>الأحدث</option>
            <option>السعر: الأقل</option>
            <option>السعر: الأعلى</option>
          </select>
        </label>

        <div className="grid gap-4">
          {visible.map((property) => (
            <PropertyCard
              key={property.id}
              property={property}
              onOpen={onOpen}
              favorite={favoriteIds.has(property.id)}
              onToggleFavorite={onToggleFavorite}
              reported={reportedPropertyIds.has(property.id)}
              onReport={onReportProperty}
            />
          ))}
        </div>
        {!visible.length && (
          <div className="py-16 text-center text-sm text-[var(--text-muted)]">
            لا توجد عقارات في هذا التصنيف حالياً.
          </div>
        )}
      </main>

      <nav
  className="bottom-nav account-bottom-nav"
  aria-label="التنقل الرئيسي"
>
  {bottomNav.map((item, index) => (
    <button
      key={item.label}
      className={index === 0 ? "active" : ""}
      onClick={() => go(item.target)}
    >
      <Icon name={item.icon} />
      <span>{item.label}</span>
    </button>
  ))}
</nav>
      
    </section>
  )
}

function CommercialShops({
  go,
  onOpenFilters,
  onOpen,
  favoriteIds,
  onToggleFavorite,
  reportedPropertyIds,
  onReportProperty,
}: {
  go: (screen: number) => void
  onOpenFilters: () => void
  onOpen: (property: Property) => void
  favoriteIds: Set<string>
  onToggleFavorite: (propertyId: string) => void
  reportedPropertyIds: Set<string>
  onReportProperty: (propertyId: string) => void
}) {
  const [category, setCategory] = useState("الكل")
  const [sort, setSort] = useState("الأحدث")
  const categories = [
    "الكل",
    "مكتب تجاري",
    "معرض",
    "مطعم/مقهى",
    "صيدلية",
    "مستودع",
    "محل عام",
  ]
  const visible = properties
    .filter((property) => property.category === "commercial")
    .filter(
      (property) =>
        category === "الكل" || property.commercialType === category,
    )
    .sort((a, b) => {
      if (sort === "السعر: الأقل") return a.price - b.price
      if (sort === "السعر: الأعلى") return b.price - a.price
      return Date.parse(b.createdAt) - Date.parse(a.createdAt)
    })

  return (
    <section className="screen !bg-[var(--surface-soft)] text-[var(--text)]">
      <header
        className="flex items-center justify-between border-b border-[var(--line)] bg-[var(--surface-raised)] px-4 pb-3 pt-9"
        dir="rtl"
      >
        <button
          className="grid size-10 place-items-center rounded-full border border-[var(--line)] text-[var(--text)]"
          onClick={() => go(-1)}
          aria-label="رجوع"
        >
          <Icon name="arrow" />
        </button>
        <h1 className="!text-lg !font-extrabold !text-[var(--text)]" dir="rtl">
          المحلات التجارية
        </h1>
        <button
          className="grid size-10 place-items-center rounded-full bg-[var(--primary-strong)] text-[var(--dark-text)] shadow-sm"
          onClick={onOpenFilters}
          aria-label="فتح تصفية المحلات التجارية"
        >
          <Icon name="filter" />
        </button>
      </header>

      <main className="min-h-0 flex-1 overflow-y-auto px-4 pb-24 pt-4">
        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 [scrollbar-width:none]">
          {categories.map((item) => (
            <button
              className={`shrink-0 rounded-full px-4 py-2 text-xs font-bold ${
                category === item
                  ? "bg-[var(--primary-strong)] text-[var(--dark-text)] shadow-sm"
                  : "border border-[var(--line)] bg-[var(--surface-raised)] text-[var(--text)]"
              }`}
              key={item}
              onClick={() => setCategory(item)}
            >
              {item}
            </button>
          ))}
        </div>

        <label
          className="my-3 flex w-full items-center justify-start gap-1 text-right text-[11px] text-[var(--text-muted)]"
          dir="rtl"
        >
          ترتيب حسب:
          <select
            className="border-0 bg-[var(--transparent)] font-bold text-[var(--text)] outline-none"
            value={sort}
            onChange={(event) => setSort(event.target.value)}
            aria-label="ترتيب المحلات التجارية"
          >
            <option>الأحدث</option>
            <option>السعر: الأقل</option>
            <option>السعر: الأعلى</option>
          </select>
        </label>

        <div className="grid gap-4">
          {visible.map((property) => (
            <PropertyCard
              key={property.id}
              property={property}
              onOpen={onOpen}
              favorite={favoriteIds.has(property.id)}
              onToggleFavorite={onToggleFavorite}
              reported={reportedPropertyIds.has(property.id)}
              onReport={onReportProperty}
            />
          ))}
        </div>
        {!visible.length && (
          <div className="py-16 text-center text-sm text-[var(--text-muted)]">
            لا توجد محلات تجارية في هذا التصنيف حالياً.
          </div>
        )}
      </main>
<nav
  className="bottom-nav account-bottom-nav"
  aria-label="التنقل الرئيسي"
>
  {bottomNav.map((item, index) => (
    <button
      key={item.label}
      className={index === 0 ? "active" : ""}
      onClick={() => go(item.target)}
    >
      <Icon name={item.icon} />
      <span>{item.label}</span>
    </button>
  ))}
</nav>
    </section>
  )
}

function LandsScreen({
  go,
  onOpenFilters,
  onOpen,
  favoriteIds,
  onToggleFavorite,
  reportedPropertyIds,
  onReportProperty,
}: {
  go: (screen: number) => void
  onOpenFilters: () => void
  onOpen: (property: Property) => void
  favoriteIds: Set<string>
  onToggleFavorite: (propertyId: string) => void
  reportedPropertyIds: Set<string>
  onReportProperty: (propertyId: string) => void
}) {
  const [category, setCategory] = useState("الكل")
  const [sort, setSort] = useState("الأحدث")
  const categories = ["الكل", "سكنية", "تجارية", "زراعية", "صناعية"]
  const visible = properties
    .filter((property) => property.category === "land")
    .filter(
      (property) => category === "الكل" || property.landType === category,
    )
    .sort((a, b) => {
      if (sort === "السعر: الأقل") return a.price - b.price
      if (sort === "السعر: الأعلى") return b.price - a.price
      return Date.parse(b.createdAt) - Date.parse(a.createdAt)
    })

  return (
    <section className="screen !bg-[var(--surface-soft)] text-[var(--text)]">
      <header
        className="flex items-center justify-between border-b border-[var(--line)] bg-[var(--surface-raised)] px-4 pb-3 pt-9"
        dir="rtl"
      >
        <button
          className="grid size-10 place-items-center rounded-full border border-[var(--line)] text-[var(--text)]"
          onClick={() => go(-1)}
          aria-label="رجوع"
        >
          <Icon name="arrow" />
        </button>
        <h1 className="!text-lg !font-extrabold !text-[var(--text)]" dir="rtl">
          الأراضي
        </h1>
        <button
          className="grid size-10 place-items-center rounded-full bg-[var(--primary-strong)] text-[var(--dark-text)] shadow-sm"
          onClick={onOpenFilters}
          aria-label="فتح تصفية الأراضي"
        >
          <Icon name="filter" />
        </button>
      </header>

      <main className="min-h-0 flex-1 overflow-y-auto px-4 pb-24 pt-4">
        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 [scrollbar-width:none]">
          {categories.map((item) => (
            <button
              className={`shrink-0 rounded-full px-4 py-2 text-xs font-bold ${
                category === item
                  ? "bg-[var(--primary-strong)] text-[var(--dark-text)] shadow-sm"
                  : "border border-[var(--line)] bg-[var(--surface-raised)] text-[var(--text)]"
              }`}
              key={item}
              onClick={() => setCategory(item)}
            >
              {item}
            </button>
          ))}
        </div>

        <label
          className="my-3 flex w-full items-center justify-start gap-1 text-right text-[11px] text-[var(--text-muted)]"
          dir="rtl"
        >
          ترتيب حسب:
          <select
            className="border-0 bg-[var(--transparent)] font-bold text-[var(--text)] outline-none"
            value={sort}
            onChange={(event) => setSort(event.target.value)}
            aria-label="ترتيب الأراضي"
          >
            <option>الأحدث</option>
            <option>السعر: الأقل</option>
            <option>السعر: الأعلى</option>
          </select>
        </label>

        <div className="grid gap-4">
          {visible.map((property) => (
            <PropertyCard
              key={property.id}
              property={property}
              onOpen={onOpen}
              favorite={favoriteIds.has(property.id)}
              onToggleFavorite={onToggleFavorite}
              reported={reportedPropertyIds.has(property.id)}
              onReport={onReportProperty}
            />
          ))}
        </div>
        {!visible.length && (
          <div className="py-16 text-center text-sm text-[var(--text-muted)]">
            لا توجد أراضٍ في هذا التصنيف حالياً.
          </div>
        )}
      </main>

      <nav
  className="bottom-nav account-bottom-nav"
  aria-label="التنقل الرئيسي"
>
  {bottomNav.map((item, index) => (
    <button
      key={item.label}
      className={index === 0 ? "active" : ""}
      onClick={() => go(item.target)}
    >
      <Icon name={item.icon} />
      <span>{item.label}</span>
    </button>
  ))}
</nav>
      
    </section>
  )
}

function HotelsScreen({
  go,
  onOpenFilters,
  onOpen,
  favoriteIds,
  onToggleFavorite,
  reportedPropertyIds,
  onReportProperty,
}: {
  go: (screen: number) => void
  onOpenFilters: () => void
  onOpen: (property: Property) => void
  favoriteIds: Set<string>
  onToggleFavorite: (propertyId: string) => void
  reportedPropertyIds: Set<string>
  onReportProperty: (propertyId: string) => void
}) {
  const [category, setCategory] = useState("الكل")
  const [sort, setSort] = useState("الأحدث")
  const categories = ["الكل", "⭐", "⭐⭐", "⭐⭐⭐", "⭐⭐⭐⭐", "⭐⭐⭐⭐⭐"]
  const visible = properties
    .filter((property) => property.category === "hotel")
    .filter(
      (property) =>
        category === "الكل" ||
        "⭐".repeat(property.starRating ?? 0) === category,
    )
    .sort((a, b) => {
      if (sort === "السعر: الأقل") return a.price - b.price
      if (sort === "السعر: الأعلى") return b.price - a.price
      return Date.parse(b.createdAt) - Date.parse(a.createdAt)
    })

  return (
    <section className="screen !bg-[var(--surface-soft)] text-[var(--text)]">
      <header
        className="flex items-center justify-between border-b border-[var(--line)] bg-[var(--surface-raised)] px-4 pb-3 pt-9"
        dir="rtl"
      >
        <button
          className="grid size-10 place-items-center rounded-full border border-[var(--line)] text-[var(--text)]"
          onClick={() => go(-1)}
          aria-label="رجوع"
        >
          <Icon name="arrow" />
        </button>
        <h1 className="!text-lg !font-extrabold !text-[var(--text)]" dir="rtl">
          الفنادق
        </h1>
        <button
          className="grid size-10 place-items-center rounded-full bg-[var(--primary-strong)] text-[var(--dark-text)] shadow-sm"
          onClick={onOpenFilters}
          aria-label="فتح تصفية الفنادق"
        >
          <Icon name="filter" />
        </button>
      </header>

      <main className="min-h-0 flex-1 overflow-y-auto px-4 pb-24 pt-4">
        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 [scrollbar-width:none]">
          {categories.map((item) => (
            <button
              className={`shrink-0 rounded-full px-4 py-2 text-xs font-bold ${
                category === item
                  ? "bg-[var(--primary-strong)] text-[var(--dark-text)] shadow-sm"
                  : "border border-[var(--line)] bg-[var(--surface-raised)] text-[var(--text)]"
              }`}
              key={item}
              onClick={() => setCategory(item)}
            >
              {item}
            </button>
          ))}
        </div>

        <label
          className="my-3 flex w-full items-center justify-start gap-1 text-right text-[11px] text-[var(--text-muted)]"
          dir="rtl"
        >
          ترتيب حسب:
          <select
            className="border-0 bg-[var(--transparent)] font-bold text-[var(--text)] outline-none"
            value={sort}
            onChange={(event) => setSort(event.target.value)}
            aria-label="ترتيب الفنادق"
          >
            <option>الأحدث</option>
            <option>السعر: الأقل</option>
            <option>السعر: الأعلى</option>
          </select>
        </label>

        <div className="grid gap-4">
          {visible.map((property) => (
            <PropertyCard
              key={property.id}
              property={property}
              onOpen={onOpen}
              favorite={favoriteIds.has(property.id)}
              onToggleFavorite={onToggleFavorite}
              reported={reportedPropertyIds.has(property.id)}
              onReport={onReportProperty}
            />
          ))}
        </div>
        {!visible.length && (
          <div className="py-16 text-center text-sm text-[var(--text-muted)]">
            لا توجد فنادق في هذا التصنيف حالياً.
          </div>
        )}
      </main>

      <nav
  className="bottom-nav account-bottom-nav"
  aria-label="التنقل الرئيسي"
>
  {bottomNav.map((item, index) => (
    <button
      key={item.label}
      className={index === 0 ? "active" : ""}
      onClick={() => go(item.target)}
    >
      <Icon name={item.icon} />
      <span>{item.label}</span>
    </button>
  ))}
</nav>
    </section>
  )
}

function ChaletsScreen({
  go,
  onOpenFilters,
  onOpen,
  favoriteIds,
  onToggleFavorite,
  reportedPropertyIds,
  onReportProperty,
}: {
  go: (screen: number) => void
  onOpenFilters: () => void
  onOpen: (property: Property) => void
  favoriteIds: Set<string>
  onToggleFavorite: (propertyId: string) => void
  reportedPropertyIds: Set<string>
  onReportProperty: (propertyId: string) => void
}) {
  const [category, setCategory] = useState("الكل")
  const [sort, setSort] = useState("الأحدث")
  const categories = [
    "الكل",
    "مسبح خاص",
    "مسبح أطفال",
    "إطلالة بانورامية",
    "سور مستقل",
    "جاكوزي",
  ]
  const visible = properties
    .filter((property) => property.category === "chalet")
    .filter((property) => {
      if (category === "الكل") return true
      if (category === "إطلالة بانورامية") {
        return property.privacy === "إطلالة بانورامية"
      }
      if (category === "سور مستقل") {
        return property.privacy === "سور مستقل مرتفع"
      }
      return property.chaletAmenities?.includes(category)
    })
    .sort((a, b) => {
      if (sort === "السعر: الأقل") return a.price - b.price
      if (sort === "السعر: الأعلى") return b.price - a.price
      return Date.parse(b.createdAt) - Date.parse(a.createdAt)
    })

  return (
    <section className="screen !bg-[var(--surface-soft)] text-[var(--text)]">
      <header
        className="flex items-center justify-between border-b border-[var(--line)] bg-[var(--surface-raised)] px-4 pb-3 pt-9"
        dir="rtl"
      >
        <button
          className="grid size-10 place-items-center rounded-full border border-[var(--line)] text-[var(--text)]"
          onClick={() => go(-1)}
          aria-label="رجوع"
        >
          <Icon name="arrow" />
        </button>
        <h1 className="!text-lg !font-extrabold !text-[var(--text)]" dir="rtl">
          الشاليهات
        </h1>
        <button
          className="grid size-10 place-items-center rounded-full bg-[var(--primary-strong)] text-[var(--dark-text)] shadow-sm"
          onClick={onOpenFilters}
          aria-label="فتح تصفية الشاليهات"
        >
          <Icon name="filter" />
        </button>
      </header>

      <main className="min-h-0 flex-1 overflow-y-auto px-4 pb-24 pt-4">
        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 [scrollbar-width:none]">
          {categories.map((item) => (
            <button
              className={`shrink-0 rounded-full px-4 py-2 text-xs font-bold ${
                category === item
                  ? "bg-[var(--primary-strong)] text-[var(--dark-text)] shadow-sm"
                  : "border border-[var(--line)] bg-[var(--surface-raised)] text-[var(--text)]"
              }`}
              key={item}
              onClick={() => setCategory(item)}
            >
              {item}
            </button>
          ))}
        </div>

        <label
          className="my-3 flex w-full items-center justify-start gap-1 text-right text-[11px] text-[var(--text-muted)]"
          dir="rtl"
        >
          ترتيب حسب:
          <select
            className="border-0 bg-[var(--transparent)] font-bold text-[var(--text)] outline-none"
            value={sort}
            onChange={(event) => setSort(event.target.value)}
            aria-label="ترتيب الشاليهات"
          >
            <option>الأحدث</option>
            <option>السعر: الأقل</option>
            <option>السعر: الأعلى</option>
          </select>
        </label>

        <div className="grid gap-4">
          {visible.map((property) => (
            <PropertyCard
              key={property.id}
              property={property}
              onOpen={onOpen}
              favorite={favoriteIds.has(property.id)}
              onToggleFavorite={onToggleFavorite}
              reported={reportedPropertyIds.has(property.id)}
              onReport={onReportProperty}
            />
          ))}
        </div>
        {!visible.length && (
          <div className="py-16 text-center text-sm text-[var(--text-muted)]">
            لا توجد شاليهات في هذا التصنيف حالياً.
          </div>
        )}
      </main>

      <nav
  className="bottom-nav account-bottom-nav"
  aria-label="التنقل الرئيسي"
>
  {bottomNav.map((item, index) => (
    <button
      key={item.label}
      className={index === 0 ? "active" : ""}
      onClick={() => go(item.target)}
    >
      <Icon name={item.icon} />
      <span>{item.label}</span>
    </button>
  ))}
</nav>
    </section>
  )
}

function SearchResults({
  go,
  onOpen,
  results,
  favoriteIds,
  onToggleFavorite,
  reportedPropertyIds,
  onReportProperty,
  onReset,
}: {
  go: (screen: number) => void
  onOpen: (property: Property) => void
  results: Property[]
  favoriteIds: Set<string>
  onToggleFavorite: (propertyId: string) => void
  reportedPropertyIds: Set<string>
  onReportProperty: (propertyId: string) => void
  onReset: () => void
}) {
  const [saved, setSaved] = useState(false)

  return (
    <section className="screen feature-screen">
      <PageHeader title="نتائج البحث" go={go} />
      <main className="results-content">
        <button
          className={saved ? "save-search saved" : "save-search"}
          onClick={() => setSaved(!saved)}
        >
          <span>
            <Icon name="bell" />
          </span>
          <div>
            <strong>{saved ? "تم حفظ البحث" : "حفظ البحث"}</strong>
            <p>سنخبرك عند إضافة عقارات جديدة مطابقة</p>
          </div>
          <b>{saved ? "✓" : "+"}</b>
        </button>

        <div className="results-heading">
          <div>
            <h2>العقارات المتاحة</h2>
            <p>
              {results.length
                ? `وجدنا ${results.length} عقارات تناسب بحثك`
                : "لا توجد نتائج مطابقة"}
            </p>
          </div>
          <button onClick={() => go(16)}>
            <Icon name="filter" />
            تعديل
          </button>
        </div>

        {results.length ? (
          <div className="property-list">
            {results.map((property) => (
              <PropertyCard
                key={property.id}
                property={property}
                onOpen={onOpen}
                favorite={favoriteIds.has(property.id)}
                onToggleFavorite={onToggleFavorite}
                reported={reportedPropertyIds.has(property.id)}
                onReport={onReportProperty}
              />
            ))}
          </div>
        ) : (
          <div className="rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-6 text-center">
            <span className="mx-auto grid size-16 place-items-center rounded-2xl bg-[var(--primary-soft)] text-[var(--primary-text)]">
              <Icon name="search" />
            </span>
            <h2 className="mt-4 text-sm font-extrabold text-[var(--text)]">
              عذراً، لم نجد عقارات مطابقة لبحثك
            </h2>
            <p className="mt-2 text-xs leading-6 text-[var(--text-muted)]">
              جرّب تعديل الخيارات أو أرسل طلباً مخصصاً وسنساعدك في العثور على
              العقار.
            </p>
            <div className="mt-5 grid gap-2">
              <button
                className="min-h-11 rounded-xl bg-[var(--primary-strong)] px-4 text-xs font-bold text-[var(--dark-text)]"
                onClick={onReset}
              >
                إعادة ضبط الفلاتر
              </button>
              <button
                className="min-h-11 rounded-xl border border-[var(--line)] bg-[var(--surface)] px-4 text-xs font-bold text-[var(--text)]"
                onClick={() => go(34)}
              >
                <span aria-hidden="true">📝</span> طلب عقار مخصص
              </button>
              <button
                className="min-h-11 rounded-xl border border-[var(--primary)] bg-[var(--primary-soft)] px-4 text-xs font-bold text-[var(--primary-text)]"
                onClick={() => go(17)}
              >
                <span aria-hidden="true">✨</span> ابحث بالذكاء الاصطناعي
              </button>
            </div>
          </div>
        )}
      </main>
    </section>
  )
}

function FavoritesScreen({
  go,
  onOpen,
  favoriteIds,
  onToggleFavorite,
  reportedPropertyIds,
  onReportProperty,
}: {
  go: (screen: number) => void
  onOpen: (property: Property) => void
  favoriteIds: Set<string>
  onToggleFavorite: (propertyId: string) => void
  reportedPropertyIds: Set<string>
  onReportProperty: (propertyId: string) => void
}) {
  const favorites = properties.filter((property) =>
    favoriteIds.has(property.id),
  )

  return (
    <section className="screen feature-screen">
      <PageHeader title="المفضلة" go={go} />
      <main className="results-content">
        <div className="favorites-summary">
          <span>
            <Icon name="heart" />
          </span>
          <div>
            <strong>عقاراتك المحفوظة</strong>
            <p>احتفظنا بخياراتك المفضلة لتعود إليها في أي وقت.</p>
          </div>
          <b>{favorites.length}</b>
        </div>
        <div className="results-heading">
          <div>
            <h2>قائمة المفضلة</h2>
            <p>{favorites.length} عقارات محفوظة</p>
          </div>
        </div>
        <div className="property-list">
          {favorites.map((property) => (
            <PropertyCard
              key={property.id}
              property={property}
              onOpen={onOpen}
              favorite
              onToggleFavorite={onToggleFavorite}
              reported={reportedPropertyIds.has(property.id)}
              onReport={onReportProperty}
            />
          ))}
          {!favorites.length && (
            <div className="rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-6 text-center">
              <Icon name="heart" />
              <strong className="mt-3 block text-sm text-[var(--text)]">
                لم تضف أي عقار إلى المفضلة بعد
              </strong>
              <button
                className="mt-4 rounded-xl bg-[var(--primary-strong)] px-4 py-3 text-xs font-bold text-[var(--dark-text)]"
                onClick={() => go(14)}
              >
                استكشف العقارات
              </button>
            </div>
          )}
        </div>
      </main>
    </section>
  )
}

function PropertyReviewsSection({
  property,
  reviews,
  onAddReview,
  onDeleteReview,
}: {
  property: Property
  reviews: PropertyReview[]
  onAddReview: (propertyId: string, rating: number, text: string) => void
  onDeleteReview: (reviewId: string) => void
}) {
  const [formOpen, setFormOpen] = useState(false)
  const [rating, setRating] = useState(0)
  const [text, setText] = useState("")
  const [feedback, setFeedback] = useState("")
  const propertyReviews = reviews
    .filter((review) => review.propertyId === property.id)
    .sort((a, b) => b.createdAt - a.createdAt)
  const average = propertyReviews.length
    ? propertyReviews.reduce((total, review) => total + review.rating, 0) /
      propertyReviews.length
    : 0

  const submitReview = (event: FormEvent) => {
    event.preventDefault()
    if (!rating) {
      setFeedback("اختر عدد النجوم أولاً")
      return
    }
    if (!text.trim()) {
      setFeedback("اكتب تعليقك قبل نشر التقييم")
      return
    }
    onAddReview(property.id, rating, text.trim())
    setRating(0)
    setText("")
    setFormOpen(false)
    setFeedback("تم نشر تقييمك بنجاح")
  }

  return (
    <section className="rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-4 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-extrabold text-[var(--text)]">
            التقييمات والمراجعات
          </h2>
          <p className="mt-1 text-[10px] text-[var(--text-muted)]">
            {propertyReviews.length} مراجعات
          </p>
        </div>
        <button
          className="rounded-xl bg-[var(--primary-soft)] px-3 py-2 text-[10px] font-bold text-[var(--primary-text)]"
          onClick={() => {
            setFormOpen((current) => !current)
            setFeedback("")
          }}
        >
          أضف تقييمك
        </button>
      </div>

      {feedback && (
        <p
          className={`mt-3 rounded-xl p-3 text-[10px] font-bold ${
            feedback === "تم نشر تقييمك بنجاح"
              ? "bg-[var(--primary-soft)] text-[var(--primary-text)]"
              : "bg-[var(--danger-soft)] text-[var(--danger-text)]"
          }`}
          role="status"
        >
          {feedback}
        </p>
      )}

      <div className="mt-4 grid grid-cols-[auto_1fr] gap-4 rounded-2xl bg-[var(--surface-soft)] p-4">
        <div className="text-center">
          <strong className="block text-3xl text-[var(--text)]">
            {average ? average.toFixed(1) : "—"}
          </strong>
          <span className="text-xs text-[var(--primary-text)]">
            {average ? "★".repeat(Math.round(average)) : "بدون تقييم"}
          </span>
          <small className="mt-1 block text-[9px] text-[var(--text-muted)]">
            {propertyReviews.length} إجمالي
          </small>
        </div>
        <div className="grid gap-1.5">
          {[5, 4, 3, 2, 1].map((star) => {
            const count = propertyReviews.filter(
              (review) => review.rating === star,
            ).length
            const percentage = propertyReviews.length
              ? (count / propertyReviews.length) * 100
              : 0
            return (
              <div
                className="grid grid-cols-[1.5rem_1fr_1.2rem] items-center gap-2 text-[9px] text-[var(--text-muted)]"
                key={star}
              >
                <span>{star}★</span>
                <span className="h-1.5 overflow-hidden rounded-full bg-[var(--line)]">
                  <span
                    className="block h-full rounded-full bg-[var(--primary)] transition-[width]"
                    style={{ width: `${percentage}%` }}
                  />
                </span>
                <span>{count}</span>
              </div>
            )
          })}
        </div>
      </div>

      {formOpen && (
        <form
          className="mt-4 grid gap-3 rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-4"
          onSubmit={submitReview}
        >
          <div>
            <span className="text-xs font-bold text-[var(--text)]">
              اختر تقييمك
            </span>
            <div className="mt-2 flex gap-1" dir="ltr">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  className={`text-2xl transition ${
                    star <= rating
                      ? "text-[var(--rating)]"
                      : "text-[var(--text-dim)]"
                  }`}
                  key={star}
                  type="button"
                  onClick={() => {
                    setRating(star)
                    setFeedback("")
                  }}
                  aria-label={`${star} نجوم`}
                >
                  ★
                </button>
              ))}
            </div>
          </div>
          <textarea
            className="min-h-24 w-full resize-none rounded-xl border border-[var(--line)] bg-[var(--surface-raised)] p-3 text-xs leading-6 text-[var(--text)] outline-none placeholder:text-[var(--text-dim)] focus:border-[var(--primary)]"
            value={text}
            onChange={(event) => setText(event.target.value)}
            placeholder="اكتب رأيك هنا..."
            maxLength={500}
          />
          <div className="flex gap-2">
            <button
              className="min-h-11 flex-1 rounded-xl bg-[var(--primary-strong)] px-4 text-xs font-bold text-[var(--dark-text)]"
              type="submit"
            >
              نشر التقييم
            </button>
            <button
              className="min-h-11 rounded-xl border border-[var(--line)] bg-[var(--surface-raised)] px-4 text-xs font-bold text-[var(--text-muted)]"
              type="button"
              onClick={() => {
                setFormOpen(false)
                setRating(0)
                setText("")
                setFeedback("")
              }}
            >
              إلغاء
            </button>
          </div>
        </form>
      )}

      <div className="mt-4 grid gap-3">
        {propertyReviews.map((review) => (
          <article
            className={`rounded-2xl border p-4 ${
              review.isNew
                ? "border-[var(--primary)] bg-[var(--primary-soft)]"
                : "border-[var(--line)] bg-[var(--surface)]"
            }`}
            key={review.id}
          >
            <div className="flex items-start gap-3">
              <span className="grid size-10 shrink-0 place-items-center rounded-full bg-[var(--surface-soft)] text-[10px] font-extrabold text-[var(--text)]">
                {review.userInitials}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <strong className="block text-xs text-[var(--text)]">
                      {review.userName}
                    </strong>
                    <span className="text-[10px] text-[var(--primary-text)]">
                      {"★".repeat(review.rating)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {review.isNew && (
                      <span className="rounded-full bg-[var(--primary-strong)] px-2 py-1 text-[8px] font-bold text-[var(--dark-text)]">
                        جديد
                      </span>
                    )}
                    {review.isOwn && (
                      <button
                        className="text-[var(--danger-text)]"
                        onClick={() => {
                          if (!window.confirm("هل تريد حذف تقييمك؟")) return
                          onDeleteReview(review.id)
                        }}
                        aria-label="حذف التقييم"
                      >
                        <Icon name="trash" />
                      </button>
                    )}
                  </div>
                </div>
                <p className="mt-2 text-xs leading-6 text-[var(--text-muted)]">
                  {review.text}
                </p>
                <small className="mt-2 block text-[9px] text-[var(--text-dim)]">
                  {review.dateLabel}
                </small>
              </div>
            </div>
          </article>
        ))}
        {!propertyReviews.length && (
          <div className="rounded-2xl bg-[var(--surface-soft)] p-5 text-center text-xs leading-6 text-[var(--text-muted)]">
            لا توجد تقييمات بعد. كن أول من يقيّم هذا العقار.
          </div>
        )}
      </div>
    </section>
  )
}

function PropertyDetailsScreen({
  property,
  go,
  favorite,
  onToggleFavorite,
  onChat,
  reviews,
  onAddReview,
  onDeleteReview,
  onOpenOwner,
  reported,
  onReportProperty,
}: {
  property: Property
  go: (screen: number) => void
  favorite: boolean
  onToggleFavorite: (propertyId: string) => void
  onChat: () => void
  reviews: PropertyReview[]
  onAddReview: (propertyId: string, rating: number, text: string) => void
  onDeleteReview: (reviewId: string) => void
  onOpenOwner: (owner: Owner) => void
  reported: boolean
  onReportProperty: (propertyId: string) => void
}) {
  const gallery = property.images.length ? property.images : [property.image]
  const [activeImage, setActiveImage] = useState(0)
  const [notice, setNotice] = useState("")
  const [lightboxOpen, setLightboxOpen] = useState(false)
  const [reportModalOpen, setReportModalOpen] = useState(false)
  const services = infrastructureItems(property)

  const share = async () => {
    try {
      if (!navigator.share) throw new Error("Share unavailable")
      await navigator.share({
        title: property.title,
        text: `${property.title} — ${propertyAddress(property)}`,
      })
    } catch {
      await navigator.clipboard
        ?.writeText(property.title)
        .catch(() => undefined)
      setNotice("تم نسخ معلومات العقار")
    }
  }

  const infoCards =
    property.category === "commercial"
      ? [
          {
            icon: "land" as IconName,
            label: "المساحة",
            value: `${property.area} م²`,
          },
          {
            icon: "shop" as IconName,
            label: "نوع المحل",
            value: property.commercialType,
          },
          {
            icon: "pin" as IconName,
            label: "الموقع",
            value: property.shopLocation,
          },
          {
            icon: "building" as IconName,
            label: "التشطيب",
            value: property.finishing,
          },
        ]
      : property.category === "land"
        ? [
            {
              icon: "land" as IconName,
              label: "المساحة",
              value: `${property.area} م²`,
            },
            {
              icon: "land" as IconName,
              label: "نوع الأرض",
              value: property.landType,
            },
            {
              icon: "pin" as IconName,
              label: "الواجهة",
              value: property.frontage?.join("، "),
            },
            {
              icon: "building" as IconName,
              label: "عرض الشارع",
              value: property.streetWidth,
            },
          ]
        : property.category === "hotel"
          ? [
              {
                icon: "hotel" as IconName,
                label: "التصنيف",
                value: "⭐".repeat(property.starRating ?? 0),
              },
              {
                icon: "bed" as IconName,
                label: "نوع الغرفة",
                value: property.roomCategory,
              },
              {
                icon: "bed" as IconName,
                label: "عدد السراير",
                value: property.bedCount,
              },
              {
                icon: "sofa" as IconName,
                label: "نوع السرير",
                value: property.bedType,
              },
            ]
          : property.category === "chalet"
            ? [
                {
                  icon: "user" as IconName,
                  label: "السعة",
                  value: `${property.capacity} ضيوف`,
                },
                {
                  icon: "shield" as IconName,
                  label: "الخصوصية",
                  value: property.privacy,
                },
                {
                  icon: "droplet" as IconName,
                  label: "المسبح",
                  value: property.chaletAmenities?.includes("مسبح خاص")
                    ? "مسبح خاص"
                    : property.chaletAmenities?.includes("مسبح أطفال")
                      ? "مسبح أطفال"
                      : "بدون مسبح",
                },
                {
                  icon: "land" as IconName,
                  label: "المساحة الترفيهية",
                  value: property.chaletAmenities?.includes("مسطحات خضراء")
                    ? "مسطحات خضراء"
                    : property.chaletAmenities?.includes("جلسات خارجية")
                      ? "جلسات خارجية"
                      : property.chaletAmenities?.includes("مكان للشواء")
                        ? "مكان للشواء"
                        : "—",
                },
              ]
      : [
          {
            icon: "bed" as IconName,
            label: "غرف النوم",
            value: property.bedrooms,
          },
          { icon: "sofa" as IconName, label: "الصالات", value: property.halls },
          {
            icon: "kitchen" as IconName,
            label: "المطابخ",
            value: property.kitchens,
          },
          {
            icon: "bath" as IconName,
            label: "الحمامات",
            value: property.bathrooms,
          },
        ]

  return (
    <section className="screen !bg-[var(--surface-soft)] text-[var(--text)]">
      <main className="min-h-0 flex-1 overflow-y-auto pb-28 [scrollbar-width:none]">
        <div className="relative h-64 overflow-hidden bg-[var(--line)]">
          <button
            className="h-full w-full cursor-zoom-in"
            onClick={() => setLightboxOpen(true)}
            aria-label="فتح الصورة بالحجم الكامل"
          >
            <img
              className="h-full w-full object-cover"
              src={gallery[activeImage]}
              alt={`${property.alt} - صورة ${activeImage + 1}`}
            />
          </button>
          <button
            className="absolute right-3 top-9 grid size-10 place-items-center rounded-full bg-[var(--overlay)] text-[var(--dark-text)] backdrop-blur"
            onClick={() => go(-1)}
            aria-label="رجوع"
          >
            <Icon name="arrow" />
          </button>
          <div className="absolute left-3 top-9 flex gap-2">
            <button
              className={`grid size-10 place-items-center rounded-full bg-[var(--overlay)] backdrop-blur ${
                favorite
                  ? "favorite-active text-[var(--danger-text)]"
                  : "text-[var(--dark-text)]"
              }`}
              onClick={() => onToggleFavorite(property.id)}
              aria-label={favorite ? "إزالة من المفضلة" : "إضافة إلى المفضلة"}
            >
              <Icon name="heart" />
            </button>
            <button
              className="grid size-10 place-items-center rounded-full bg-[var(--overlay)] text-[var(--dark-text)] backdrop-blur"
              onClick={() => void share()}
              aria-label="مشاركة العقار"
            >
              <Icon name="share" />
            </button>
            <button
              className={`grid size-10 place-items-center rounded-full text-[var(--dark-text)] backdrop-blur ${
                reported ? "bg-[var(--danger)]" : "bg-[var(--overlay)]"
              }`}
              onClick={() => {
                if (reported) {
                  onReportProperty(property.id)
                  setNotice("تم إلغاء البلاغ")
                } else {
                  setReportModalOpen(true)
                }
              }}
              aria-label={reported ? "إلغاء البلاغ عن العقار" : "إبلاغ عن العقار"}
            >
              <Icon name="warning" />
            </button>
          </div>
          <span className="absolute bottom-3 left-3 rounded-full bg-[var(--overlay)] px-3 py-1 text-[10px] font-bold text-[var(--dark-text)] backdrop-blur">
            <span className="inline-flex items-center gap-1" dir="ltr">
              <Icon name="image" />
              {activeImage + 1}/{gallery.length}
            </span>
          </span>
        </div>

        <div className="flex gap-2 overflow-x-auto bg-[var(--surface-raised)] px-4 py-3 [scrollbar-width:none]">
          {gallery.map((image, index) => (
            <button
              className={`h-14 w-16 shrink-0 overflow-hidden rounded-xl border-2 ${
                activeImage === index
                  ? "border-[var(--primary)]"
                  : "border-[var(--transparent)]"
              }`}
              key={`${image}-${index}`}
              onClick={() => setActiveImage(index)}
              aria-label={`عرض الصورة ${index + 1}`}
            >
              <img className="h-full w-full object-cover" src={image} alt="" />
            </button>
          ))}
        </div>

        <div className="space-y-3 p-4">
          <section className="rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-4 shadow-sm">
            <div className="mb-3 flex flex-wrap gap-2">
              <span
                className={`rounded-full px-3 py-1 text-[10px] font-bold ${
                  property.purpose === "للبيع"
                    ? "bg-[var(--primary-soft)] text-[var(--primary-text)]"
                    : property.purpose === "للإيجار"
                      ? "bg-[var(--primary-soft)] text-[var(--primary-text)]"
                      : "bg-[var(--primary-soft)] text-[var(--primary-text)]"
                }`}
              >
                {property.purpose}
              </span>
              {property.category === "hotel" ? (
                <span className="rounded-full bg-[var(--primary-soft)] px-3 py-1 text-[10px] font-bold text-[var(--primary-text)]">
                  {"⭐".repeat(property.starRating ?? 0)}
                </span>
              ) : property.category === "chalet" ? (
                <span className="rounded-full bg-[var(--primary-soft)] px-3 py-1 text-[10px] font-bold text-[var(--primary-text)]">
                  {property.capacity} ضيوف
                </span>
              ) : property.paymentMethod ? (
                <span className="rounded-full bg-[var(--primary-soft)] px-3 py-1 text-[10px] font-bold text-[var(--primary-text)]">
                  {property.paymentMethod}
                </span>
              ) : null}
              <span className="rounded-full bg-[var(--surface-soft)] px-3 py-1 text-[10px] font-bold text-[var(--text-muted)]">
                {property.category === "commercial"
                  ? property.finishing
                  : property.category === "land"
                    ? property.landType
                    : property.category === "hotel"
                      ? property.roomCategory
                      : property.category === "chalet"
                        ? property.privacy
                        : property.furnishing}
              </span>
            </div>
            <h1 className="!text-xl !font-extrabold !text-[var(--text)]">
              {property.title}
            </h1>
            <p className="mt-1 text-xs leading-6 text-[var(--text-muted)]">
              {property.subtitle}
            </p>
            <p className="mt-2 flex items-center gap-1 text-[11px] text-[var(--text-muted)]">
              <Icon name="pin" />
              {propertyAddress(property)}
            </p>
            <b className="mt-4 block text-xl font-extrabold text-[var(--text)]">
              {propertyPrice(property)}
            </b>
          </section>

          <section className="grid grid-cols-4 divide-x divide-x-reverse divide-[var(--line)] rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] py-4 shadow-sm">
            {infoCards.map((item) => (
              <div
                className="flex min-w-0 flex-col items-center gap-1 text-center"
                key={item.label}
              >
                <span className="text-[var(--primary-text)]">
                  <Icon name={item.icon} />
                </span>
                <b
                  className={`w-full px-1 text-center text-[var(--text)] ${
                    property.category !== "residential"
                      ? "line-clamp-2 text-[9px] leading-4"
                      : "text-sm"
                  }`}
                >
                  {item.value}
                </b>
                <small className="truncate text-[8px] text-[var(--text-muted)]">
                  {item.label}
                </small>
              </div>
            ))}
          </section>

          <section className="rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-4 shadow-sm">
            <div className="mb-2 flex items-center gap-2">
              <span className="text-[var(--primary-text)]">
                <Icon name="document" />
              </span>
              <h2 className="text-sm font-extrabold text-[var(--text)]">
                وصف العقار
              </h2>
            </div>
            <p className="text-xs leading-7 text-[var(--text-muted)]">
              {property.description}
            </p>
          </section>

          {property.category === "residential" && services.length > 0 && (
            <section className="rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-4 shadow-sm">
              <div className="mb-3 flex items-center gap-2">
                <span className="text-[var(--primary-text)]">
                  <Icon name="settings" />
                </span>
                <h2 className="text-sm font-extrabold text-[var(--text)]">
                  خدمات البنية التحتية
                </h2>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {services.map((service) => (
                  <div
                    className="flex min-w-0 items-center gap-2 rounded-xl bg-[var(--surface-soft)] p-3"
                    key={service.label}
                  >
                    <span
                      className={`grid size-8 shrink-0 place-items-center rounded-lg ${
                        service.status === "unavailable"
                          ? "bg-[var(--line)] text-[var(--text-muted)]"
                          : "bg-[var(--primary-soft)] text-[var(--primary-text)]"
                      }`}
                    >
                      <Icon name={service.icon} />
                    </span>
                    <span className="min-w-0">
                      <b className="block truncate text-[9px] text-[var(--text-muted)]">
                        {service.label}
                      </b>
                      <small className="block break-words text-[10px] font-bold leading-4 text-[var(--text)]">
                        {service.value}
                      </small>
                    </span>
                  </div>
                ))}
              </div>
            </section>
          )}

          <section className="rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-4 shadow-sm">
            <div className="mb-3 flex items-center gap-2">
              <span className="text-[var(--primary-text)]">
                <Icon name="settings" />
              </span>
              <h2 className="text-sm font-extrabold text-[var(--text)]">
                {property.category === "chalet"
                  ? "المميزات الترفيهية"
                  : "المرافق والخدمات"}
              </h2>
            </div>
            <div className="flex flex-wrap gap-2">
              {(property.category === "chalet"
                ? property.chaletAmenities ?? []
                : property.amenities
              ).map((amenity) => (
                <span
                  className="rounded-full bg-[var(--surface-soft)] px-3 py-2 text-[10px] font-semibold text-[var(--text)]"
                  key={amenity}
                >
                  {amenity}
                </span>
              ))}
            </div>
          </section>

          <button
            className="flex w-full items-center gap-3 rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-4 text-right shadow-sm"
            onClick={() => onOpenOwner(property.owner)}
          >
            <span className="grid size-12 shrink-0 place-items-center rounded-full bg-[var(--primary-soft)] text-xs font-extrabold text-[var(--primary-text)]">
              {property.owner.initials}
            </span>
            <span className="min-w-0 flex-1">
              <b className="block truncate text-sm text-[var(--text)]">
                {property.owner.name}
              </b>
              <small className="mt-0.5 block text-[10px] text-[var(--text-muted)]">
                مالك العقار
              </small>
              <small className="mt-1 flex items-center gap-1 text-[10px] text-[var(--text-muted)]">
                <span className="text-[var(--primary-text)]">
                  <Icon name="star" />
                </span>
                {property.owner.rating} ({property.owner.reviewCount} تقييم)
              </small>
            </span>
            <Icon name="chevron" />
          </button>

          <section className="rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-4 shadow-sm">
            <div className="mb-3 flex items-center gap-2">
              <span className="grid size-9 place-items-center rounded-xl bg-[var(--danger-soft)] text-[var(--danger-text)]">
                <Icon name="pin" />
              </span>
              <span>
                <b className="block text-sm text-[var(--text)]">الموقع</b>
                <small className="text-[10px] text-[var(--text-muted)]">
                  {propertyAddress(property)}
                </small>
              </span>
            </div>
            <div
              className="relative grid h-24 place-items-center overflow-hidden rounded-xl bg-[var(--surface-soft)]"
              aria-label="معاينة تقريبية للموقع وليست خريطة تفاعلية"
            >
              <span className="absolute inset-x-0 top-1/2 border-t border-dashed border-[var(--line-strong)]" />
              <span className="absolute inset-y-0 left-1/2 border-l border-dashed border-[var(--line-strong)]" />
              <span className="z-10 grid size-9 place-items-center rounded-full bg-[var(--surface-raised)] text-[var(--danger-text)] shadow">
                <Icon name="pin" />
              </span>
              <small className="absolute bottom-2 text-[8px] text-[var(--text-muted)]">
                معاينة تقريبية للموقع
              </small>
            </div>
          </section>

          <PropertyReviewsSection
            property={property}
            reviews={reviews}
            onAddReview={onAddReview}
            onDeleteReview={onDeleteReview}
          />
        </div>
      </main>

      <div className="absolute inset-x-0 bottom-0 z-50 border-t border-[var(--line)] bg-[var(--surface-raised)] p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
        <button
          className="flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-[var(--primary-strong)] px-4 font-bold text-[var(--dark-text)] shadow-lg shadow-[var(--primary-shadow)]"
          onClick={onChat}
        >
          <Icon name="chat" />
          تواصل مع المالك
        </button>
      </div>

      {notice && (
        <div className="absolute bottom-24 left-1/2 z-[60] -translate-x-1/2 whitespace-nowrap rounded-xl bg-[var(--overlay)] px-4 py-2 text-[10px] text-[var(--dark-text)] shadow-xl">
          {notice}
        </div>
      )}
      {lightboxOpen && (
        <div
          className="absolute inset-0 z-[70] flex flex-col justify-between bg-[var(--overlay)] p-4 backdrop-blur-md"
          role="dialog"
          aria-modal="true"
          aria-label="معرض صور العقار"
          dir="rtl"
        >
          <div className="flex items-center justify-between gap-3">
            <button
              className="grid size-11 place-items-center rounded-full bg-[var(--surface-raised)] text-[var(--text)] shadow-lg"
              onClick={() => setLightboxOpen(false)}
              aria-label="إغلاق معرض الصور"
            >
              <Icon name="close" />
            </button>
            <span
              className="rounded-full bg-[var(--surface-raised)] px-3 py-2 text-xs font-bold text-[var(--text)] shadow-lg"
              dir="ltr"
            >
              {activeImage + 1} / {gallery.length}
            </span>
          </div>

          <div className="relative flex min-h-0 flex-1 items-center justify-center py-4">
            <img
              className="max-h-full w-full object-contain"
              src={gallery[activeImage]}
              alt={`${property.alt} - معاينة الصورة ${activeImage + 1}`}
            />
            {gallery.length > 1 && (
              <>
                <button
                  className="absolute right-0 grid size-11 place-items-center rounded-full bg-[var(--surface-raised)] text-[var(--text)] shadow-lg"
                  onClick={() =>
                    setActiveImage(
                      (current) =>
                        (current - 1 + gallery.length) % gallery.length,
                    )
                  }
                  aria-label="الصورة السابقة"
                >
                  <span className="rotate-180">
                    <Icon name="chevron" />
                  </span>
                </button>
                <button
                  className="absolute left-0 grid size-11 place-items-center rounded-full bg-[var(--surface-raised)] text-[var(--text)] shadow-lg"
                  onClick={() =>
                    setActiveImage(
                      (current) => (current + 1) % gallery.length,
                    )
                  }
                  aria-label="الصورة التالية"
                >
                  <Icon name="chevron" />
                </button>
              </>
            )}
          </div>

          <div className="flex gap-2 overflow-x-auto rounded-2xl bg-[var(--surface-raised)] p-3 [scrollbar-width:none]">
            {gallery.map((image, index) => (
              <button
                className={`h-16 w-20 shrink-0 overflow-hidden rounded-xl border-2 ${
                  activeImage === index
                    ? "border-[var(--primary)]"
                    : "border-[var(--transparent)]"
                }`}
                key={`${image}-lightbox-${index}`}
                onClick={() => setActiveImage(index)}
                aria-label={`عرض الصورة ${index + 1}`}
              >
                <img className="h-full w-full object-cover" src={image} alt="" />
              </button>
            ))}
          </div>
        </div>
      )}
      {reportModalOpen && (
        <ReportReasonModal
          onClose={() => setReportModalOpen(false)}
          onConfirm={() => {
            onReportProperty(property.id)
            setReportModalOpen(false)
            setNotice("تم إرسال البلاغ للمراجعة")
          }}
        />
      )}
    </section>
  )
}

function AiAssistant({ go }: { go: (screen: number) => void }) {
  const [message, setMessage] = useState("")
  const [sentMessage, setSentMessage] = useState("")
  const prompts = [
    "أبحث عن شقة قريبة من عملي",
    "شاليه لعطلة نهاية الأسبوع",
    "فندق مناسب للعائلة",
  ]

  const sendMessage = () => {
    if (!message.trim()) return
    setSentMessage(message)
    setMessage("")
  }

  return (
    <section className="screen ai-screen">
      <PageHeader title="مساعد مسكني الذكي" go={go} />
      <main className="ai-content">
        <div className="ai-identity">
          <span>
            <Icon name="sparkles" />
          </span>
          <div>
            <strong>مساعد مسكني</strong>
            <small>
              <i /> متصل الآن
            </small>
          </div>
        </div>
        <div className="chat-thread">
          <div className="ai-bubble">
            مرحباً! كيف يمكنني مساعدتك في العثور على عقارك المثالي اليوم؟
            <small>الآن</small>
          </div>
          {sentMessage && (
            <>
              <div className="user-bubble">{sentMessage}</div>
              <div className="ai-bubble">
                رائع، سأبحث لك عن أفضل الخيارات المطابقة وأرتبها حسب تفضيلاتك.
              </div>
            </>
          )}
        </div>
        <div className="prompt-chips">
          <p>جرّب أن تسأل عن:</p>
          {prompts.map((prompt) => (
            <button key={prompt} onClick={() => setMessage(prompt)}>
              <Icon name="sparkles" />
              {prompt}
            </button>
          ))}
        </div>
      </main>
      <div className="chat-composer">
        <input
          value={message}
          onChange={(event) => setMessage(event.target.value)}
          onKeyDown={(event) => event.key === "Enter" && sendMessage()}
          placeholder="تحدث مع المساعد الذكي..."
        />
        <button onClick={sendMessage} aria-label="إرسال">
          <Icon name="send" />
        </button>
      </div>
    </section>
  )
}

function DeactivateAccount({ go }: { go: (screen: number) => void }) {
  return (
    <section className="screen feature-screen">
      <PageHeader title="تعطيل الحساب" go={go} />
      <main className="danger-main">
        <div className="warning-symbol warning-symbol--soft">
          <Icon name="pause" />
        </div>
        <span className="eyebrow">توقف مؤقت</span>
        <h1>هل ترغب في إيقاف حسابك مؤقتاً؟</h1>
        <p>ستتمكن من العودة متى شئت، وستظل بياناتك وحجوزاتك محفوظة بأمان.</p>
        <div className="info-note">
          <Icon name="shield" />
          لن يظهر ملفك أو نشاطك للآخرين خلال فترة التعطيل.
        </div>
      </main>
      <footer className="screen-footer danger-actions">
        <button className="danger-primary" onClick={() => go(4)}>
          تعطيل الحساب
        </button>
        <button className="quiet-action" onClick={() => go(12)}>
          إلغاء والعودة
        </button>
      </footer>
    </section>
  )
}

function DeleteAccount({ go }: { go: (screen: number) => void }) {
  const submit = (event: FormEvent) => {
    event.preventDefault()
    go(4)
  }

  return (
    <section className="screen feature-screen">
      <PageHeader title="حذف الحساب" go={go} />
      <main className="danger-main delete-main">
        <div className="warning-symbol">
          <Icon name="warning" />
        </div>
        <span className="danger-eyebrow">إجراء نهائي</span>
        <h1>هل أنت متأكد من حذف حسابك نهائياً؟</h1>
        <p>
          سيتم حذف بياناتك وحجوزاتك ومفضلاتك، ولا يمكن التراجع عن هذا الإجراء.
        </p>
        <form className="delete-form" onSubmit={submit}>
          <Field label="أدخل كلمة المرور للتأكيد" icon="lock" password />
          <button className="delete-button" type="submit">
            <Icon name="trash" />
            تأكيد الحذف
          </button>
        </form>
      </main>
    </section>
  )
}

function Suggestions({ go }: { go: (screen: number) => void }) {
  const [suggestion, setSuggestion] = useState("")
  const [submitted, setSubmitted] = useState(false)

  const sendSuggestion = () => {
    if (!suggestion.trim()) return
    setSuggestion("")
    setSubmitted(true)
  }

  return (
    <section className="screen feature-screen">
      <PageHeader title="اقتراحاتك" go={go} />
      <main className="feature-content suggestion-content">
        {submitted && (
          <SuccessBanner>
            تم إرسال اقتراحك بنجاح، شكراً لتواصلك معنا!
          </SuccessBanner>
        )}
        <div className="suggestion-icon">
          <Icon name="chat" />
        </div>
        <h1>ساهم في تطوير مسكني</h1>
        <p>رأيك يصنع فرقاً. شاركنا ما يمكن أن يجعل تجربتك أفضل.</p>
        <label className="suggestion-field">
          <span>اقتراحك</span>
          <textarea
            value={suggestion}
            onChange={(event) => {
              setSuggestion(event.target.value)
              setSubmitted(false)
            }}
            placeholder="شاركنا أفكارك ومقترحاتك..."
            maxLength={500}
          />
          <small>{suggestion.length} / 500</small>
        </label>
      </main>
      <footer className="screen-footer">
        <PrimaryButton onClick={sendSuggestion} disabled={!suggestion.trim()}>
          إرسال الاقتراح
        </PrimaryButton>
      </footer>
    </section>
  )
}

function About({ go }: { go: (screen: number) => void }) {
  const socialLinks: { icon: IconName label: string url: string }[] = [
    { icon: "xSocial", label: "منصة X", url: "https://x.com" },
    { icon: "instagram", label: "Instagram", url: "https://www.instagram.com" },
    {
      icon: "whatsapp",
      label: "WhatsApp",
      url: "https://wa.me/967700000000",
    },
  ]

  return (
    <section className="screen feature-screen">
      <PageHeader title="حول المنصة" go={go} />
      <main className="about-main">
        <LogoMark large />
        <h1>مَسْكَنِي</h1>
        <span className="version-pill">الإصدار 1.0.0</span>
        <p>
          رؤيتنا أن نجعل الوصول إلى المسكن المناسب أكثر سهولة ووضوحاً وثقة، ونبني
          جسراً ذكياً بين الباحثين عن المكان وشركاء النجاح.
        </p>
        <div className="about-divider" />
        <small>تابع مسكني</small>
        <div className="social-links">
          {socialLinks.map((item) => (
            <button
              key={item.label}
              onClick={() =>
                window.open(item.url, "_blank", "noopener,noreferrer")
              }
              aria-label={item.label}
            >
              <Icon name={item.icon} />
            </button>
          ))}
        </div>
      </main>
      <p className="about-copyright">© 2025 مسكني — جميع الحقوق محفوظة</p>
    </section>
  )
}

function SuccessBanner({ children }: { children: ReactNode }) {
  return (
    <div className="success-banner" role="status">
      <span>✓</span>
      <p>{children}</p>
    </div>
  )
}

function UploadZone({ label }: { label: string }) {
  const [fileMessage, setFileMessage] = useState("")

  return (
    <label className="upload-zone">
      <input
        type="file"
        accept="image/*,.pdf"
        required
        onChange={(event) => {
          const file = event.target.files?.[0]
          if (!file) {
            setFileMessage("")
            return
          }
          if (file.size > 5 * 1024 * 1024) {
            event.target.value = ""
            setFileMessage("حجم الملف أكبر من 5MB")
            return
          }
          setFileMessage(`تم اختيار: ${file.name}`)
        }}
      />
      <span>
        <Icon name="upload" />
      </span>
      <strong>{label}</strong>
      <p>اسحب الملف هنا أو اضغط للاختيار</p>
      <small>{fileMessage || "PNG، JPG أو PDF — بحد أقصى 5MB"}</small>
    </label>
  )
}

function EditProfile({ go }: { go: (screen: number) => void }) {
  const [saved, setSaved] = useState(false)
  const [avatarName, setAvatarName] = useState("")

  return (
    <section className="screen feature-screen">
      <PageHeader title="تعديل الملف الشخصي" go={go} />
      <main className="feature-content profile-form-content">
        {saved && (
          <SuccessBanner>تم حفظ بيانات ملفك الشخصي بنجاح</SuccessBanner>
        )}
        <div className="edit-avatar">
          <div className="avatar avatar--large">مح</div>
          <div>
            <strong>صورتك الشخصية</strong>
            <p>اختر صورة واضحة وحديثة</p>
            <label className="edit-avatar-upload">
              <input
                type="file"
                accept="image/*"
                onChange={(event) =>
                  setAvatarName(event.target.files?.[0]?.name ?? "")
                }
              />
              <Icon name="upload" />
              {avatarName || "تغيير الصورة الشخصية"}
            </label>
          </div>
        </div>
        <form
          className="profile-form"
          onSubmit={(event) => {
            event.preventDefault()
            setSaved(true)
          }}
        >
          <Field label="الاسم الكامل" icon="user" />
          <Field label="رقم الهاتف" icon="phone" />
          <Field label="البريد الإلكتروني" icon="mail" />
          <label className="field">
            <span>المدينة</span>
            <span className="field-control">
              <Icon name="pin" />
              <input type="text" placeholder="صنعاء" />
            </span>
          </label>
          <PrimaryButton type="submit">حفظ التغييرات</PrimaryButton>
        </form>
      </main>
    </section>
  )
}

function AccountVerification({
  go,
  isPartner = false,
}: {
  go: (screen: number) => void
  isPartner?: boolean
}) {
  const [submitted, setSubmitted] = useState(false)

  return (
    <section className="screen feature-screen">
      <PageHeader
        title={isPartner ? "استكمال بيانات وتوثيق الحساب" : "توثيق الحساب"}
        go={go}
      />
      <main className="feature-content verification-content">
        {submitted && (
          <SuccessBanner>
            {isPartner
              ? "ستتم مراجعة البيانات لتفعيل حسابك، جاري تحويلك..."
              : "تم رفع بياناتك بنجاح، بانتظار مراجعة الإدارة"}
          </SuccessBanner>
        )}
        <div className="verification-intro">
          <span>
            <Icon name="shield" />
          </span>
          <div>
            <h2>{isPartner ? "استكمال بيانات التوثيق" : "وثّق هويتك"}</h2>
            <p>
              {isPartner
                ? "أكمل بياناتك الرسمية لتفعيل حساب المالك والبدء بإدارة عقاراتك."
                : "ارفع مستوى الثقة والأمان في حسابك على مسكني."}
            </p>
          </div>
        </div>
        <form
          className="profile-form"
          onSubmit={(event) => {
            event.preventDefault()
            if (submitted) return
            setSubmitted(true)
            // فقط إذا كان الحساب مالك/شريك ينتقل لشاشة قيد التطوير (39)
            if (isPartner) {
              window.setTimeout(() => {
                go(39)
              }, 1800)
            }
          }}
        >
          <Field
            label={isPartner ? "الاسم الرباعي أو اسم المنشأة" : "الاسم الرباعي"}
            icon="user"
          />
          <Field
            label={
              isPartner ? "رقم الهوية أو السجل التجاري" : "رقم الهوية"
            }
            icon="document"
          />
          {isPartner && <Field label="العنوان / المدينة" icon="pin" />}
          <UploadZone
            label={
              isPartner
                ? "رفع صورة الهوية أو الترخيص التجاري"
                : "رفع صورة الهوية"
            }
          />
          <PrimaryButton type="submit" disabled={submitted}>
            {submitted
              ? "تم الإرسال..."
              : isPartner
                ? "تأكيد البيانات"
                : "إرسال طلب التوثيق"}
          </PrimaryButton>
        </form>
      </main>
    </section>
  )
}



function FollowingList({
  go,
  followedOwnerIds,
  onToggleFollow,
  onOpenOwner,
}: {
  go: (screen: number) => void
  followedOwnerIds: Set<string>
  onToggleFollow: (ownerId: string) => void
  onOpenOwner: (owner: Owner) => void
}) {
  const following = ownerList.filter((owner) => followedOwnerIds.has(owner.id))

  return (
    <section className="screen feature-screen">
      <PageHeader title="قائمة المتابعة" go={go} />
      <main className="feature-content following-content">
        <div className="list-summary">
          <p>الحسابات التي تتابعها</p>
          <span>{following.length} حسابات</span>
        </div>
        <div className="following-list">
          {following.map((owner) => (
            <article className="following-card" key={owner.id}>
              <button
                className="follow-avatar border-0 p-0"
                onClick={() => onOpenOwner(owner)}
                aria-label={`عرض ملف ${owner.name}`}
              >
                {owner.initials}
              </button>
              <button
                className="min-w-0 border-0 bg-[var(--transparent)] p-0 text-right text-[var(--text)]"
                onClick={() => onOpenOwner(owner)}
              >
                <strong>
                  {owner.name}
                  {owner.verified && <span>✓</span>}
                </strong>
                <p>{owner.type}</p>
              </button>
              <button onClick={() => onToggleFollow(owner.id)}>
                إلغاء المتابعة
              </button>
            </article>
          ))}
          {following.length === 0 && (
            <div className="empty-following">
              <Icon name="heart" />
              <p>لا توجد حسابات في قائمة المتابعة حالياً</p>
            </div>
          )}
        </div>
      </main>
    </section>
  )
}

function OwnerProfileScreen({
  owner,
  go,
  reviews,
  followed,
  blocked,
  reported,
  favoriteIds,
  reportedPropertyIds,
  onToggleFollow,
  onContact,
  onOpenProperty,
  onToggleFavorite,
  onReportProperty,
  onBlock,
  onReport,
}: {
  owner: Owner
  go: (screen: number) => void
  reviews: PropertyReview[]
  followed: boolean
  blocked: boolean
  reported: boolean
  favoriteIds: Set<string>
  reportedPropertyIds: Set<string>
  onToggleFollow: (ownerId: string) => void
  onContact: (owner: Owner) => void
  onOpenProperty: (property: Property) => void
  onToggleFavorite: (propertyId: string) => void
  onReportProperty: (propertyId: string) => void
  onBlock: (ownerId: string) => void
  onReport: (ownerId: string) => void
}) {
  const [bioExpanded, setBioExpanded] = useState(false)
  const [notice, setNotice] = useState("")
  const propertiesSection = useRef<HTMLElement>(null)
  const reviewsSection = useRef<HTMLElement>(null)
  const ownerProperties = properties.filter(
    (property) => property.owner.id === owner.id,
  )
  const ownerPropertyIds = new Set(
    ownerProperties.map((property) => property.id),
  )
  const recentReviews = reviews.filter((review) =>
    ownerPropertyIds.has(review.propertyId),
  )
  const dynamicReviewCount = owner.reviewCount + recentReviews.length
  const dynamicRating = dynamicReviewCount
    ? (owner.rating * owner.reviewCount +
        recentReviews.reduce((total, review) => total + review.rating, 0)) /
      dynamicReviewCount
    : owner.rating

  const shareOwner = async () => {
    const shareData = {
      title: `${owner.name} — مسكني`,
      text: `الملف الشخصي للمالك ${owner.name} على منصة مسكني`,
    }
    try {
      if (!navigator.share) throw new Error("Share unavailable")
      await navigator.share(shareData)
    } catch {
      await navigator.clipboard
        ?.writeText(`${shareData.title} — ${shareData.text}`)
        .catch(() => undefined)
      setNotice("تم نسخ معلومات الملف الشخصي")
    }
  }

  const reportOwner = () => {
    if (!window.confirm(`هل تريد الإبلاغ عن ${owner.name}؟`)) return
    onReport(owner.id)
    setNotice("تم إرسال البلاغ للمراجعة")
  }

  return (
    <section className="screen bg-[var(--surface-soft)] text-[var(--text)]">
      <header className="grid shrink-0 grid-cols-[1fr_auto_1fr] items-center border-b border-[var(--line)] bg-[var(--surface-raised)] px-4 pb-3 pt-9">
        <button
          className="grid size-10 justify-self-start place-items-center rounded-full border border-[var(--line)] text-[var(--text)]"
          onClick={() => go(-1)}
          aria-label="رجوع"
        >
          <Icon name="arrow" />
        </button>
        <h1 className="text-sm font-extrabold">الملف الشخصي</h1>
        <div className="flex justify-self-end gap-2">
          {!blocked && (
            <>
              <button
                className="grid size-9 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface)] text-[var(--text-muted)]"
                onClick={() => void shareOwner()}
                aria-label="مشاركة الملف الشخصي"
              >
                <Icon name="share" />
              </button>
              <button
                className="grid size-9 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface)] text-[var(--danger-text)]"
                onClick={reportOwner}
                aria-label="إبلاغ عن المالك"
              >
                <Icon name="warning" />
              </button>
            </>
          )}
        </div>
      </header>

      {blocked ? (
        <main className="grid min-h-0 flex-1 place-items-center overflow-y-auto px-4 py-8">
          <section className="w-full rounded-3xl border border-[var(--line)] bg-[var(--surface-raised)] p-6 text-center shadow-sm">
            <span className="mx-auto grid size-20 place-items-center rounded-3xl bg-[var(--surface-soft)] text-xl font-extrabold text-[var(--text-muted)]">
              {owner.initials}
            </span>
            <strong className="mt-4 block text-lg font-extrabold">
              {owner.name}
            </strong>
            <span className="mx-auto mt-4 grid size-12 place-items-center rounded-full bg-[var(--danger-soft)] text-[var(--danger-text)]">
              <Icon name="shield" />
            </span>
            <strong className="mt-3 block text-sm font-extrabold">
              هذا المستخدم محظور
            </strong>
            <p className="mx-auto mt-2 max-w-sm text-xs leading-7 text-[var(--text-muted)]">
              لن تتمكن من التواصل معه أو متابعة حسابه أو التفاعل مع عقاراته
              حتى ترفع الحظر.
            </p>
            <button
              className="mt-5 min-h-12 w-full rounded-xl border border-[var(--primary)] bg-[var(--primary-soft)] px-4 text-xs font-bold text-[var(--primary-text)]"
              onClick={() => {
                onBlock(owner.id)
                setNotice("تم رفع الحظر")
              }}
            >
              رفع الحظر
            </button>
          </section>
        </main>
      ) : (
        <main className="min-h-0 flex-1 space-y-3 overflow-y-auto px-4 pb-8 pt-4 [scrollbar-width:none]">
        <section className="rounded-3xl border border-[var(--line)] bg-[var(--surface-raised)] p-5 text-center shadow-sm">
          <span className="mx-auto grid size-20 place-items-center rounded-3xl bg-[var(--primary-soft)] text-xl font-extrabold text-[var(--primary-text)]">
            {owner.initials}
          </span>
          <h2 className="mt-3 flex items-center justify-center gap-1 text-lg font-extrabold">
            {owner.name}
            {owner.verified && (
              <span className="grid size-5 place-items-center rounded-full bg-[var(--primary-strong)] text-[10px] text-[var(--dark-text)]">
                ✓
              </span>
            )}
          </h2>
          <p className="mt-1 flex items-center justify-center gap-1 text-[10px] text-[var(--text-muted)]">
            <span
              className={`size-2 rounded-full ${
                owner.online ? "bg-[var(--primary)]" : "bg-[var(--text-dim)]"
              }`}
            />
            {owner.online ? "متصل الآن" : `آخر ظهور ${owner.lastSeen}`}
          </p>
          <button
            className="mt-3 inline-flex items-center gap-1 rounded-full bg-[var(--primary-soft)] px-3 py-2 text-xs font-bold text-[var(--primary-text)]"
            onClick={() =>
              reviewsSection.current?.scrollIntoView({ behavior: "smooth" })
            }
          >
            <Icon name="star" />
            {dynamicRating.toFixed(1)} ({dynamicReviewCount} تقييم)
          </button>
          <div className="mt-3 flex flex-wrap justify-center gap-3 text-[10px] text-[var(--text-muted)]">
            <span className="inline-flex items-center gap-1">
              <Icon name="pin" />
              {owner.location}
            </span>
            <span className="inline-flex items-center gap-1">
              <Icon name="calendar" />
              عضو منذ {owner.since}
            </span>
          </div>
          <p
            className={`mx-auto mt-4 max-w-sm text-xs leading-7 text-[var(--text-muted)] ${
              bioExpanded ? "" : "line-clamp-2"
            }`}
          >
            {owner.bio}
          </p>
          <button
            className="mt-1 text-[10px] font-bold text-[var(--primary-text)]"
            onClick={() => setBioExpanded((current) => !current)}
          >
            {bioExpanded ? "عرض أقل" : "قراءة المزيد"}
          </button>
        </section>

        <section className="grid grid-cols-3 gap-2">
          <button
            className="min-w-0 rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-3 text-center"
            onClick={() =>
              reviewsSection.current?.scrollIntoView({ behavior: "smooth" })
            }
          >
            <b className="block text-sm text-[var(--text)]">
              {dynamicRating.toFixed(1)}
            </b>
            <small className="text-[9px] text-[var(--text-muted)]">تقييم</small>
          </button>
          <button
            className="min-w-0 rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-3 text-center"
            onClick={() =>
              propertiesSection.current?.scrollIntoView({ behavior: "smooth" })
            }
          >
            <b className="block text-sm text-[var(--text)]">
              {ownerProperties.length}
            </b>
            <small className="text-[9px] text-[var(--text-muted)]">
              عقارات
            </small>
          </button>
          <div className="min-w-0 rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-3 text-center">
            <b className="block text-sm text-[var(--text)]">
              {owner.responseRate}%
            </b>
            <small className="text-[9px] text-[var(--text-muted)]">ردود</small>
          </div>
        </section>

        <section className="grid grid-cols-3 gap-2">
          <button
            className="flex min-h-12 items-center justify-center gap-2 rounded-xl bg-[var(--primary-strong)] px-3 text-xs font-bold text-[var(--dark-text)] disabled:cursor-not-allowed disabled:opacity-50"
            onClick={() => onContact(owner)}
            disabled={blocked}
          >
            <Icon name="chat" />
            تواصل
          </button>
          <button
            className="flex min-h-12 items-center justify-center gap-2 rounded-xl border border-[var(--line)] bg-[var(--surface-raised)] px-3 text-xs font-bold text-[var(--text)]"
            onClick={() => {
              window.location.href = `tel:${owner.phone}`
            }}
          >
            <Icon name="phone" />
            اتصال
          </button>
          <button
            className={`min-h-12 rounded-xl border px-3 text-[10px] font-bold ${
              followed
                ? "border-[var(--line)] bg-[var(--surface-raised)] text-[var(--text)]"
                : "border-[var(--primary)] bg-[var(--primary-soft)] text-[var(--primary-text)]"
            }`}
            onClick={() => onToggleFollow(owner.id)}
            disabled={blocked}
          >
            {followed ? "إلغاء المتابعة" : "متابعة"}
          </button>
        </section>

        <section className="rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-3 text-center">
          <span className="text-[10px] text-[var(--text-muted)]">
            {owner.followerCount + (followed ? 1 : 0)} متابع
          </span>
        </section>

        <section ref={propertiesSection} className="scroll-mt-4">
          <div className="mb-3 flex items-end justify-between">
            <div>
              <h2 className="text-sm font-extrabold">عقارات {owner.name}</h2>
              <p className="mt-1 text-[10px] text-[var(--text-muted)]">
                {ownerProperties.length} عقارات منشورة
              </p>
            </div>
          </div>
          <div className="grid gap-3">
            {ownerProperties.map((property) => (
              <PropertyCard
                key={property.id}
                property={property}
                onOpen={onOpenProperty}
                favorite={favoriteIds.has(property.id)}
                onToggleFavorite={onToggleFavorite}
                reported={reportedPropertyIds.has(property.id)}
                onReport={onReportProperty}
              />
            ))}
            {!ownerProperties.length && (
              <div className="rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-6 text-center text-xs text-[var(--text-muted)]">
                لا توجد عقارات منشورة حالياً
              </div>
            )}
          </div>
        </section>

        <section
          ref={reviewsSection}
          className="scroll-mt-4 rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-4"
        >
          <h2 className="text-sm font-extrabold">تقييمات المالك</h2>
          <div className="mt-3 flex items-center gap-3">
            <strong className="text-3xl text-[var(--text)]">
              {dynamicRating.toFixed(1)}
            </strong>
            <div>
              <p className="text-sm text-[var(--primary-text)]">
                {"★".repeat(Math.round(dynamicRating))}
              </p>
              <small className="text-[10px] text-[var(--text-muted)]">
                {dynamicReviewCount} تقييم
              </small>
            </div>
          </div>
        </section>

        <section className="grid gap-2 rounded-2xl border border-[var(--line)] bg-[var(--surface-raised)] p-4">
          <button
            className="min-h-11 rounded-xl border border-[var(--danger)] bg-[var(--danger-soft)] px-4 text-xs font-bold text-[var(--danger-text)] disabled:cursor-not-allowed disabled:opacity-60"
            onClick={() => {
              if (!window.confirm(`هل تريد حظر ${owner.name}؟`)) return
              onBlock(owner.id)
              setNotice("تم الحظر")
            }}
          >
            حظر المستخدم
          </button>
          <button
            className="min-h-11 rounded-xl border border-[var(--line)] bg-[var(--surface)] px-4 text-xs font-bold text-[var(--danger-text)] disabled:cursor-not-allowed disabled:opacity-60"
            onClick={reportOwner}
            disabled={reported}
          >
            {reported ? "تم إرسال البلاغ" : "إبلاغ"}
          </button>
        </section>
        </main>
      )}

      {notice && (
        <div className="absolute bottom-5 left-1/2 z-[60] -translate-x-1/2 whitespace-nowrap rounded-xl bg-[var(--overlay)] px-4 py-2 text-[10px] text-[var(--dark-text)] shadow-xl">
          {notice}
        </div>
      )}
    </section>
  )
}

function JoinPartner({ go }: { go: (screen: number) => void }) {
  const [type, setType] = useState("مالك خاص")
  const [submitted, setSubmitted] = useState(false)

  return (
    <section className="screen feature-screen">
      <PageHeader title="انضم إلينا كشريك" go={go} />
      <main className="feature-content partner-content">
        {submitted && (
          <SuccessBanner>
            تم إرسال طلبك بنجاح، سنتواصل معك بعد مراجعة البيانات
          </SuccessBanner>
        )}
        <div className="partner-intro">
          <Icon name="userPlus" />
          <div>
            <h2>كن شريكاً في النجاح</h2>
            <p>وسّع أعمالك ووصل إلى آلاف الباحثين عن المكان المناسب.</p>
          </div>
        </div>
        <form
          className="profile-form"
          onSubmit={(event) => {
            event.preventDefault()
            setSubmitted(true)
          }}
        >
          <Field label="الاسم الكامل / اسم المنشأة" icon="user" />
          <Field label="رقم الهاتف" icon="phone" />
          <Field label="البريد الإلكتروني" icon="mail" />
          <fieldset className="partner-types">
            <legend>نوع الحساب</legend>
            <div>
              {["مالك خاص", "مكتب عقاري", "فندق", "شاليه"].map((item) => (
                <button
                  key={item}
                  type="button"
                  className={type === item ? "active" : ""}
                  onClick={() => setType(item)}
                >
                  {item}
                </button>
              ))}
            </div>
          </fieldset>
          <UploadZone label="رفع الهوية / السجل التجاري" />
          <PrimaryButton type="submit">إرسال طلب الانضمام</PrimaryButton>
        </form>
      </main>
    </section>
  )
}

function ToggleRow({
  icon,
  title,
  subtitle,
  active,
  onClick,
}: {
  icon: IconName
  title: string
  subtitle: string
  active: boolean
  onClick: () => void
}) {
  return (
    <button className="toggle-row" onClick={onClick}>
      <span className="toggle-icon">
        <Icon name={icon} />
      </span>
      <span>
        <strong>{title}</strong>
        <small>{subtitle}</small>
      </span>
      <i className={active ? "switch active" : "switch"}>
        <b />
      </i>
    </button>
  )
}

function Security({ go }: { go: (screen: number) => void }) {
  const [twoFactor, setTwoFactor] = useState(true)
  const [biometric, setBiometric] = useState(false)
  const [saved, setSaved] = useState(false)
  const [googleLinked, setGoogleLinked] = useState(false)
  const [appleLinked, setAppleLinked] = useState(false)

  return (
    <section className="screen feature-screen">
      <PageHeader title="إدارة وأمان الحساب" go={go} />
      <main className="feature-content security-content">
        {saved && <SuccessBanner>تم تغيير كلمة المرور بنجاح</SuccessBanner>}
        <section className="security-card">
          <h2>الحسابات المرتبطة</h2>
          <AccountLinkRow
            icon="google"
            name="Google"
            linked={googleLinked}
            onClick={() => setGoogleLinked(!googleLinked)}
          />
          <AccountLinkRow
            icon="apple"
            name="Apple"
            linked={appleLinked}
            onClick={() => setAppleLinked(!appleLinked)}
          />
        </section>
        <section className="security-card">
          <h2>خيارات الحماية</h2>
          <ToggleRow
            icon="shield"
            title="التحقق بخطوتين (2FA)"
            subtitle="رمز إضافي عند تسجيل الدخول"
            active={twoFactor}
            onClick={() => setTwoFactor(!twoFactor)}
          />
          <ToggleRow
            icon="user"
            title="تسجيل الدخول بالبصمة"
            subtitle="استخدم بصمة جهازك للدخول"
            active={biometric}
            onClick={() => setBiometric(!biometric)}
          />
        </section>
        <section className="security-card password-card">
          <h2>تغيير كلمة المرور</h2>
          <form
            className="profile-form"
            onSubmit={(event) => {
              event.preventDefault()
              setSaved(true)
            }}
          >
            <Field label="كلمة المرور الحالية" icon="lock" password />
            <Field label="كلمة المرور الجديدة" icon="lock" password />
            <Field label="تأكيد كلمة المرور" icon="lock" password />
            <button
              className="forgot-inline"
              type="button"
              onClick={() => go(7)}
            >
              نسيت كلمة المرور؟
            </button>
            <PrimaryButton type="submit">تأكيد التغيير</PrimaryButton>
          </form>
        </section>
        <section className="account-danger-zone security-danger-zone">
          <div className="settings-section-title">
            <h2>إجراءات الحساب</h2>
            <p>إجراءات حساسة متعلقة بحسابك</p>
          </div>
          <button onClick={() => go(18)}>
            <Icon name="pause" />
            <span>
              <strong>تعطيل الحساب مؤقتاً</strong>
              <small>يمكنك العودة في أي وقت</small>
            </span>
            <Icon name="chevron" />
          </button>
          <button className="delete-account-link" onClick={() => go(19)}>
            <Icon name="trash" />
            <span>
              <strong>حذف الحساب نهائياً</strong>
              <small>لا يمكن التراجع عن هذا الإجراء</small>
            </span>
            <Icon name="chevron" />
          </button>
        </section>
      </main>
    </section>
  )
}

function LanguageSheet({ go }: { go: (screen: number) => void }) {
  const [language, setLanguage] = useState("العربية")

  return (
    <section className="screen language-screen">
      <PageHeader title="اللغة" go={go} />
      <main className="language-backdrop">
        <div className="language-preview">
          <Icon name="globe" />
          <h2>لغة التطبيق</h2>
          <p>يمكنك تغيير لغة العرض في أي وقت.</p>
        </div>
      </main>
      <div className="language-sheet">
        <i />
        <div className="sheet-heading">
          <div>
            <h2>اختر اللغة</h2>
            <p>Choose your preferred language</p>
          </div>
          <span>
            <Icon name="globe" />
          </span>
        </div>
        {[
          { label: "العربية", meta: "Arabic", code: "ع", available: true },
          {
            label: "English",
            meta: "الإنجليزية — قريباً",
            code: "En",
            available: false,
          },
        ].map((item) => (
          <button
            className={`language-option${
              language === item.label ? " active" : ""
            }`}
            key={item.label}
            onClick={() => setLanguage(item.label)}
            disabled={!item.available}
            aria-label={
              item.available
                ? `اختيار ${item.label}`
                : `${item.label} غير متاحة حالياً`
            }
          >
            <b>{item.code}</b>
            <span>
              <strong>{item.label}</strong>
              <small>{item.meta}</small>
            </span>
            <i>{language === item.label ? "✓" : ""}</i>
          </button>
        ))}
        <PrimaryButton onClick={() => go(-1)}>تطبيق اللغة</PrimaryButton>
      </div>
    </section>
  )
}

type SpecialRequest = {
  type: string
  date: string
  status: string
  tone: string
}

const initialSpecialRequests: SpecialRequest[] = [
  {
    type: "شقة سكنية في صنعاء",
    date: "12 أكتوبر 2026",
    status: "قيد المراجعة",
    tone: "pending",
  },
  {
    type: "شاليه عائلي في عدن",
    date: "28 سبتمبر 2026",
    status: "تم العثور على طلبك",
    tone: "found",
  },
  {
    type: "محل تجاري في حدة",
    date: "04 سبتمبر 2026",
    status: "قيد المراجعة",
    tone: "pending",
  },
]

function RequestsFeed({
  go,
  requests,
}: {
  go: (screen: number) => void
  requests: SpecialRequest[]
}) {
  const [statusMessage, setStatusMessage] = useState("")

  return (
    <div className="requests-content">
      {statusMessage && (
        <div
          className="mb-3 rounded-xl border border-[var(--line)] bg-[var(--primary-soft)] p-3 text-xs font-bold leading-6 text-[var(--text)]"
          role="status"
        >
          {statusMessage}
        </div>
      )}
      <button className="new-request-button" onClick={() => go(34)}>
        <span>+</span>
        <div>
          <strong>رفع طلب عقار جديد</strong>
          <p>أخبرنا بما تبحث عنه وسنساعدك في إيجاده</p>
        </div>
        <Icon name="chevron" />
      </button>
      <div className="list-summary">
        <p>الطلبات السابقة</p>
        <span>{requests.length} طلبات</span>
      </div>
      <div className="request-list">
        {requests.map((request, index) => (
          <button
            className="request-card"
            key={`${request.type}-${request.date}-${index}`}
            onClick={() =>
              setStatusMessage(
                request.tone === "pending"
                  ? "طلبك قيد المراجعة ولا توجد نتائج بعد"
                  : "تم العثور على نتيجة لطلبك، وسنتواصل معك لإكمال التفاصيل",
              )
            }
          >
            <span className="request-icon">
              <Icon name="search" />
            </span>
            <div>
              <strong>{request.type}</strong>
              <p>
                <Icon name="calendar" />
                {request.date}
              </p>
            </div>
            <small className={request.tone}>{request.status}</small>
          </button>
        ))}
      </div>
    </div>
  )
}

function MyRequests({
  go,
  requests,
}: {
  go: (screen: number) => void
  requests: SpecialRequest[]
}) {
  return (
    <section className="screen feature-screen">
      <PageHeader title="طلباتي" go={go} />
      <main className="feature-content requests-page">
        <RequestsFeed go={go} requests={requests} />
      </main>
      <nav className="bottom-nav account-bottom-nav" aria-label="التنقل الرئيسي">
        {bottomNav.map((item, index) => (
          <button
            key={item.label}
            className={index === 1 ? "active" : ""}
            onClick={() => go(item.target)}
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
    </section>
  )
}

function NewPropertyRequest({
  go,
  onAddRequest,
}: {
  go: (screen: number) => void
  onAddRequest: (request: SpecialRequest) => void
}) {
  const [request, setRequest] = useState("")
  const [submitted, setSubmitted] = useState(false)

  return (
    <section className="screen feature-screen">
      <PageHeader title="رفع طلب عقار جديد" go={go} />
      <main className="feature-content custom-request-content">
        {submitted && (
          <SuccessBanner>تم الرفع، عندما يتوفر طلبك سيصلك إشعار</SuccessBanner>
        )}
        <div className="custom-request-intro">
          <span>
            <Icon name="search" />
          </span>
          <h1>ما العقار الذي تبحث عنه؟</h1>
          <p>
            اكتب تفاصيل طلبك بوضوح، مثل نوع العقار والموقع والميزانية والمواصفات
            التي تهمك.
          </p>
        </div>
        <form
          className="custom-request-form"
          onSubmit={(event) => {
            event.preventDefault()
            if (!request.trim()) return
            onAddRequest({
              type: request.trim(),
              date: "اليوم",
              status: "قيد المراجعة",
              tone: "pending",
            })
            setSubmitted(true)
            setRequest("")
          }}
        >
          <label>
            <span>تفاصيل الطلب المخصص</span>
            <textarea
              value={request}
              onChange={(event) => {
                setRequest(event.target.value)
                setSubmitted(false)
              }}
              placeholder="مثال: أبحث عن شقة مفروشة في صنعاء، ثلاث غرف، قريبة من الخدمات وبميزانية مناسبة..."
              maxLength={500}
              required
            />
            <small>{request.length} / 500</small>
          </label>
          <PrimaryButton type="submit">رفع الطلب</PrimaryButton>
        </form>
      </main>
    </section>
  )
}

type ChatMessage = {
  id: string
  text: string
  sentAt: string
}

type Conversation = {
  id: string
  ownerId: string
  name: string
  type: string
  initials: string
  message: string
  time: string
  unread: number
  online: boolean
  updatedAt: number
  pinned?: boolean
  muted?: boolean
  messages: ChatMessage[]
}

const initialConversations: Conversation[] = [
  {
    id: "hotel-sanaa",
    ownerId: owners.hotelSanaa.id,
    name: "فندق سماء صنعاء",
    type: "فنادق",
    initials: "فس",
    message: "يسعدنا تأكيد حجزك، هل تحتاج إلى خدمة النقل؟",
    time: "10:42 ص",
    unread: 2,
    online: true,
    updatedAt: 4,
    messages: [],
  },
  {
    id: "owner-ahmed",
    ownerId: owners.ahmed.id,
    name: "أحمد القاسمي",
    type: "ملاك",
    initials: "أق",
    message: "الشقة متاحة للمعاينة غداً بعد الساعة الرابعة.",
    time: "أمس",
    unread: 0,
    online: true,
    updatedAt: 3,
    messages: [],
  },
  {
    id: "office-ofuq",
    ownerId: owners.ofuq.id,
    name: "مكتب أفق العقاري",
    type: "ملاك",
    initials: "مأ",
    message: "أرسلنا لك التفاصيل الكاملة والموقع على الخريطة.",
    time: "الأحد",
    unread: 1,
    online: false,
    updatedAt: 2,
    messages: [],
  },
  {
    id: "chalets-oasis",
    ownerId: owners.oasis.id,
    name: "شاليهات الواحة",
    type: "فنادق",
    initials: "شا",
    message: "شكراً لاختيارك لنا، نتمنى لك إقامة سعيدة.",
    time: "12 أكتوبر",
    unread: 0,
    online: false,
    updatedAt: 1,
    messages: [],
  },
]

function Chats({
  go,
  conversations,
  onDelete,
  onPin,
  onUnpin,
  onOpen,
}: {
  go: (screen: number) => void
  conversations: Conversation[]
  onDelete: (id: string) => void
  onPin: (id: string) => void
  onUnpin: (id: string) => void
  onOpen: (conversation: Conversation) => void
}) {
  const [category, setCategory] = useState("الكل")
  const [query, setQuery] = useState("")
  const pointerStarts = useRef<Record<string, { x: number; y: number; locked?: "x" | "y" }>>({})
  const longPressTimers = useRef<Record<string, number>>({})
  const swiped = useRef<Record<string, boolean>>({})
  const [dragOffsets, setDragOffsets] = useState<Record<string, number>>({})
  const unreadConversationCount = conversations.filter(
    (conversation) => conversation.unread > 0,
  ).length
  const visibleChats = [...conversations]
    .filter((conversation) => {
      const matchesCategory =
        category === "الكل" ||
        (category === "غير المقروءة"
          ? conversation.unread > 0
          : conversation.type === category)
      return matchesCategory && conversation.name.includes(query.trim())
    })
    .sort(
      (a, b) =>
        Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)) ||
        b.updatedAt - a.updatedAt,
    )

  const clearLongPress = (id: string) => {
    const timer = longPressTimers.current[id]
    if (timer) window.clearTimeout(timer)
    delete longPressTimers.current[id]
  }

  return (
    <section className="screen feature-screen chats-screen">
      <PageHeader title="الرسائل" go={go} />
      <main className="chats-content">
        <label className="chats-search">
          <Icon name="search" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="ابحث في المحادثات..."
          />
        </label>
        <div className="chat-categories">
          {["الكل", "غير المقروءة", "ملاك", "فنادق"].map((item) => (
            <button
              key={item}
              className={category === item ? "active" : ""}
              onClick={() => setCategory(item)}
            >
              {item}
              {item === "غير المقروءة" && (
                <span>{unreadConversationCount}</span>
              )}
            </button>
          ))}
        </div>
        <div className="chats-heading">
          <div>
            <h2>الرسائل</h2>
            <p>{visibleChats.length} محادثات</p>
          </div>
          <button onClick={() => go(25)}>
            <Icon name="send" />
            رسالة جديدة
          </button>
        </div>
        <button className="pinned-bot-card" onClick={() => go(17)}>
          <span>
            <Icon name="sparkles" />
            <i />
          </span>
          <div>
            <strong>مساعد مسكني الذكي</strong>
            <small>متصل الآن</small>
            <p>مرحباً! كيف يمكنني مساعدتك في العثور على عقارك؟</p>
          </div>
          <b>مثبت</b>
        </button>
        <div className="conversations-list">
          {visibleChats.map((conversation, index) => {
            const startsNormalSection =
              !conversation.pinned &&
              (index === 0 || visibleChats[index - 1]?.pinned)
            return (
              <div className="contents" key={conversation.id}>
                {index === 0 && conversation.pinned && (
                  <p className="mb-1 mt-1 text-[10px] font-bold text-[var(--primary-text)]">
                    المحادثات المثبتة
                  </p>
                )}
                {startsNormalSection && (
                  <p className="mb-1 mt-2 text-[10px] font-bold text-[var(--text-muted)]">
                    كل المحادثات
                  </p>
                )}
                <button
                  className={`conversation-card touch-pan-y select-none ${
                    conversation.pinned ? "border-[var(--primary)]" : ""
                  }`}
                  onClick={() => {
                    if (swiped.current[conversation.id]) {
                      delete swiped.current[conversation.id]
                      return
                    }
                    onOpen(conversation)
                  }}
                                    onContextMenu={(event) => event.preventDefault()}
                  style={{
                    transform: dragOffsets[conversation.id]
                      ? `translateX(${dragOffsets[conversation.id]}px)`
                      : undefined,
                    transition: dragOffsets[conversation.id]
                      ? "none"
                      : "transform 180ms ease",
                  }}
                  onPointerDown={(event) => {
                    pointerStarts.current[conversation.id] = {
                      x: event.clientX,
                      y: event.clientY,
                    }
                    if (conversation.pinned) {
                      longPressTimers.current[conversation.id] =
                        window.setTimeout(() => {
                          swiped.current[conversation.id] = true
                          onUnpin(conversation.id)
                        }, 650)
                    }
                  }}
                  onPointerMove={(event) => {
                    const start = pointerStarts.current[conversation.id]
                    if (!start) return

                    const dx = event.clientX - start.x
                    const dy = event.clientY - start.y

                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                      clearLongPress(conversation.id)
                    }

                    if (!start.locked) {
                      if (Math.abs(dy) > 10 && Math.abs(dy) > Math.abs(dx)) {
                        start.locked = "y"
                      } else if (
                        Math.abs(dx) > 12 &&
                        Math.abs(dx) > Math.abs(dy)
                      ) {
                        start.locked = "x"
                      }
                    }

                    if (start.locked === "x") {
                      const clamped = Math.max(-100, Math.min(100, dx))
                      setDragOffsets((current) => ({
                        ...current,
                        [conversation.id]: clamped,
                      }))
                    }
                  }}
                  onPointerCancel={() => {
                    clearLongPress(conversation.id)
                    delete pointerStarts.current[conversation.id]
                    setDragOffsets((current) => ({
                      ...current,
                      [conversation.id]: 0,
                    }))
                  }}
                  onPointerUp={(event) => {
                    clearLongPress(conversation.id)
                    const start = pointerStarts.current[conversation.id]
                    delete pointerStarts.current[conversation.id]
                    setDragOffsets((current) => ({
                      ...current,
                      [conversation.id]: 0,
                    }))

                    if (!start || start.locked !== "x") return
                    const distance = event.clientX - start.x

                    if (Math.abs(distance) > 85) {
                      swiped.current[conversation.id] = true
                      window.setTimeout(() => {
                        delete swiped.current[conversation.id]
                      }, 0)
                    }
                    if (distance > 85) onDelete(conversation.id)
                    if (distance < -85) onPin(conversation.id)
                  }}
                >
                  <span className={`chat-avatar tone-${(index % 3) + 1}`}>
                    {conversation.initials}
                    {conversation.online && <i />}
                  </span>
                  <div>
                    <strong>
                      {conversation.name}
                      <b>✓</b>
                    </strong>
                    <small>
                      {conversation.type === "ملاك"
                        ? "مالك موثّق"
                        : "منشأة موثّقة"}
                    </small>
                    <p className={conversation.unread ? "unread" : ""}>
                      {conversation.message}
                    </p>
                  </div>
                  <span className="chat-meta">
                    <time>{conversation.time}</time>
                    {(conversation.pinned || conversation.muted) && (
                      <span className="flex items-center gap-1">
                        {conversation.muted && (
                          <span
                            className="grid size-5 place-items-center rounded-full bg-[var(--surface-soft)] text-[var(--text-muted)]"
                            aria-label="الإشعارات مكتومة"
                            title="الإشعارات مكتومة"
                          >
                            <Icon name="bellOff" />
                          </span>
                        )}
                        {conversation.pinned && (
                          <span
                            className="text-[var(--primary-text)]"
                            aria-label="محادثة مثبتة"
                          >
                            <Icon name="pin" />
                          </span>
                        )}
                      </span>
                    )}
                    {conversation.unread > 0 && <b>{conversation.unread}</b>}
                  </span>
                </button>
              </div>
            )
          })}
          {visibleChats.length === 0 && (
            <div className="empty-chats">
              <Icon name="chat" />
              <strong>لا توجد محادثات</strong>
              <p>جرّب البحث باسم مختلف أو اختر تصنيفاً آخر.</p>
            </div>
          )}
        </div>
      </main>
      <nav
  className="bottom-nav account-bottom-nav"
  aria-label="التنقل الرئيسي"
>
  {bottomNav.map((item, index) => (
    <button
      key={item.label}
      className={index === 3 ? "active relative" : "relative"}
      onClick={() => go(item.target)}
    >
      <Icon name={item.icon} />
      <span>{item.label}</span>
      {index === 3 && unreadConversationCount > 0 && (
        <b className="absolute right-1/2 top-1 grid size-4 translate-x-4 place-items-center rounded-full bg-[var(--danger)] text-[8px] text-[var(--dark-text)]">
          {unreadConversationCount}
        </b>
      )}
    </button>
  ))}
</nav>
    </section>
  )
}

function ChatDetail({
  go,
  property,
  conversation,
  onDelete,
  onBlock,
  onReport,
  muted,
  onToggleMute,
  onSendMessage,
  onViewOwner,
  onOpenProperty,
}: {
  go: (screen: number) => void
  property?: Property
  conversation?: Conversation
  onDelete: (id?: string) => void
  onBlock: (id?: string) => void
  onReport: (id?: string) => void
  muted: boolean
  onToggleMute: (id?: string) => void
  onSendMessage: (id: string | undefined, message: string) => void
  onViewOwner: () => void
  onOpenProperty: (property: Property) => void
}) {
  const [message, setMessage] = useState("")
  const [notice, setNotice] = useState("")
  const [optionsOpen, setOptionsOpen] = useState(false)
  const [isSearching, setIsSearching] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [voicePlaying, setVoicePlaying] = useState(false)
  const [localMuted, setLocalMuted] = useState(false)
  const isMuted = conversation ? muted : localMuted
  const contactName =
    conversation?.name ?? property?.owner.name ?? "أحمد القاسمي"
  const contactInitials =
    conversation?.initials ?? property?.owner.initials ?? "أق"

  const sendMessage = () => {
    if (!message.trim()) return
    const nextMessage = message.trim()
    onSendMessage(conversation?.id, nextMessage)
    setMessage("")
  }

  const matchingMessages = (conversation?.messages ?? []).filter((item) =>
    item.text
      .toLocaleLowerCase("ar")
      .includes(searchQuery.trim().toLocaleLowerCase("ar")),
  )

  const showNotice = (text: string) => {
    setNotice(text)
    window.setTimeout(() => setNotice(""), 2200)
  }

  return (
    <section className="screen chat-detail-screen">
      <header className="chat-detail-header">
        <BackButton onClick={() => go(-1)} />
        <div className="chat-contact">
          <span className="chat-avatar tone-1">
            {contactInitials}
            <i />
          </span>
          <div>
            <strong>
              {contactName}
              <b>✓</b>
            </strong>
            <small>متصل الآن</small>
          </div>
        </div>
        <div className="chat-header-actions">
          <button onClick={() => setOptionsOpen(true)} aria-label="المزيد">
            <Icon name="more" />
          </button>
        </div>
      </header>

      {isSearching && (
        <div className="chat-message-search">
          <label>
            <Icon name="search" />
            <input
              type="search"
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
              placeholder="ابحث في الرسائل..."
              autoFocus
            />
          </label>
          {searchQuery && (
            <small className="chat-search-count">
              {matchingMessages.length} نتيجة
            </small>
          )}
          <button
            onClick={() => {
              setSearchQuery("")
              setIsSearching(false)
            }}
          >
            إلغاء
          </button>
        </div>
      )}

      <main className="messages-thread">
        <div className="chat-date-divider">
          <span>اليوم</span>
        </div>

        <div className="message-row incoming">
          <span className="mini-chat-avatar">أق</span>
          <div className="message-bubble">
            أهلاً بك، {property ? `عقار «${property.title}»` : "الشقة"} ما زال
            متاحاً ويمكن ترتيب موعد للمعاينة.
            <time>10:31 ص</time>
          </div>
        </div>

        <div className="message-row outgoing">
          <div className="message-bubble">
            ممتاز، هل يمكن المعاينة غداً بعد الساعة الرابعة؟
            <time>
              10:34 ص <b>✓✓</b>
            </time>
          </div>
        </div>

        <div className="message-row incoming">
          <span className="mini-chat-avatar">أق</span>
          <div className="message-bubble">
            نعم بالتأكيد، أرسلت لك موقع العقار والتفاصيل.
            <time>10:36 ص</time>
          </div>
        </div>

        <button
          className="shared-property-card"
          onClick={() => (property ? onOpenProperty(property) : go(14))}
        >
          <span>
            <Icon name="building" />
          </span>
          <div>
            <small>عقار تمت مشاركته</small>
            <strong>{property?.title ?? "شقة عصرية في حي حدة"}</strong>
            <p>
              <Icon name="pin" />
              {property ? propertyAddress(property) : "صنعاء، حي حدة"}
            </p>
          </div>
          <b>{property ? propertyPrice(property) : "85,000,000 ر.ي"}</b>
        </button>

        <div className="message-row incoming voice-row">
          <span className="mini-chat-avatar">أق</span>
          <div className="voice-message">
            <button
              onClick={() => setVoicePlaying((current) => !current)}
              aria-label={
                voicePlaying ? "إيقاف الرسالة الصوتية" : "تشغيل الرسالة الصوتية"
              }
              aria-pressed={voicePlaying}
            >
              {voicePlaying ? "❚❚" : "▶"}
            </button>
            <div className="voice-wave">
              {Array.from({ length: 12 }).map((_, index) => (
                <i key={index} />
              ))}
            </div>
            <span dir="ltr">0:24</span>
          </div>
        </div>

        {(conversation?.messages ?? []).map((sentMessage) => (
          <div
            className={`message-row outgoing${
              searchQuery &&
              sentMessage.text
                .toLocaleLowerCase("ar")
                .includes(searchQuery.toLocaleLowerCase("ar"))
                ? " message-search-match"
                : ""
            }`}
            key={sentMessage.id}
          >
            <div className="message-bubble">
              {sentMessage.text}
              <time>
                {sentMessage.sentAt} <b>✓</b>
              </time>
            </div>
          </div>
        ))}

        <div className="typing-indicator">
          <span className="mini-chat-avatar">أق</span>
          <div>
            <i />
            <i />
            <i />
          </div>
          <small>يكتب الآن...</small>
        </div>
      </main>

      <div className="message-composer">
        <label aria-label="إرفاق ملف" title="إرفاق ملف">
          <input
            type="file"
            onChange={(event) => {
              const file = event.target.files?.[0]
              if (file) showNotice(`تم اختيار الملف: ${file.name}`)
              event.target.value = ""
            }}
          />
          <Icon name="paperclip" />
        </label>
        <label
          className="composer-action"
          aria-label="إرسال صورة"
          title="إرسال صورة"
        >
          <input
            type="file"
            accept="image/*"
            onChange={(event) => {
              const file = event.target.files?.[0]
              if (file) showNotice(`تم اختيار الصورة: ${file.name}`)
              event.target.value = ""
            }}
          />
          <Icon name="image" />
        </label>
        <div className="composer-input">
          <input
            value={message}
            onChange={(event) => setMessage(event.target.value)}
            onKeyDown={(event) => event.key === "Enter" && sendMessage()}
            placeholder="اكتب رسالتك..."
          />
          <button
            onClick={() => setMessage((current) => `${current}🙂`)}
            aria-label="رمز تعبيري"
          >
            <Icon name="smile" />
          </button>
        </div>
        <button
          className="composer-send"
          onClick={
            message.trim()
              ? sendMessage
              : () => showNotice("اضغط مطولاً لتسجيل رسالة صوتية")
          }
          aria-label={message.trim() ? "إرسال الرسالة" : "رسالة صوتية"}
        >
          <Icon name={message.trim() ? "send" : "mic"} />
        </button>
      </div>

      {optionsOpen && (
        <div className="chat-options-layer">
          <button
            className="chat-options-scrim"
            onClick={() => setOptionsOpen(false)}
            aria-label="إغلاق خيارات المحادثة"
          />
          <aside className="chat-options-panel">
            <div className="chat-options-heading">
              <div>
                <strong>خيارات المحادثة</strong>
                <small>{contactName}</small>
              </div>
              <button onClick={() => setOptionsOpen(false)} aria-label="إغلاق">
                <Icon name="close" />
              </button>
            </div>
            <div className="chat-options-profile">
              <span className="chat-avatar tone-1">{contactInitials}</span>
              <div>
                <strong>
                  {contactName} <b>✓</b>
                </strong>
                <small>مالك موثّق · متصل الآن</small>
              </div>
            </div>
            <div className="chat-options-list">
              <button onClick={onViewOwner}>
                <Icon name="user" />
                <span>عرض الملف الشخصي</span>
                <Icon name="chevron" />
              </button>
              <button
                onClick={() => {
                  if (conversation) onToggleMute(conversation.id)
                  else setLocalMuted((current) => !current)
                  showNotice(
                    isMuted ? "تم تشغيل الإشعارات" : "تم كتم الإشعارات",
                  )
                }}
              >
                <Icon name={isMuted ? "bellOff" : "bell"} />
                <span>كتم إشعارات المحادثة</span>
                <i
                  className={isMuted ? "option-switch active" : "option-switch"}
                >
                  <b />
                </i>
              </button>
              <button
                onClick={() => {
                  setIsSearching(true)
                  setOptionsOpen(false)
                }}
              >
                <Icon name="search" />
                <span>البحث في المحادثة</span>
                <Icon name="chevron" />
              </button>
            </div>
            <div className="chat-danger-options">
              <button
                onClick={() => {
                  if (!window.confirm("هل تريد حظر هذا المستخدم؟")) return
                  onBlock(conversation?.id)
                }}
              >
                <Icon name="warning" />
                حظر المستخدم
              </button>
              <button
                onClick={() => {
                  if (!window.confirm("هل تريد إرسال بلاغ عن هذه المحادثة؟"))
                    return
                  onReport(conversation?.id)
                  showNotice("تم إرسال البلاغ، سنراجعه في أقرب وقت")
                  setOptionsOpen(false)
                }}
              >
                <Icon name="document" />
                إبلاغ عن المحادثة
              </button>
              <button
                onClick={() => {
                  if (!window.confirm("هل تريد مسح هذه المحادثة نهائياً؟"))
                    return
                  onDelete(conversation?.id)
                }}
              >
                <Icon name="trash" />
                مسح المحادثة
              </button>
            </div>
          </aside>
        </div>
      )}

      {notice && (
        <div className="chat-action-toast" role="status">
          {notice}
        </div>
      )}
    </section>
  )
}

const offers = [
  {
    className: "summer",
    icon: "chalet" as IconName,
    title: "خصم 15% على شاليهات الصيف",
    text: "استمتع بعطلتك مع أفضل الشاليهات المختارة.",
    code: "SUMMER15",
  },
  {
    className: "hotel-offer",
    icon: "hotel" as IconName,
    title: "ليلة إضافية مجاناً",
    text: "احجز ليلتين في الفنادق المشاركة واحصل على الثالثة.",
    code: "NIGHT3",
  },
  {
    className: "home-offer",
    icon: "building" as IconName,
    title: "عرض المستأجر الجديد",
    text: "خصم خاص على رسوم أول حجز شهري عبر مسكني.",
    code: "NEWRENT",
  },
]

function OffersFeed() {
  const [usedCode, setUsedCode] = useState("")

  return (
    <div className="offers-content offers-tab-content">
      {usedCode && (
        <SuccessBanner>تم تفعيل الكود {usedCode} بنجاح</SuccessBanner>
      )}
      <p className="offers-lead">عروض مختارة تجعل تجربتك أجمل وأوفر</p>
      <div className="offers-list">
        {offers.map((offer) => (
          <article className="offer-card" key={offer.code}>
            <div className={`offer-banner ${offer.className}`}>
              <Icon name={offer.icon} />
              <span>عرض حصري</span>
              <i />
            </div>
            <div className="offer-copy">
              <h2>{offer.title}</h2>
              <p>{offer.text}</p>
              <div>
                <code>{offer.code}</code>
                <button onClick={() => setUsedCode(offer.code)}>
                  استخدم الكود
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}

function AccountSettings({ go }: { go: (screen: number) => void }) {
  const [shareNotice, setShareNotice] = useState(false)

  const shareProfile = async () => {
    const shareData = {
      title: "الملف الشخصي — مسكني",
      text: "الملف الشخصي لمحمد أحمد على منصة مسكني",
    }

    try {
      if (!navigator.share) throw new Error("Web Share is unavailable")
      await navigator.share(shareData)
    } catch {
      try {
        await navigator.clipboard?.writeText(
          `${shareData.title} — ${shareData.text}`,
        )
      } catch {
        // Embedded previews may restrict both sharing and clipboard access.
      }
    }
    setShareNotice(true)
    window.setTimeout(() => setShareNotice(false), 2600)
  }

  return (
    <section className="screen feature-screen">
      <PageHeader title="الملف الشخصي" go={go} />
      <main className="feature-content account-settings-content">
        {shareNotice && (
          <SuccessBanner>تم تجهيز الملف الشخصي للمشاركة</SuccessBanner>
        )}
        <span className="account-section-label">الملف الشخصي</span>
        <div className="account-hero">
          <div className="avatar avatar--large">مح</div>
          <div className="account-hero-copy">
            <strong className="verified-name">
              محمد أحمد
              <span>✓</span>
            </strong>
            <span className="account-role">
              <i />
              مستخدم عادي · حساب نشط
            </span>
            <div className="account-contact-details">
              <span dir="ltr">
                <Icon name="mail" />
                mohammed@email.com
              </span>
              <span dir="ltr">
                <Icon name="phone" />
                +967 700 000 000
              </span>
            </div>
          </div>
          <div className="profile-card-actions">
            <button
              className="profile-share-button"
              onClick={() => void shareProfile()}
            >
              <Icon name="share" />
              مشاركة الملف
            </button>
            <button className="profile-edit-link" onClick={() => go(23)}>
              تعديل البيانات
            </button>
          </div>
        </div>
      </main>
    </section>
  )
}

function AccountLinkRow({
  icon,
  name,
  linked,
  onClick,
}: {
  icon: IconName
  name: string
  linked: boolean
  onClick: () => void
}) {
  return (
    <div className="account-link-row">
      <span>
        <Icon name={icon} />
      </span>
      <div>
        <strong>{name}</strong>
        <small>{linked ? "تم ربط الحساب" : "غير مرتبط"}</small>
      </div>
      <button className={linked ? "linked" : ""} onClick={onClick}>
        {linked ? "إلغاء الربط" : "ربط الحساب"}
      </button>
    </div>
  )
}

function NotificationSettings({ go }: { go: (screen: number) => void }) {
  const [promos, setPromos] = useState(true)
  const [messages, setMessages] = useState(true)
  const [updates, setUpdates] = useState(false)

  return (
    <section className="screen feature-screen">
      <PageHeader title="إعدادات الإشعارات" go={go} />
      <main className="feature-content notification-settings-content">
        <div className="notification-settings-intro">
          <span>
            <Icon name="bell" />
          </span>
          <h2>تحكّم في تنبيهاتك</h2>
          <p>اختر الإشعارات التي ترغب في استقبالها من مسكني.</p>
        </div>
        <section className="security-card">
          <ToggleRow
            icon="tag"
            title="إشعارات العروض والخصومات"
            subtitle="أحدث العروض والأكواد الحصرية"
            active={promos}
            onClick={() => setPromos(!promos)}
          />
          <ToggleRow
            icon="chat"
            title="إشعارات الرسائل"
            subtitle="الرسائل والردود الجديدة"
            active={messages}
            onClick={() => setMessages(!messages)}
          />
          <ToggleRow
            icon="settings"
            title="تحديثات الحساب"
            subtitle="الأمان والتوثيق وتغييرات الحساب"
            active={updates}
            onClick={() => setUpdates(!updates)}
          />
        </section>
      </main>
    </section>
  )
}

const faqItems = [
  {
    question: "كيف أقوم بحجز عقار؟",
    answer:
      "اختر العقار المناسب، راجع تفاصيله وتوفره، ثم تواصل مباشرة مع المالك عبر المحادثة الداخلية لترتيب المعاينة أو الاتفاق.",
  },
  {
    question: "كيف أتواصل مع مالك العقار؟",
    answer:
      "يمكنك بدء محادثة آمنة مع المالك من صفحة العقار أو من قسم الرسائل بعد تسجيل الدخول.",
  },
  {
    question: "هل يمكنني إلغاء الحجز؟",
    answer:
      "لا توجد عمليات حجز أو دفع مباشر على المنصة؛ يمكنك التنسيق مع المالك بشأن أي ترتيبات أو إلغاءات حسب الاتفاق بينكما.",
  },
]

function HelpCenter({ go }: { go: (screen: number) => void }) {
  const [openIndex, setOpenIndex] = useState(0)
  const openExternal = (url: string) => {
    window.open(url, "_blank", "noopener,noreferrer")
  }

  return (
    <section className="screen feature-screen">
      <PageHeader title="المساعدة والتواصل" go={go} />
      <main className="feature-content help-content">
        <div className="help-hero">
          <Icon name="help" />
          <h1>كيف يمكننا مساعدتك؟</h1>
          <p>إجابات سريعة عن أكثر الأسئلة شيوعاً.</p>
        </div>
        <div className="faq-list">
          {faqItems.map((item, index) => (
            <article
              className={`faq-item${openIndex === index ? " open" : ""}`}
              key={item.question}
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? -1 : index)}
              >
                <span>{item.question}</span>
                <b>+</b>
              </button>
              {openIndex === index && <p>{item.answer}</p>}
            </article>
          ))}
        </div>
        <div className="contact-heading help-contact-heading">
          <span>
            <Icon name="chat" />
          </span>
          <h1>تحتاج مساعدة إضافية؟</h1>
          <p>فريق مسكني جاهز للتواصل معك.</p>
        </div>
        <button
          className="contact-card whatsapp-card"
          onClick={() => openExternal("https://wa.me/967700000000")}
        >
          <span>
            <Icon name="whatsapp" />
          </span>
          <div>
            <strong>التواصل عبر واتساب</strong>
            <p>متاح يومياً من 9 صباحاً حتى 10 مساءً</p>
          </div>
          <Icon name="chevron" />
        </button>
        <button
          className="contact-card"
          onClick={() => {
            window.location.href = "mailto:support@maskani.app"
          }}
        >
          <span>
            <Icon name="mail" />
          </span>
          <div>
            <strong>التواصل عبر البريد الإلكتروني</strong>
            <p dir="ltr">support@maskani.app</p>
          </div>
          <Icon name="chevron" />
        </button>
        <section className="contact-social">
          <h2>تابعنا على منصات التواصل</h2>
          <div>
            {[
              {
                icon: "xSocial" as IconName,
                label: "X / Twitter",
                url: "https://x.com",
              },
              {
                icon: "instagram" as IconName,
                label: "Instagram",
                url: "https://www.instagram.com",
              },
              {
                icon: "whatsapp" as IconName,
                label: "WhatsApp",
                url: "https://wa.me/967700000000",
              },
            ].map((item) => (
              <button key={item.label} onClick={() => openExternal(item.url)}>
                <Icon name={item.icon} />
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </section>
      </main>
    </section>
  )
}

function Terms({ go }: { go: (screen: number) => void }) {
  return (
    <section className="screen feature-screen">
      <PageHeader title="الشروط والأحكام" go={go} />
      <main className="feature-content legal-content">
        <div className="legal-meta">
          <Icon name="document" />
          <div>
            <h1>الشروط والأحكام</h1>
            <p>آخر تحديث: أكتوبر 2026</p>
          </div>
        </div>
        <p className="legal-intro">
          باستخدامك لتطبيق مسكني، فإنك توافق على الشروط والسياسات الموضحة أدناه.
          نوصي بقراءتها بعناية قبل استخدام خدمات المنصة.
        </p>
        <section>
          <h2>شروط الاستخدام</h2>
          <p>
            يلتزم المستخدم بتقديم معلومات صحيحة وحديثة، واستخدام المنصة للأغراض
            المشروعة فقط. لا يجوز نشر محتوى مضلل أو استخدام الحساب للإضرار
            بالمستخدمين أو مزودي الخدمة.
          </p>
        </section>
        <section>
          <h2>سياسة الخصوصية</h2>
          <p>
            نجمع الحد الأدنى من البيانات اللازمة لتشغيل الخدمة وتحسينها. نحافظ
            على بياناتك وفق معايير حماية مناسبة، ولا نشاركها مع أطراف خارجية إلا
            بموافقتك أو عندما يقتضي القانون ذلك.
          </p>
        </section>
        <section>
          <h2>التصفح والتواصل المباشر</h2>
          <p>
            يتيح مسكني للمستخدمين تصفح العقارات والتواصل مباشرة مع الملاك
            الموثّقين عبر المحادثة الداخلية. لا تتضمن المنصة أي عمليات حجز أو
            دفع إلكتروني، ويتم الاتفاق على شروط المعاينة أو الإيجار أو البيع
            مباشرة بين الطرفين.
          </p>
        </section>
        <section>
          <h2>الطلبات المخصصة</h2>
          <p>
            يمكن للمستخدم رفع طلب عقار مخصص يوضح فيه احتياجاته، وسيقوم فريق
            مسكني أو الملاك بمحاولة توفير خيارات مطابقة. لا يضمن مسكني تلبية
            الطلب خلال مدة محددة، ويُعد رفع الطلب مجانياً.
          </p>
        </section>
        <section>
          <h2>حقوق المستخدم</h2>
          <p>
            يمكنك طلب تحديث بياناتك أو تعطيل حسابك أو حذفه نهائياً من إعدادات
            الحساب. قد نحتفظ ببعض السجلات عندما يكون ذلك مطلوباً لأسباب تنظيمية
            أو قانونية.
          </p>
        </section>
      </main>
    </section>
  )
}

function Splash({ go }: { go: (screen: number) => void }) {
  return (
    <button
      className="splash screen"
      onClick={() => go(1)}
      aria-label="الانتقال إلى شاشة الترحيب"
    >
      <div className="splash-glow" />
      <div className="splash-brand">
        <LogoMark large />
        <h1>مَسْكَنِي</h1>
        <p>مكانك يبدأ من هنا</p>
      </div>
      <span className="splash-hint">
        المس للبدء <i>←</i>
      </span>
    </button>
  )
}

function FeaturedScreen({
  go,
  onOpen,
  favoriteIds,
  onToggleFavorite,
  reportedPropertyIds,
  onReportProperty,
}: {
  go: (screen: number) => void
  onOpen: (property: Property) => void
  favoriteIds: Set<string>
  onToggleFavorite: (propertyId: string) => void
  reportedPropertyIds: Set<string>
  onReportProperty: (propertyId: string) => void
}) {
  const [category, setCategory] = useState("الكل")
  const [sort, setSort] = useState("الأحدث")

  const categories = [
    "الكل",
    "المنازل والشقق",
    "المحلات التجارية",
    "الأراضي",
    "الفنادق",
    "الشاليهات",
  ]

  const featured = properties
    .filter((property) => property.featured === true)
    .filter((property) => {
      if (category === "الكل") return true
      if (category === "المنازل والشقق") return property.category === "residential"
      if (category === "المحلات التجارية") return property.category === "commercial"
      if (category === "الأراضي") return property.category === "land"
      if (category === "الفنادق") return property.category === "hotel"
      if (category === "الشاليهات") return property.category === "chalet"
      return true
    })
    .sort((a, b) => {
      if (sort === "السعر: الأقل") return a.price - b.price
      if (sort === "السعر: الأعلى") return b.price - a.price
      return (
        Date.parse(b.featuredAt ?? b.createdAt) -
        Date.parse(a.featuredAt ?? a.createdAt)
      )
    })

  return (
    <section className="screen !bg-[var(--surface-soft)] text-[var(--text)]">
      <header
        className="flex items-center justify-between border-b border-[var(--line)] bg-[var(--surface-raised)] px-4 pb-3 pt-9"
        dir="rtl"
      >
        <button
          className="grid size-10 place-items-center rounded-full border border-[var(--line)] text-[var(--text)]"
          onClick={() => go(-1)}
          aria-label="رجوع"
        >
          <Icon name="arrow" />
        </button>
        <h1 className="!text-lg !font-extrabold !text-[var(--text)]" dir="rtl">
          العروض المميزة
        </h1>
        <span className="grid size-10 place-items-center rounded-full bg-[var(--rating)] text-[var(--dark-text)]">
          <Icon name="star" />
        </span>
      </header>

      <main className="min-h-0 flex-1 overflow-y-auto px-4 pb-24 pt-4">
        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 [scrollbar-width:none]">
          {categories.map((item) => (
            <button
              className={`shrink-0 rounded-full px-4 py-2 text-xs font-bold ${
                category === item
                  ? "bg-[var(--primary-strong)] text-[var(--dark-text)] shadow-sm"
                  : "border border-[var(--line)] bg-[var(--surface-raised)] text-[var(--text)]"
              }`}
              key={item}
              onClick={() => setCategory(item)}
            >
              {item}
            </button>
          ))}
        </div>

        <label
          className="my-3 flex w-full items-center justify-start gap-1 text-right text-[11px] text-[var(--text-muted)]"
          dir="rtl"
        >
          ترتيب حسب:
          <select
            className="border-0 bg-[var(--transparent)] font-bold text-[var(--text)] outline-none"
            value={sort}
            onChange={(event) => setSort(event.target.value)}
            aria-label="ترتيب العروض"
          >
            <option>الأحدث</option>
            <option>السعر: الأقل</option>
            <option>السعر: الأعلى</option>
          </select>
        </label>

        <div className="grid gap-4">
          {featured.map((property) => (
            <PropertyCard
              key={property.id}
              property={property}
              onOpen={onOpen}
              favorite={favoriteIds.has(property.id)}
              onToggleFavorite={onToggleFavorite}
              reported={reportedPropertyIds.has(property.id)}
              onReport={onReportProperty}
            />
          ))}
        </div>

        {!featured.length && (
          <div className="py-16 text-center text-sm text-[var(--text-muted)]">
            لا توجد عروض مميزة في هذا التصنيف حالياً.
          </div>
        )}
      </main>

      <nav
        className="bottom-nav account-bottom-nav"
        aria-label="التنقل الرئيسي"
      >
        {bottomNav.map((item, index) => (
          <button
            key={item.label}
            className={index === 2 ? "active" : ""}
            onClick={() => go(item.target)}
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
    </section>
  )
}

export default function App() {
  const [screen, setScreen] = useState(() => {
    const stored = window.history.state?.maskaniScreen
    return typeof stored === "number" ? stored : 0
  })
  const [accountType, setAccountType] = useState(0)
  const [selectedProperty, setSelectedProperty] = useState<Property>(
    properties[0],
  )
  const [filters, setFilters] =
    useState<SearchFilterState>(createDefaultFilters)
  const [filterContext, setFilterContext] =
    useState<SearchFilterContext>("all")
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(() => new Set())
  const [chatItems, setChatItems] =
    useState<Conversation[]>(initialConversations)
  const [selectedConversation, setSelectedConversation] =
    useState<Conversation>()
  const [selectedOwner, setSelectedOwner] = useState<Owner>(owners.ahmed)
  const [followedOwnerIds, setFollowedOwnerIds] = useState<Set<string>>(
    () => new Set([owners.ofuq.id]),
  )
  const [blockedOwnerIds, setBlockedOwnerIds] = useState<Set<string>>(
    () => new Set(),
  )
  const [reportedOwnerIds, setReportedOwnerIds] = useState<Set<string>>(
    () => new Set(),
  )
  const [reportedPropertyIds, setReportedPropertyIds] = useState<Set<string>>(
    () => new Set(),
  )
  const [reviews, setReviews] = useState<PropertyReview[]>([])
  const [specialRequests, setSpecialRequests] =
    useState<SpecialRequest[]>(initialSpecialRequests)
  const simulatedMessageIndex = useRef(0)
  const isPartner = accountType > 0
  const filterSource =
    filterContext === "residential"
      ? properties.filter((property) => property.category === "residential")
      : filterContext === "commercial"
        ? properties.filter((property) => property.category === "commercial")
        : filterContext === "land"
          ? properties.filter((property) => property.category === "land")
          : filterContext === "hotel"
            ? properties.filter((property) => property.category === "hotel")
            : filterContext === "chalet"
              ? properties.filter((property) => property.category === "chalet")
              : properties
  const filteredProperties = filterProperties(filterSource, filters)

  useEffect(() => {
    const storedTheme = window.localStorage.getItem("maskani-theme")
    if (storedTheme === "dark" || storedTheme === "light") {
      document.documentElement.dataset.theme = storedTheme
    }
  }, [])

  useEffect(() => {
    if (typeof window.history.state?.maskaniScreen !== "number") {
      window.history.replaceState({ maskaniScreen: screen }, "")
    }

    const handlePopState = (event: PopStateEvent) => {
      setScreen(
        typeof event.state?.maskaniScreen === "number"
          ? event.state.maskaniScreen
          : 0,
      )
    }

    window.addEventListener("popstate", handlePopState)
    return () => window.removeEventListener("popstate", handlePopState)
  }, [])

  useEffect(() => {
    const simulatedMessages = [
      "هل ما زلت مهتماً بالعقار؟ يمكننا ترتيب موعد مناسب.",
      "تم تحديث تفاصيل العرض، ويمكنك مراجعتها الآن.",
      "مرحباً، يسعدنا الإجابة عن أي استفسار لديك.",
    ]
    const timer = window.setInterval(() => {
      setChatItems((current) => {
        const candidates = current.filter(
          (item) => screen !== 36 || item.id !== selectedConversation?.id,
        )
        if (!candidates.length) return current
        const target =
          candidates[simulatedMessageIndex.current % candidates.length]
        const nextMessage =
          simulatedMessages[
            simulatedMessageIndex.current % simulatedMessages.length
          ]
        simulatedMessageIndex.current += 1
        return current.map((item) =>
          item.id === target.id
            ? {
                ...item,
                message: nextMessage,
                time: "الآن",
                unread: item.unread + 1,
                updatedAt: Date.now(),
              }
            : item,
        )
      })
    }, 20000)

    return () => window.clearInterval(timer)
  }, [screen, selectedConversation?.id])

  const navigate = (nextScreen: number) => {
    if (nextScreen === -1) {
      window.history.back()
      return
    }
    if (nextScreen === screen) return
    window.history.pushState({ maskaniScreen: nextScreen }, "")
    setScreen(nextScreen)
  }

  const openFilters = (context: SearchFilterContext) => {
    setFilterContext(context)
    if (context === "commercial") {
      setFilters({
        ...createDefaultFilters(),
        propertyType: "محلات",
      })
    } else if (context === "land") {
      setFilters({
        ...createDefaultFilters(),
        propertyType: "أرض",
      })
    } else if (context === "hotel") {
      setFilters({
        ...createDefaultFilters(),
        propertyType: "فندق",
      })
    } else if (context === "chalet") {
      setFilters({
        ...createDefaultFilters(),
        propertyType: "شاليه",
      })
    } else if (context === "residential") {
      setFilters((current) => ({
        ...current,
        propertyType: ["شقة", "منازل مستقلة", "فلل"].includes(
          current.propertyType,
        )
          ? current.propertyType
          : "",
      }))
    }
    navigate(16)
  }

  const openProperty = (property: Property) => {
    setSelectedProperty(property)
    navigate(38)
  }

  const openOwner = (owner: Owner) => {
    setSelectedOwner(owner)
    navigate(40)
  }

  const toggleFavorite = (propertyId: string) => {
    setFavoriteIds((current) => {
      const next = new Set(current)
      if (next.has(propertyId)) next.delete(propertyId)
      else next.add(propertyId)
      return next
    })
  }

  const openConversation = (conversation: Conversation) => {
    const openedConversation = { ...conversation, unread: 0 }
    setChatItems((current) =>
      current.map((item) =>
        item.id === conversation.id ? openedConversation : item,
      ),
    )
    setSelectedConversation(openedConversation)
    navigate(36)
  }

  const contactOwner = (owner: Owner) => {
    if (blockedOwnerIds.has(owner.id)) return
    const existingConversation = chatItems.find(
      (conversation) => conversation.ownerId === owner.id,
    )
    if (existingConversation) {
      openConversation(existingConversation)
      return
    }
    const conversation: Conversation = {
      id: `owner-${owner.id}`,
      ownerId: owner.id,
      name: owner.name,
      type: owner.type.includes("فندق") ? "فنادق" : "ملاك",
      initials: owner.initials,
      message: "ابدأ محادثتك الآن",
      time: "الآن",
      unread: 0,
      online: owner.online,
      updatedAt: Date.now(),
      messages: [],
    }
    setChatItems((current) => [conversation, ...current])
    setSelectedConversation(conversation)
    navigate(36)
  }

  const toggleFollowOwner = (ownerId: string) => {
    setFollowedOwnerIds((current) => {
      const next = new Set(current)
      if (next.has(ownerId)) next.delete(ownerId)
      else next.add(ownerId)
      return next
    })
  }

  const blockOwner = (ownerId: string) => {
    const isBlocked = blockedOwnerIds.has(ownerId)
    setBlockedOwnerIds((current) => {
      const next = new Set(current)
      if (next.has(ownerId)) next.delete(ownerId)
      else next.add(ownerId)
      return next
    })
    if (isBlocked) return
    setFollowedOwnerIds((current) => {
      const next = new Set(current)
      next.delete(ownerId)
      return next
    })
    setChatItems((current) =>
      current.filter((conversation) => conversation.ownerId !== ownerId),
    )
    setSelectedConversation((current) =>
      current?.ownerId === ownerId ? undefined : current,
    )
  }

  const reportOwner = (ownerId: string) => {
    setReportedOwnerIds((current) => new Set(current).add(ownerId))
  }

  const reportProperty = (propertyId: string) => {
    setReportedPropertyIds((current) => {
      const next = new Set(current)
      if (next.has(propertyId)) next.delete(propertyId)
      else next.add(propertyId)
      return next
    })
  }

  const addReview = (propertyId: string, rating: number, text: string) => {
    const id = `review-${Date.now()}`
    const review: PropertyReview = {
      id,
      propertyId,
      userId: "current-user",
      userName: "محمد أحمد",
      userInitials: "مح",
      rating,
      text,
      dateLabel: "الآن",
      createdAt: Date.now(),
      isOwn: true,
      isNew: true,
    }
    setReviews((current) => [review, ...current])
    window.setTimeout(() => {
      setReviews((current) =>
        current.map((item) =>
          item.id === id ? { ...item, isNew: false } : item,
        ),
      )
    }, 3500)
  }

  const deleteReview = (reviewId: string) => {
    setReviews((current) => current.filter((review) => review.id !== reviewId))
  }

  const deleteConversation = (id?: string) => {
    if (id) setChatItems((current) => current.filter((item) => item.id !== id))
    setSelectedConversation(undefined)
    navigate(35)
  }

  const pinConversation = (id: string) => {
    setChatItems((current) =>
      current
        .map((item) => (item.id === id ? { ...item, pinned: true } : item))
        .sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned))),
    )
  }

  const unpinConversation = (id: string) => {
    setChatItems((current) =>
      current.map((item) =>
        item.id === id ? { ...item, pinned: false } : item,
      ),
    )
  }

  const updateConversationFromSentMessage = (
    id: string | undefined,
    message: string,
  ) => {
    if (!id) return
    const update = (item: Conversation): Conversation =>
      item.id === id
        ? {
            ...item,
            message: `أنت: ${message}`,
            time: "الآن",
            unread: 0,
            updatedAt: Date.now(),
            messages: [
              ...item.messages,
              {
                id: `message-${Date.now()}`,
                text: message,
                sentAt: "الآن",
              },
            ],
          }
        : item
    setChatItems((current) => current.map(update))
    setSelectedConversation((current) => (current ? update(current) : current))
  }

  const toggleConversationMute = (id?: string) => {
    if (!id) return
    setChatItems((current) =>
      current.map((item) =>
        item.id === id ? { ...item, muted: !item.muted } : item,
      ),
    )
    setSelectedConversation((current) =>
      current?.id === id ? { ...current, muted: !current.muted } : current,
    )
  }

  const addSpecialRequest = (request: SpecialRequest) => {
    setSpecialRequests((current) => [request, ...current])
  }

  const current = (() => {
    if (screen === 0) return <Splash go={navigate} />
    if (screen >= 1 && screen <= 3)
      return <Onboarding step={screen - 1} go={navigate} />
    if (screen === 4)
      return <Login go={navigate} setAccountType={setAccountType} />
    if (screen === 5)
      return (
        <SignUp
          go={navigate}
          accountType={accountType}
          setAccountType={setAccountType}
        />
      )
    if (screen === 6) return <Otp go={navigate} isPartner={isPartner} />
    if (screen === 7) return <PasswordRecovery go={navigate} />
    if (screen === 8) return <TemporaryPassword go={navigate} />
    if (screen === 9) return <NewPassword go={navigate} isPartner={isPartner} />
    if (screen === 10 || screen === 11)
      return <Welcome partner={screen === 11} go={navigate} />
    if (screen === 12)
      return (
        <Home
          go={navigate}
          onOpenFilters={() => openFilters("all")}
          onViewAll={() => {
            setFilterContext("all")
            setFilters(createDefaultFilters())
            navigate(22)
          }}
          onSearch={(query) => {
            setFilterContext("all")
            setFilters({
              ...createDefaultFilters(),
              manualLocation: query.trim(),
            })
            navigate(22)
          }}
        />
      )
    if (screen === 13) return <AccountScreen go={navigate} />
    if (screen === 14)
      return (
        <HomesApartments
          go={navigate}
          onOpenFilters={() => openFilters("residential")}
          onOpen={openProperty}
          favoriteIds={favoriteIds}
          onToggleFavorite={toggleFavorite}
          reportedPropertyIds={reportedPropertyIds}
          onReportProperty={reportProperty}
        />
      )
    if (screen === 15)
      return <Notifications go={navigate} onOpenProperty={openProperty} />
    if (screen === 16)
      return (
        <SearchFilters
          go={navigate}
          filters={filters}
          setFilters={setFilters}
          onApply={() => navigate(22)}
          context={filterContext}
        />
      )
    if (screen === 17) return <AiAssistant go={navigate} />
    if (screen === 18) return <DeactivateAccount go={navigate} />
    if (screen === 19) return <DeleteAccount go={navigate} />
    if (screen === 20) return <Suggestions go={navigate} />
    if (screen === 21) return <About go={navigate} />
    if (screen === 22)
      return (
        <SearchResults
          go={navigate}
          onOpen={openProperty}
          results={filteredProperties}
          favoriteIds={favoriteIds}
          onToggleFavorite={toggleFavorite}
          reportedPropertyIds={reportedPropertyIds}
          onReportProperty={reportProperty}
          onReset={() =>
            setFilters({
              ...createDefaultFilters(),
              propertyType:
                filterContext === "commercial"
                  ? "محلات"
                  : filterContext === "land"
                    ? "أرض"
                    : filterContext === "hotel"
                      ? "فندق"
                      : filterContext === "chalet"
                        ? "شاليه"
                        : "",
            })
          }
        />
      )
    if (screen === 23) return <EditProfile go={navigate} />
    if (screen === 24)
  return <AccountVerification go={navigate} isPartner={isPartner} />
    if (screen === 25)
      return (
        <FollowingList
          go={navigate}
          followedOwnerIds={followedOwnerIds}
          onToggleFollow={toggleFollowOwner}
          onOpenOwner={openOwner}
        />
      )
    if (screen === 26) return <JoinPartner go={navigate} />
    if (screen === 27) return <Security go={navigate} />
    if (screen === 28) return <LanguageSheet go={navigate} />
    if (screen === 29)
      return <MyRequests go={navigate} requests={specialRequests} />
    if (screen === 30) return <AccountSettings go={navigate} />
    if (screen === 31) return <NotificationSettings go={navigate} />
    if (screen === 32) return <HelpCenter go={navigate} />
    if (screen === 33) return <Terms go={navigate} />
    if (screen === 34)
      return <NewPropertyRequest go={navigate} onAddRequest={addSpecialRequest} />
    if (screen === 35)
      return (
        <Chats
          go={navigate}
          conversations={chatItems}
          onDelete={(id) =>
            setChatItems((current) => current.filter((item) => item.id !== id))
          }
          onPin={pinConversation}
          onUnpin={unpinConversation}
          onOpen={openConversation}
        />
      )
    if (screen === 36)
      return (
        <ChatDetail
          go={navigate}
          property={
            selectedConversation
              ? properties.find(
                  (property) =>
                    property.owner.id === selectedConversation.ownerId,
                )
              : selectedProperty
          }
          conversation={selectedConversation}
          onDelete={deleteConversation}
          onBlock={(id) => {
            const conversation =
              chatItems.find((item) => item.id === id) ?? selectedConversation
            if (conversation) blockOwner(conversation.ownerId)
            navigate(35)
          }}
          onReport={(id) => {
            if (!id) return
            const conversation = chatItems.find((item) => item.id === id)
            if (conversation) reportOwner(conversation.ownerId)
            setChatItems((current) =>
              current.map((item) =>
                item.id === id
                  ? { ...item, message: "تم إرسال بلاغ عن هذه المحادثة" }
                  : item,
              ),
            )
          }}
          muted={Boolean(selectedConversation?.muted)}
          onToggleMute={toggleConversationMute}
          onSendMessage={updateConversationFromSentMessage}
          onViewOwner={() => {
            const owner =
              findOwner(selectedConversation?.ownerId ?? "") ??
              selectedProperty.owner
            openOwner(owner)
          }}
          onOpenProperty={openProperty}
        />
      )
    if (screen === 37)
      return (
        <FavoritesScreen
          go={navigate}
          onOpen={openProperty}
          favoriteIds={favoriteIds}
          onToggleFavorite={toggleFavorite}
          reportedPropertyIds={reportedPropertyIds}
          onReportProperty={reportProperty}
        />
      )
    if (screen === 38)
      return (
        <PropertyDetailsScreen
          property={selectedProperty}
          go={navigate}
          favorite={favoriteIds.has(selectedProperty.id)}
          onToggleFavorite={toggleFavorite}
          onChat={() => contactOwner(selectedProperty.owner)}
          reviews={reviews}
          onAddReview={addReview}
          onDeleteReview={deleteReview}
          onOpenOwner={openOwner}
          reported={reportedPropertyIds.has(selectedProperty.id)}
          onReportProperty={reportProperty}
        />
      )
    if (screen === 39) return <Placeholder go={navigate} isPartner={isPartner} />

    if (screen === 40)
      return (
        <OwnerProfileScreen
          owner={selectedOwner}
          go={navigate}
          reviews={reviews}
          followed={followedOwnerIds.has(selectedOwner.id)}
          blocked={blockedOwnerIds.has(selectedOwner.id)}
          reported={reportedOwnerIds.has(selectedOwner.id)}
          favoriteIds={favoriteIds}
          reportedPropertyIds={reportedPropertyIds}
          onToggleFollow={toggleFollowOwner}
          onContact={contactOwner}
          onOpenProperty={openProperty}
          onToggleFavorite={toggleFavorite}
          onReportProperty={reportProperty}
          onBlock={blockOwner}
          onReport={reportOwner}
        />
      )
    if (screen === 41)
      return (
        <CommercialShops
          go={navigate}
          onOpenFilters={() => openFilters("commercial")}
          onOpen={openProperty}
          favoriteIds={favoriteIds}
          onToggleFavorite={toggleFavorite}
          reportedPropertyIds={reportedPropertyIds}
          onReportProperty={reportProperty}
        />
      )
    if (screen === 42)
      return (
        <LandsScreen
          go={navigate}
          onOpenFilters={() => openFilters("land")}
          onOpen={openProperty}
          favoriteIds={favoriteIds}
          onToggleFavorite={toggleFavorite}
          reportedPropertyIds={reportedPropertyIds}
          onReportProperty={reportProperty}
        />
      )
    if (screen === 43)
      return (
        <HotelsScreen
          go={navigate}
          onOpenFilters={() => openFilters("hotel")}
          onOpen={openProperty}
          favoriteIds={favoriteIds}
          onToggleFavorite={toggleFavorite}
          reportedPropertyIds={reportedPropertyIds}
          onReportProperty={reportProperty}
        />
      )
    if (screen === 44)
      return (
        <ChaletsScreen
          go={navigate}
          onOpenFilters={() => openFilters("chalet")}
          onOpen={openProperty}
          favoriteIds={favoriteIds}
          onToggleFavorite={toggleFavorite}
          reportedPropertyIds={reportedPropertyIds}
          onReportProperty={reportProperty}
        />
      )
    if (screen === 45)
  return (
    <FeaturedScreen
      go={navigate}
      onOpen={openProperty}
      favoriteIds={favoriteIds}
      onToggleFavorite={toggleFavorite}
      reportedPropertyIds={reportedPropertyIds}
      onReportProperty={reportProperty}
    />
  )
    return <Placeholder go={navigate} />
  })()

  return (
    <div className="app-shell" dir="rtl">
      <aside className="flow-nav">
        <div className="flow-brand">
          <BrandMini />
          <p>تدفق الدخول والتسجيل</p>
        </div>
        <nav aria-label="شاشات التطبيق">
          {screens.map((name, index) => (
            <button
              key={name}
              className={screen === index ? "active" : ""}
              onClick={() => navigate(index)}
            >
              <span>{String(index + 1).padStart(2, "0")}</span>
              {name}
            </button>
          ))}
        </nav>
        <div className="flow-meta">
          <span>Maskani mobile</span>
          <span>RTL · {screens.length} screens</span>
        </div>
      </aside>
      <main className="device-stage">
        <div className="device">
          <div className="device-island" />
          {current}
        </div>
        <p className="stage-caption">
          واجهة واحدة، تجربة سلسة من الاكتشاف إلى التفعيل
        </p>
      </main>
    </div>
  )
}
